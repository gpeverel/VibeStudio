# Происхождение файлов, версия 17

## project/
- Страницы приложения и документов: пакет версии 16 (`bundles/v16-final.json`; опубликован как Version 18, `1793032088-f7c8`) плюс правки версии 17 (`tools/p_v17_app.py`, `tools/p_v17_pages.py`, `tools/p_v17_docs.py`, генератор листов `tools/gen_handoff8.py`, холст `tools/update_canvas8.py`). Версия 16 — правка пакета версии 15 (Version 17, `1792286621-25ae`), та — правка опубликованной версии 14 (`1792072575-8814`), та — правка опубликованной версии 12 (`1791973368-bfe9`). Исходная сборка версий 10–12 (каталог `src/`, `build.py` и др.) находилась во временной папке сессии, была очищена и **не восстановлена**.
- Платформы-обёртки создаёт `tools/mkboards5.py`; обёртки `T-*` и `RV-*` в комплект не входят. `support.js` — копия `artifact-type/dc-runtime.js` опубликованной версии.
- Основание документов (`tools/basis.json`): `docs/SPEC.md` на коммите 07776e2 (15.10.2026), состояние кода — репозиторий на 749f040 (19.10.2026), дизайн-контракт — согласование 27.10.2026, `docs/DESIGN.md` и `src/renderer/styles/tokens.css` в рабочей копии без коммита (SHA-256 в `basis.json`).

## proposals/
- `d0`–`d9`, `all.patch`, `index.json` — патчи версии 16 (`tools/mkproposals.py`) на основе файлов коммита `bc6a5c9`.
- `applied-2026-10-27.patch` — `git diff` рабочей копии после внесения: `all.patch` и абзац о масштабе 200% в разделе «Размер окна» `DESIGN.md`.

## tools/ и tests/
Таблица происхождения — в `tools/README.md` и `tests/README.md`. Коротко:
- извлечены из журнала сессии без изменений: `tools/gen_handoff_v12.py`, `tools/pt.py`;
- извлечены из журнала и изменены: `tests/legacy/t7–t12.mjs` (`tests/legacy/CHANGES.md`);
- написаны заново при подготовке версий 14–17: остальные файлы; в версии 17 — `tools/p_v17_*.py`, `tools/mkv17.py`, `tools/p_gen8.py`, `tools/update_canvas8.py`, `tools/mkkit8.py`; изменены `tests/ui7/zoom200.mjs`, `tests/tokens5.mjs`, `tools/check_docs15.py`, `tools/basis.json`, `tests/expected.json`.

## tests/evidence/
- `v14-before/`, `v14-baseline-new-harness/`, `v15-after/`, `v15-before/`, `v14-control/`, `v16/` — как в версии 16.
- `v17/` — проверка `zoom200` версии 17 на файлах версии 16 («до»), прежняя проверка на окне 640×480, предварительный прогон, Play-проверка Version 18.

## visual/
Снимки сделаны `tests/ui7/rvshots.mjs` (Playwright, Chrome) на страницах версии 17, 1440×900 и 640×480.
