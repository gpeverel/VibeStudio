// Контактный лист для просмотра: node tests/montage.mjs out.png name1 name2 ... (имена снимков из tests/shots/rv без RV- и .png)
import fs from 'node:fs';
import { launch, openPage } from './cdp.mjs';
const [out, ...names] = process.argv.slice(2);
const cols = names.length <= 2 ? names.length : 2;
const html = '<html><body style="margin:0;background:#888;display:grid;grid-template-columns:repeat(' + cols + ',1fr);gap:6px">' + names.map(n => '<div style="font:12px sans-serif;color:#fff"><div style="padding:2px 6px;background:#222">' + n + '</div><img style="width:100%;display:block" src="/tests/shots/rv/RV-' + n + '.png"></div>').join('') + '</body></html>';
fs.mkdirSync(new URL('../review/', import.meta.url).pathname, { recursive: true });
fs.writeFileSync(new URL('../review/m.html', import.meta.url).pathname, html);
const c = await launch();
try {
  const pg = await openPage(c.port, (process.env.MOCKUP_BASE || 'http://127.0.0.1:8765') + '/review/m.html', 1600, 1000);
  await pg.wait(1500);
  const h = await pg.ev('document.documentElement.scrollHeight');
  await pg.send('Emulation.setDeviceMetricsOverride', { width: 1600, height: h, deviceScaleFactor: 1, mobile: false });
  await pg.wait(300); await pg.shot(out); await pg.close();
} finally { c.close(); }
