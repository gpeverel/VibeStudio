#!/bin/sh
# Полный прогон проверок макета (версия 16; шаги ui7-* и docs добавлены в версии 16). Код возврата 0 — только если ВСЕ шаги выполнены и дали успех.
# Любая ошибка шага (непройденная проверка, исключение, шаг не запустился, пустой или неполный прогон) даёт ненулевой код.
# Запускать в отдельной распакованной копии комплекта: прогон переписывает результаты (прежние переносятся в results.prev).
#
# Переменные окружения (все необязательные):
#   MOCKUP_BASE  — адрес уже запущенного сервера; если не задан, сервер поднимается на свободном порту сам;
#   MOCKUP_PORT, CDP_PORT — порты сервера и отладки Chrome (если заданы окружением, используются как есть);
#   CHROME       — путь к Chrome;
#   PLAYWRIGHT_DIR — каталог пакета playwright (обязателен для шагов ui7-*: без него эти шаги падают, и прогон не пройден);
#   VIBESTUDIO_REPO — путь к репозиторию VibeStudio: шаг docs дополнительно сверяет утверждения листов о коде с репозиторием;
#   STEPS_FILE, EXPECTED_FILE, RESULTS_ROOT — для самопроверки обвязки (tests/selftest.mjs).
cd "$(dirname "$0")" || exit 1
HERE=$(pwd)
STEPS_FILE="${STEPS_FILE:-$HERE/steps.txt}"
EXPECTED_FILE="${EXPECTED_FILE:-$HERE/expected.json}"
RESULTS_ROOT="${RESULTS_ROOT:-$HERE/results}"
RUN_ID="run-$(date +%Y%m%d-%H%M%S)-$$"
export RUN_ID RESULTS_ROOT HERE
SRV_PID=""
cleanup() { [ -n "$SRV_PID" ] && kill "$SRV_PID" 2>/dev/null; }
trap cleanup EXIT INT TERM

if [ ! -f "$STEPS_FILE" ]; then echo "НЕТ СПИСКА ШАГОВ: $STEPS_FILE"; exit 2; fi
if [ ! -s "$STEPS_FILE" ]; then echo "ПУСТОЙ СПИСОК ШАГОВ: прогон не выполнялся"; exit 2; fi

if [ -z "$MOCKUP_BASE" ]; then
  if [ -z "$MOCKUP_PORT" ] || [ -z "$CDP_PORT" ]; then
    PORTS=$(python3 -I -c "
import socket
ps=[]
for i in range(2):
    s=socket.socket(); s.bind(('127.0.0.1',0)); ps.append(s.getsockname()[1]); s.close()
print(*ps)") || { echo "Не удалось выбрать свободные порты"; exit 2; }
    [ -z "$MOCKUP_PORT" ] && MOCKUP_PORT=${PORTS%% *}
    [ -z "$CDP_PORT" ] && CDP_PORT=${PORTS##* }
  fi
  export MOCKUP_PORT CDP_PORT
  (cd "$HERE/.." && exec python3 -m http.server "$MOCKUP_PORT" --bind 127.0.0.1 >/dev/null 2>&1) &
  SRV_PID=$!
  MOCKUP_BASE="http://127.0.0.1:$MOCKUP_PORT"
  export MOCKUP_BASE
  UP=0
  for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20; do
    if python3 -I -c "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('$MOCKUP_BASE/README.md',timeout=1).status==200 else 1)" 2>/dev/null; then UP=1; break; fi
    sleep 0.5
  done
  if [ "$UP" != 1 ]; then echo "Сервер не поднялся на $MOCKUP_BASE"; exit 2; fi
else
  export MOCKUP_BASE
fi
[ -n "$CDP_PORT" ] && export CDP_PORT
echo "Прогон $RUN_ID · сервер $MOCKUP_BASE · порт CDP ${CDP_PORT:-9333}"

if [ -d "$RESULTS_ROOT" ]; then rm -rf "$RESULTS_ROOT.prev"; mv "$RESULTS_ROOT" "$RESULTS_ROOT.prev"; fi
mkdir -p "$RESULTS_ROOT/legacy" || exit 2
: > "$RESULTS_ROOT/steps.rc"
FAILED=0; N=0
while IFS='|' read -r ID CMD; do
  case "$ID" in ''|\#*) continue;; esac
  PRE=0; case "$ID" in \!*) PRE=1; ID=${ID#!};; esac
  N=$((N+1))
  echo ""; echo "=== $ID ==="
  RESULTS_DIR="$RESULTS_ROOT" sh -c "cd \"$HERE\" && $CMD" </dev/null
  RC=$?
  echo "$ID $RC" >> "$RESULTS_ROOT/steps.rc"
  if [ "$RC" -ne 0 ]; then
    FAILED=$((FAILED+1)); echo "ШАГ НЕ ПРОЙДЕН: $ID (код $RC)"
    if [ "$PRE" = 1 ]; then echo "Обязательный шаг не выполнен, прогон прерван."; echo "ПРОГОН НЕ ПРОЙДЕН"; exit 1; fi
  fi
done < "$STEPS_FILE"
if [ "$N" -eq 0 ]; then echo "В списке нет ни одного шага: прогон пустой."; echo "ПРОГОН НЕ ПРОЙДЕН"; exit 2; fi

echo ""; echo "=== Проверка полноты прогона ==="
node "$HERE/verify-run.mjs" --expected "$EXPECTED_FILE" --results "$RESULTS_ROOT" --run-id "$RUN_ID"
VRC=$?
if [ "$FAILED" -ne 0 ] || [ "$VRC" -ne 0 ]; then echo "ПРОГОН НЕ ПРОЙДЕН: шагов с ошибкой $FAILED, проверка полноты $VRC"; exit 1; fi
echo "ПРОГОН ПРОЙДЕН: все шаги выполнены, результаты этого прогона ($RUN_ID) полные"
exit 0
