// Измерение значений для предложений --color-scrim и фон строк diff (node tests/tokens5.mjs → tests/tokens5.json)
import fs from 'node:fs';
import { launch, openPage } from './cdp.mjs';
const MEASURE = `(() => {
  const parse = (s) => { const m = s.match(/rgba?\\(([^)]+)\\)/); if (!m) return null; const p = m[1].split(',').map(x => parseFloat(x)); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; };
  const lum = (c) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
  const cr = (a, b) => { const l1 = lum(a), l2 = lum(b); return +(((Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05)).toFixed(2)); };
  const hex = (c) => '#' + c.map(v => Math.round(v).toString(16).padStart(2, '0')).join('');
  const root = document.querySelector('.app'); const cs = getComputedStyle(root);
  const tok = (n) => { const c = parse(cs.getPropertyValue(n).trim().startsWith('#') ? (() => { const h = cs.getPropertyValue(n).trim(); return 'rgb(' + [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)).join(',') + ')'; })() : cs.getPropertyValue(n)); return c ? [c.r, c.g, c.b] : null; };
  const T = {}; ['--color-bg', '--color-surface', '--color-surface-sunken', '--color-border', '--color-text', '--color-text-muted', '--color-success', '--color-danger'].forEach(n => T[n] = tok(n));
  const out = { tokens: Object.fromEntries(Object.entries(T).map(([k, v]) => [k, hex(v)])) };
  const sc = document.querySelector('.scrim');
  if (sc) { const s = getComputedStyle(sc); const bg = parse(s.backgroundColor); const a = +(parseFloat(s.opacity) * bg.a).toFixed(4); /* версия 17: прозрачность в самом --color-scrim, opacity 1 */
    out.scrim = { background: s.backgroundColor, opacity: a, hex: hex([bg.r, bg.g, bg.b]), rgba: 'rgba(' + [bg.r, bg.g, bg.b].join(',') + ',' + a + ')' };
    const mix = (fg, bgc) => fg.map((v, i) => v * a + bgc[i] * (1 - a));
    const over = (name) => mix([bg.r, bg.g, bg.b], T[name]);
    const dlg = document.getElementById('dlg'); const dbg = parse(getComputedStyle(dlg).backgroundColor); const dc = [dbg.r, dbg.g, dbg.b];
    const bsurf = over('--color-surface'), bsunk = over('--color-surface-sunken'), bbg = over('--color-bg');
    out.scrim.composite = { 'над surface': hex(bsurf), 'над surface-sunken': hex(bsunk), 'над bg': hex(bbg) };
    out.scrim.dialogSurface = hex(dc);
    out.scrim.contrast = { 'поверхность окна к затемнённому surface-sunken (боковая панель)': cr(dc, bsunk), 'поверхность окна к затемнённому bg': cr(dc, bbg), 'граница окна к затемнённому surface-sunken': cr(T['--color-border'], bsunk), 'текст text к затемнённому bg (фон за окном)': cr(mix([bg.r, bg.g, bg.b], T['--color-text']), bbg) };
    out.scrim.dialogTextMin = cr(T['--color-text-muted'], dc); }
  const add = document.querySelector('.dl.add'); const del = document.querySelector('.dl.del'); const ctx = document.querySelector('.dl:not(.add):not(.del)'); const hk = document.querySelector('.hk');
  if (add && del && ctx && hk) { const g = (e) => parse(getComputedStyle(e).backgroundColor); const gb = (e) => parse(getComputedStyle(e).borderLeftColor); const col = (e) => parse(getComputedStyle(e).color);
    const A = g(add), D = g(del), C = g(ctx);
    const rowBg = (e) => { const c = g(e); return c && c.a > 0.5 ? [c.r, c.g, c.b] : T['--color-bg']; };
    out.diff = { addBg: hex(rowBg(add)), delBg: hex(rowBg(del)), ctxBg: hex(rowBg(ctx)), hunkBg: hex(rowBg(hk)), pageBg: hex(T['--color-bg']),
      addBorderLeft: hex([gb(add).r, gb(add).g, gb(add).b]), delBorderLeft: hex([gb(del).r, gb(del).g, gb(del).b]),
      contrast: { 'текст в строке add': cr(T['--color-text'], rowBg(add)), 'текст в строке del': cr(T['--color-text'], rowBg(del)), 'знак + (success) на фоне add': cr(T['--color-success'], rowBg(add)), 'знак − (danger) на фоне del': cr(T['--color-danger'], rowBg(del)), 'номера строк (text-muted) на фоне add': cr(T['--color-text-muted'], rowBg(add)), 'полоса слева add к bg страницы (не текст, 3:1)': cr(T['--color-success'], T['--color-bg']), 'полоса слева del к bg страницы (не текст, 3:1)': cr(T['--color-danger'], T['--color-bg']), 'фон add к фону контекстной строки (1:1 без различия)': cr(rowBg(add), rowBg(ctx)) } }; }
  return out;
})()`;
let c = null, crashErr = null; const res = {};
try {
  c = await launch();
  for (const [key, name] of [['dark-dialog', 'E-DbErr-Dialog-Dark'], ['light-dialog', 'E-DbErr-Active-Light'], ['dark-diff', 'R-Review-Dark'], ['light-diff', 'T-Review-Light']]) {
    const pg = await openPage(c.port, (process.env.MOCKUP_BASE || 'http://127.0.0.1:8765') + '/project/' + name + '.dc.html', 1440, 900); await pg.wait(1800);
    res[key] = await pg.ev(MEASURE); await pg.close();
  }
} catch (e) { crashErr = e; console.log('АВАРИЙНОЕ ЗАВЕРШЕНИЕ: ' + (e && e.message || e)); } finally { if (c) c.close(); }
// измерение считается выполненным, только если получены все четыре набора значений
const complete = !crashErr && ['dark-dialog', 'light-dialog'].every(k => res[k] && res[k].scrim) && ['dark-diff', 'light-diff'].every(k => res[k] && res[k].diff);
const status = crashErr ? 'crashed' : complete ? 'passed' : Object.keys(res).length ? 'incomplete' : 'empty';
const rd = process.env.RESULTS_DIR || new URL('./results/', import.meta.url).pathname; fs.mkdirSync(rd, { recursive: true });
fs.writeFileSync(new URL('./tokens5.json', import.meta.url), JSON.stringify(res, null, 1));
fs.writeFileSync(rd + '/tokens5.status.json', JSON.stringify({ script: 'tokens5.mjs', status, runId: process.env.RUN_ID || '', crash: crashErr ? String(crashErr.message || crashErr) : null, at: new Date().toISOString() }, null, 1));
console.log(JSON.stringify(res, null, 1)); console.log('статус: ' + status);
process.exit(status === 'passed' ? 0 : crashErr ? 2 : 3);
