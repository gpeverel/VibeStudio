// минимальный CDP-клиент: node 24 имеет глобальный WebSocket
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const CHROME = process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const live = new Set();
process.on('exit', () => { for (const p of live) { try { p.kill('SIGKILL'); } catch (e) {} } });
// Запускает Chrome. Если браузер не запустился или не отвечает по CDP, бросает исключение: прогон не продолжается вхолостую.
export async function launch(port = +(process.env.CDP_PORT || 9333)) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chrome-prof-'));
  let startErr = null, exited = null;
  const proc = spawn(CHROME, ['--headless=new', `--remote-debugging-port=${port}`, `--user-data-dir=${dir}`, '--no-first-run', '--disable-gpu', '--hide-scrollbars', '--force-device-scale-factor=1', 'about:blank'], { stdio: 'ignore' });
  live.add(proc);
  proc.on('error', (e) => { startErr = e; });
  proc.on('exit', (code, sig) => { exited = { code, sig }; live.delete(proc); });
  let ready = false;
  for (let i = 0; i < 50 && !startErr && !exited; i++) { try { const r = await fetch(`http://127.0.0.1:${port}/json/version`); if (r.ok) { ready = true; break; } } catch (e) {} await new Promise(r => setTimeout(r, 200)); }
  const cleanup = () => { try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) {} };
  if (!ready) {
    try { proc.kill('SIGKILL'); } catch (e) {} cleanup();
    throw new Error('Chrome не запустился или не отвечает по CDP на порту ' + port + ' (' + CHROME + ')' + (startErr ? ': ' + startErr.message : exited ? ': процесс завершился с кодом ' + exited.code : ': нет ответа за 10 с'));
  }
  return { proc, port, close() { try { proc.kill('SIGKILL'); } catch (e) {} cleanup(); } };
}
export async function openPage(port, url, w = 1440, h = 900) {
  const t = await (await fetch(`http://127.0.0.1:${port}/json/new?about:blank`, { method: 'PUT' })).json();
  const ws = new WebSocket(t.webSocketDebuggerUrl); await new Promise(r => ws.addEventListener('open', r));
  let id = 0; const pend = new Map(); const logs = [];
  ws.addEventListener('message', (m) => { const d = JSON.parse(m.data); if (d.id && pend.has(d.id)) { pend.get(d.id)(d); pend.delete(d.id); } else if (d.method === 'Runtime.consoleAPICalled') logs.push(d.params.type + ': ' + d.params.args.map(a => a.value ?? a.description).join(' ')); else if (d.method === 'Runtime.exceptionThrown') logs.push('EXC: ' + (d.params.exceptionDetails.exception?.description || d.params.exceptionDetails.text)); });
  const send = (method, params = {}) => new Promise(r => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
  await send('Runtime.enable'); await send('Page.enable');
  await send('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: false });
  const nav = await send('Page.navigate', { url });
  if (nav.result && nav.result.errorText) throw new Error('Страница не открылась: ' + url + ' — ' + nav.result.errorText);
  const api = {
    send, logs, ws,
    async ev(expr) { const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }); if (r.result.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails.exception?.description || r.result.exceptionDetails)); return r.result.result.value; },
    async wait(ms) { await new Promise(r => setTimeout(r, ms)); },
    async shot(file, clip) { const p = { format: 'png' }; if (clip) p.clip = Object.assign({ scale: 1 }, clip); const r = await send('Page.captureScreenshot', p); fs.writeFileSync(file, Buffer.from(r.result.data, 'base64')); },
    async key(key, opts = {}) { const base = { key, code: opts.code || key, windowsVirtualKeyCode: opts.vk || 0, modifiers: opts.mod || 0 }; await send('Input.dispatchKeyEvent', Object.assign({ type: 'keyDown', text: opts.text }, base)); await send('Input.dispatchKeyEvent', Object.assign({ type: 'keyUp' }, base)); },
    async click(sel) { const r = await api.ev(`(()=>{const e=document.querySelector(${JSON.stringify(sel)});if(!e)return null;e.scrollIntoView({block:'center'});const b=e.getBoundingClientRect();return [b.x+b.width/2,b.y+b.height/2]})()`); if (!r) throw new Error('нет элемента ' + sel); await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: r[0], y: r[1], button: 'left', clickCount: 1 }); await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: r[0], y: r[1], button: 'left', clickCount: 1 }); },
    async close() { try { ws.close(); await fetch(`http://127.0.0.1:${port}/json/close/${t.id}`); } catch (e) {} }
  };
  return api;
}
