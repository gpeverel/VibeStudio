// Регрессии независимого ревью версии 14 (замечания B-01, B-02, A-09). Написан заново при подготовке версии 15.
// Каждый сценарий воспроизводит путь из замечания и имеет контрольный прогон без сбоя; на версии 14 ключевые из них не проходят.
import { init, done, crash, page, ok, section } from './tlib.mjs';
await init();
const body = (pg) => pg.text('body');
const setSel = (pg, id, v) => pg.ev(`(()=>{const e=document.getElementById(${JSON.stringify(id)});const set=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set;set.call(e,${JSON.stringify(v)});e.dispatchEvent(new Event('change',{bubbles:true}));})()`);
const chip = (pg) => pg.text('#status-chip');
const watchLive = (pg) => pg.ev(`(()=>{window.__live=[];const l=document.getElementById('live');new MutationObserver(()=>window.__live.push(l.innerText)).observe(l,{childList:true,characterData:true,subtree:true});return true})()`);
const liveLog = (pg) => pg.ev(`window.__live||[]`);
const region = (pg) => pg.ev(`(()=>{const a=document.activeElement; if(!a||a===document.body) return 'body'; return a.closest('#dlg')?'dlg':a.closest('#sb-panel')?'sb':a.closest('#in-panel')?'in':a.closest('main')?'main':'other'})()`);
const focusables = (pg, root) => pg.ev(`(()=>{const r=document.querySelector(${JSON.stringify(root)}); if(!r) return []; return [...r.querySelectorAll('button:not([disabled]),summary,a[href],input,textarea,select,[tabindex]')].filter(el=>el.tabIndex>=0&&el.getClientRects().length>0&&!el.closest('[inert]')).map(el=>el.id||el.tagName)})()`);
const focusId = (pg, id) => pg.ev(`(()=>{const e=document.getElementById(${JSON.stringify(id)}); if(!e) return false; e.focus(); return document.activeElement===e})()`);
try {
  // =====================================================================================================
  await section('B-01. Клавиатурный обход боковых панелей: закреплённая (≥1280) не удерживает фокус, модальная (<1280) удерживает');
  const STATES = [['D-Solo-Running', 'dark'], ['D-Solo-Running', 'light'], ['R-Review', 'dark'], ['R-Review', 'light'], ['N1-New', 'dark'], ['N1-New', 'light'], ['X-Restart-Banner', 'dark'], ['X-Restart-Banner', 'light']];
  for (const [base, theme] of STATES) {
    const lbl = base + '/' + theme;
    // --- ≥1280: обе панели закреплены и немодальны
    let pg = await page('T-Focus-' + base + '-' + theme + '-1440');
    const sbList = await focusables(pg, '#sb-panel');
    ok(lbl + ' · 1440: боковая панель закреплена (не role=dialog) и содержит элементы фокуса', sbList.length >= 3 && (await pg.ev(`!document.getElementById('sb-panel').getAttribute('role')`)), sbList);
    await focusId(pg, sbList[sbList.length - 1]); await pg.tab(false);
    let r = await region(pg);
    // следующим в порядке обхода стоит ручка ширины панели (button.grip, вне панели): это уже выход из панели; второй Tab ведёт в основную область
    const r1 = r; await pg.tab(false); const r2 = await region(pg);
    ok(lbl + ' · 1440: Tab с последнего элемента панели выходит из неё (ручка ширины), следующий Tab ведёт в основную область', r1 !== 'sb' && r1 !== 'body' && r2 === 'main', { r1, r2, last: sbList[sbList.length - 1] });
    await focusId(pg, sbList[0]); await pg.tab(true);
    r = await region(pg);
    ok(lbl + ' · 1440: Shift+Tab с первого элемента панели выходит из неё', r !== 'sb', r);
    // последовательный обход: из начала страницы фокус проходит панель, затем основную область, затем (если есть) инспектор
    await pg.ev(`document.activeElement&&document.activeElement.blur&&document.activeElement.blur(); window.scrollTo(0,0)`);
    const seq = []; for (let i = 0; i < sbList.length + 40; i++) { await pg.tab(false); seq.push(await region(pg)); }
    const firstMain = seq.indexOf('main'), lastSb = seq.lastIndexOf('sb');
    ok(lbl + ' · 1440: Tab последовательно проходит панель и переходит в основную область (без возврата в панель до конца основной области)', firstMain > 0 && firstMain <= sbList.length + 3 && !seq.slice(1, firstMain).slice(sbList.length).includes('sb') && !seq.slice(firstMain, firstMain + 6).includes('sb'), { firstMain, lastSb, seq: seq.slice(0, 16).join(',') });
    if (await pg.has('#in-panel')) {
      ok(lbl + ' · 1440: фокус доходит до инспектора', seq.includes('in'), seq.join(','));
      const inList = await focusables(pg, '#in-panel');
      await focusId(pg, inList[inList.length - 1]); await pg.tab(false);
      ok(lbl + ' · 1440: Tab с последнего элемента инспектора выходит из него', (await region(pg)) !== 'in', await region(pg));
      await focusId(pg, inList[0]); await pg.tab(true);
      ok(lbl + ' · 1440: Shift+Tab с первого элемента инспектора выходит из него', (await region(pg)) !== 'in', await region(pg));
    }
    await pg.close();
    // --- 1000: боковая панель — модальная накладка, инспектор закреплён
    pg = await page('T-Focus-' + base + '-' + theme + '-1000', 1000, 800);
    await pg.click('#btn-sb'); await pg.wait(250);
    const ov = await focusables(pg, '#sb-panel');
    ok(lbl + ' · 1000: панель проектов открыта как модальная (role=dialog, aria-modal)', (await pg.ev(`document.getElementById('sb-panel').getAttribute('role')==='dialog'&&document.getElementById('sb-panel').getAttribute('aria-modal')==='true'`)) && ov.length >= 3, ov);
    await focusId(pg, ov[ov.length - 1]); await pg.tab(false);
    ok(lbl + ' · 1000: модальная панель удерживает фокус: Tab с последнего ведёт на первый', (await region(pg)) === 'sb' && (await pg.active()) === ov[0], await pg.active());
    await focusId(pg, ov[0]); await pg.tab(true);
    ok(lbl + ' · 1000: Shift+Tab с первого ведёт на последний, фокус остаётся внутри', (await region(pg)) === 'sb' && (await pg.active()) === ov[ov.length - 1], await pg.active());
    await pg.esc(); await pg.wait(250);
    ok(lbl + ' · 1000: Esc закрывает панель, фокус возвращается на кнопку панели проектов', !(await pg.has('#sb-panel')) && (await pg.active()) === 'btn-sb', await pg.active());
    if (await pg.has('#in-panel')) {
      const inList = await focusables(pg, '#in-panel');
      await focusId(pg, inList[inList.length - 1]); await pg.tab(false);
      ok(lbl + ' · 1000: закреплённый инспектор не удерживает фокус', (await region(pg)) !== 'in', await region(pg));
    }
    await pg.close();
    // --- 640: обе панели — накладки
    pg = await page('T-Focus-' + base + '-' + theme + '-640', 640, 480);
    await pg.click('#btn-sb'); await pg.wait(250);
    const ov6 = await focusables(pg, '#sb-panel');
    await focusId(pg, ov6[ov6.length - 1]); await pg.tab(false);
    const a1 = await pg.active(); await focusId(pg, ov6[0]); await pg.tab(true);
    ok(lbl + ' · 640: модальная панель проектов удерживает фокус в обе стороны', a1 === ov6[0] && (await pg.active()) === ov6[ov6.length - 1], { a1, a2: await pg.active() });
    await pg.esc(); await pg.wait(250);
    ok(lbl + ' · 640: Esc закрывает панель проектов, фокус на её кнопке', !(await pg.has('#sb-panel')) && (await pg.active()) === 'btn-sb', await pg.active());
    if (await pg.has('#btn-in')) {
      await pg.click('#btn-in'); await pg.wait(250);
      const in6 = await focusables(pg, '#in-panel');
      await focusId(pg, in6[in6.length - 1]); await pg.tab(false); const b1 = await pg.active();
      await focusId(pg, in6[0]); await pg.tab(true);
      ok(lbl + ' · 640: модальный инспектор удерживает фокус в обе стороны', b1 === in6[0] && (await pg.active()) === in6[in6.length - 1], { b1, b2: await pg.active() });
      await pg.esc(); await pg.wait(250);
      ok(lbl + ' · 640: Esc закрывает инспектор, фокус на его кнопке', !(await pg.has('#in-panel')) && (await pg.active()) === 'btn-in', await pg.active());
    }
    await pg.close();
  }
  // настоящие модальные окна по-прежнему удерживают фокус и возвращают его после закрытия (обе темы)
  for (const [name, theme] of [['T-DbErr-Commit', 'тёмная'], ['T-Conflict', 'светлая']]) {
    const pg = await page(name);
    let stay = true; for (let i = 0; i < 18; i++) { await pg.tab(false); if (!(await region(pg)).startsWith('dlg')) stay = false; }
    for (let i = 0; i < 8; i++) { await pg.tab(true); if ((await region(pg)) !== 'dlg') stay = false; }
    ok('Модальное окно (' + theme + ' тема, ' + name + '): Tab и Shift+Tab не выводят фокус из окна', stay);
    await pg.esc(); await pg.wait(250);
    ok('Модальное окно (' + theme + ' тема, ' + name + '): Esc закрывает, фокус возвращается в сессию', !(await pg.has('#dlg')) && ['msg', 'btn-new', 'sess-title'].includes(await pg.active()), await pg.active());
    await pg.close();
  }

  // =====================================================================================================
  await section('B-02. Общая блокировка побочных эффектов при отказе записи состояния');
  const ticks = (pg) => pg.ev(`[...document.querySelectorAll('#ns-scroll input[type=checkbox]')].forEach(c=>{ if(!c.checked && /ns-(trust|consent)/.test(c.id)) c.click(); })`);
  // --- путь а: закрыть окно ошибки → новая сессия → подготовка
  let pg = await page('E-DbErr-Dialog-Dark');
  await pg.click('#dlg-close'); await pg.wait(300);
  await pg.click('#btn-new'); await pg.wait(500);
  ok('путь «а»: форма новой сессии открывается (открытие формы не нарушение)', await pg.has('#ns-create'));
  await ticks(pg); await pg.wait(250);
  ok('путь «а»: «Создать сессию» заблокирована даже при полностью заполненной форме', (await pg.dis('#ns-create')) === true);
  ok('путь «а»: причина блокировки видна над формой и в подвале, общий индикатор в заголовке', (await pg.text('#ns-dbw')).includes('создать сессию и пройти подготовку нельзя') && (await pg.text('#ns-dbwhy')).includes('во всех сессиях и проектах') && (await pg.text('#db-chip')).includes('Запись состояния недоступна'));
  await pg.ev(`document.getElementById('ns-create').click()`); await pg.wait(1800);
  ok('путь «а»: подготовка не началась и сессия не создана', !(await pg.has('#ns-ph')) && !(await body(pg)).includes('Создаём рабочую копию'));
  await pg.close();
  // контроль без сбоя
  pg = await page('N1-New-Dark');
  await ticks(pg); await pg.wait(250);
  ok('контроль «а» без сбоя БД: «Создать сессию» доступна при той же форме', (await pg.dis('#ns-create')) === false);
  await pg.click('#ns-create'); await pg.wait(700);
  ok('контроль «а»: подготовка началась', (await pg.text('#ns-ph')).includes('Создаём рабочую копию'));
  await pg.wait(5500);
  ok('контроль «а»: сессия создана', (await pg.text('#ns-ph')).includes('Сессия создана'), await pg.text('#ns-ph'));
  await pg.close();

  // --- путь б: «Тесты парсера CSV» → проверки
  pg = await page('E-DbErr-Dialog-Dark');
  await pg.click('#dlg-close'); await pg.wait(300);
  await pg.click('#sb-csv'); await pg.wait(500);
  ok('путь «б»: открыта сессия «Тесты парсера CSV», её статус не затёрт общей ошибкой', (await pg.text('#sess-title')).includes('Тесты парсера CSV') && (await chip(pg)).includes('Готово к ревью'), await chip(pg));
  ok('путь «б»: общая недоступность записи видна и в этой сессии (индикатор, предупреждение, примечание инспектора)', (await pg.text('#db-chip')).includes('Запись состояния недоступна') && (await body(pg)).includes('а не только в этой') && (await pg.has('#db-note')));
  await pg.click('#tab-checks'); await pg.wait(250);
  await pg.click('#cfg-open2'); await pg.wait(500);
  await pg.click('#dlg-cons'); await pg.wait(200);
  ok('путь «б»: форма команд проверок открывается, но «Сохранить и разрешить» заблокирована даже при согласии', (await pg.dis('#dlg-go')) === true && (await pg.text('#dlg-body')).includes('действие не будет выполнено'));
  ok('путь «б»: объяснение в подвале и кнопка «Состояние записи…» (действие восстановления)', (await pg.text('#dlg-foot')).includes('Запись состояния недоступна') && (await pg.dis('#dlg-dbstate')) === false);
  await pg.ev(`document.getElementById('dlg-go').click()`); await pg.wait(1200);
  ok('путь «б»: конфигурация не сохранена', !(await body(pg)).includes('Проверки сохранены'));
  await pg.close();
  pg = await page('T-DbOk-Checks');
  const nm = await pg.val('#cfg-n-0');
  if (!nm) { await pg.setVal('#cfg-n-0', 'lint'); await pg.setVal('#cfg-c-0', 'npm run lint'); }
  await pg.click('#dlg-cons'); await pg.wait(200);
  ok('контроль «б» без сбоя БД: «Сохранить и разрешить» доступна', (await pg.dis('#dlg-go')) === false);
  await pg.click('#dlg-go'); await pg.wait(1500);
  ok('контроль «б»: проверки сохранены', (await body(pg)).includes('Проверки сохранены'));
  await pg.close();

  // --- запуск проверок
  pg = await page('T-DbErr-Stale');
  await pg.click('#tab-checks'); await pg.wait(250);
  ok('запуск проверок: кнопка «Запустить проверки заново» видна, но заблокирована, причина указана', (await pg.dis('#rerun')) === true && (await pg.text('#rerun-why')).includes('заблокированы'));
  await pg.ev(`document.getElementById('rerun').click()`); await pg.wait(1800);
  ok('запуск проверок: проверки не запускались', !(await body(pg)).includes('Проверки выполняются'));
  await pg.close();
  pg = await page('T-DbRec-Stale');
  await pg.click('#tab-checks'); await pg.wait(250);
  ok('запуск проверок после восстановления записи: заблокирован до сверки', (await pg.dis('#rerun')) === true && (await pg.text('#rerun-why')).includes('сначала нужна сверка'));
  await pg.close();
  pg = await page('R-Stale-Dark');
  await pg.click('#tab-checks'); await pg.wait(250);
  ok('контроль без сбоя БД: «Запустить проверки заново» доступна', (await pg.dis('#rerun')) === false);
  await pg.click('#rerun'); await pg.wait(300);
  ok('контроль: проверки выполняются', (await body(pg)).includes('Проверки выполняются'));
  await pg.wait(1900);
  ok('контроль: проверки завершены', !(await pg.has('#rerun')));
  await pg.close();

  // --- добавление проекта
  pg = await page('T-DbErr-AddP');
  ok('добавление проекта: страница открывается с результатом проверки папки (чтение разрешено)', await pg.has('#ap-add'));
  ok('добавление проекта: «Добавить проект» заблокирована, причина названа, баннер над формой', (await pg.dis('#ap-add')) === true && (await pg.text('#ap-dbwhy')).includes('во всех сессиях и проектах') && !(await pg.has('#ap-dbw')));   // при показанном результате причина стоит у кнопки; баннер над папками нужен до проверки папки
  await pg.ev(`document.getElementById('ap-add').click()`); await pg.wait(500);
  ok('добавление проекта: проект не добавлен', !(await body(pg)).includes('Проект добавлен'));
  await pg.close();
  pg = await page('T-DbErr-AddPick');
  ok('добавление проекта до проверки папки: баннер над выбором папки назван причиной, проверка папки (чтение) доступна', (await pg.has('#ap-dbw')) && (await pg.dis('#ap-check')) !== null);
  await pg.close();
  pg = await page('T-DbOk-AddP');
  ok('контроль без сбоя БД: «Добавить проект» доступна', (await pg.dis('#ap-add')) === false);
  await pg.click('#ap-add'); await pg.wait(500);
  ok('контроль: проект добавлен', (await body(pg)).includes('Проект добавлен'));
  await pg.close();

  // --- отправка сообщений и отмена ожидания
  pg = await page('T-DbErr-Live');
  ok('сообщения: поле ввода и «Отправить» заблокированы', (await pg.dis('#msg')) === true && (await pg.dis('#send')) === true);
  await pg.ev(`(()=>{const m=document.getElementById('msg'); m.value='сообщение-при-отказе-записи'; m.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true})); const s=document.getElementById('send'); s.click();})()`); await pg.wait(400);
  ok('сообщения: даже программная отправка не добавляет сообщение в ленту', !(await body(pg)).includes('сообщение-при-отказе-записи'));
  await pg.close();
  pg = await page('T-DbErr-Queued');
  ok('отмена ожидания очереди: заблокирована, причина указана', (await pg.dis('#cancel-wait')) === true && (await pg.text('#cancel-why')).includes('заблокированы'));
  await pg.close();
  pg = await page('T-DbOk-Queued');
  ok('контроль без сбоя БД: «Отменить ожидание» доступна', (await pg.dis('#cancel-wait')) === false);
  await pg.click('#cancel-wait'); await pg.wait(400);
  ok('контроль: ожидание отменено', !(await pg.has('#cancel-wait')));
  await pg.close();

  // --- замечания ревью
  pg = await page('T-DbErr-Review');
  ok('ревью: «Отправить на доработку» заблокирована, причина видна, читать diff можно', (await pg.dis('#rv-send')) === true && (await pg.has('#rv-dbw')) && (await pg.has('.dl')));
  await pg.click('.dl.add'); await pg.wait(250);
  if (await pg.has('#rv-draft')) { await pg.setVal('#rv-draft', 'замечание при отказе записи'); await pg.wait(200); ok('ревью: «Добавить замечание» заблокирована', (await pg.dis('#rv-add')) === true); }
  else ok('ревью: форма замечания открыта', false);
  await pg.close();
  pg = await page('T-DbOk-Review');
  await pg.click('.dl.add'); await pg.wait(250);
  await pg.setVal('#rv-draft', 'замечание без отказа записи'); await pg.wait(200);
  ok('контроль без сбоя БД: «Добавить замечание» доступна', (await pg.dis('#rv-add')) === false);
  await pg.click('#rv-add'); await pg.wait(300);
  ok('контроль: замечание появилось, «Отправить на доработку» доступна', (await body(pg)).includes('замечание без отказа записи') && (await pg.dis('#rv-send')) === false);
  await pg.close();

  // --- права и правила
  pg = await page('T-DbErr-Denied');
  await pg.click('#perm-allow'); await pg.wait(350);
  ok('разрешения: окно «Разрешить действие» открывается, «Разрешить на следующий ход» заблокирована', (await pg.has('#dlg-go')) && (await pg.dis('#dlg-go')) === true && (await pg.text('#dlg-body')).includes('действие не будет выполнено'));
  await pg.close();
  pg = await page('T-DbErr-Rules');
  await pg.click('#rl-new'); await pg.wait(300);
  ok('правила: форма нового правила открывается, «Сохранить разрешение» заблокирована', (await pg.has('#dlg-rsave')) && (await pg.dis('#dlg-rsave')) === true);
  await pg.close();

  // --- диалоги изменяющих операций
  for (const [name, btn, label] of [['T-DbErr-Commit', 'dlg-go', 'коммит'], ['T-DbErr-Apply', 'dlg-go', 'применение: подготовка кандидата'], ['T-DbErr-Push', 'dlg-go', 'push'], ['T-DbErr-Discard', 'dlg-go', 'отбрасывание'], ['T-DbErr-Undo', 'dlg-go', 'отмена применения'], ['T-DbErr-Bypass', 'dlg-go', 'применение без проверок'], ['T-DbErr-Checks', 'dlg-go', 'команды проверок']]) {
    pg = await page(name);
    ok(label + ': окно открывается, главная кнопка заблокирована, причина и «Состояние записи…» на месте', (await pg.has('#' + btn)) && (await pg.dis('#' + btn)) === true && (await pg.dis('#dlg-dbstate')) === false && (await pg.text('#dlg-foot')).includes('Запись состояния недоступна'), { has: await pg.has('#' + btn), foot: await pg.text('#dlg-foot') });
    await pg.close();
  }
  pg = await page('T-DbRec-Commit');
  ok('коммит после восстановления записи: заблокирован до сверки, причина — нужна сверка', (await pg.dis('#dlg-go')) === true && (await pg.text('#dlg-foot')).includes('сначала нужна сверка'));
  await pg.close();
  pg = await page('T-DbOk-Commit');
  ok('контроль без сбоя БД: окно коммита без баннера блокировки и без кнопки «Состояние записи…»', !(await pg.has('#dlg-dbstate')) && !(await pg.text('#dlg-body')).includes('действие не будет выполнено'));
  await pg.close();
  pg = await page('T-DbErr-Restart');
  ok('восстановление после закрытия: «Продолжить работу» заблокирована', (await pg.has('#rs-resume')) && (await pg.dis('#rs-resume')) === true);
  await pg.close();
  pg = await page('T-DbErr-StopOk');
  ok('баннер «Остановлено»: «Продолжить работу» заблокирована при недоступной записи', (await pg.has('#stop-resume')) && (await pg.dis('#stop-resume')) === true, await pg.has('#stop-resume'));
  await pg.close();
  pg = await page('T-DbErr-PCtx');
  await pg.ev(`(()=>{const c=document.querySelector('#dlg input[type=checkbox]'); if(c&&!c.checked) c.click();})()`); await pg.wait(200);
  ok('новый диалог участника: «Начать новый диалог» заблокирована даже после подтверждения', (await pg.dis('#dlg-go')) === true);
  await pg.close();
  pg = await page('T-DbErr-ReconApply');
  ok('сверка прерванного применения при недоступной записи: «Выполнить сверку» заблокирована (результат нельзя записать)', (await pg.has('#dlg-run')) && (await pg.dis('#dlg-run')) === true && (await pg.dis('#dlg-dbstate')) === false);
  await pg.close();

  // --- предусмотренные действия восстановления и чтение остаются
  pg = await page('T-DbErr-Live');
  ok('восстановление: действие «Состояние записи…» в инспекторе и «Что произошло и что делать…» в ленте доступны', (await pg.dis('#act-dberr')) === false && (await pg.dis('#alert-act')) === false);
  await pg.click('#alert-act'); await pg.wait(350);
  ok('восстановление: в окне доступны «Проверить запись снова», расположение базы и сводка', (await pg.dis('#dlg-run')) === false && (await pg.has('#dlg-open-db')) && (await pg.has('#dlg-diag-show')));
  ok('окно ошибки называет, что заблокировано во всех сессиях, и что доступно для чтения', (await pg.text('#dlg-body')).includes('Что заблокировано во всех сессиях и проектах') && (await pg.text('#dlg-body')).includes('Читать сохранённую ленту, историю и результаты любой сессии'));
  await pg.esc(); await pg.wait(250);
  await pg.click('#tab-changes'); await pg.wait(200);
  await pg.click('#open-review'); await pg.wait(500);
  ok('чтение: просмотр результата (diff) открывается при отказе записи', (await pg.has('#rv-title')) && (await pg.has('.dl')));
  await pg.close();
  pg = await page('E-DbErr-Recovered-Light');
  await pg.click('#dlg-close').catch(() => {}); await pg.wait(250);
  ok('после восстановления записи: индикатор «нужна сверка», действие «Выполнить сверку…» доступно', (await pg.text('#status-chip')).includes('нужна сверка') || (await pg.text('#db-chip')).includes('нужна сверка'));
  await pg.close();

  // --- исторические статусы завершённых сессий
  pg = await page('E-DbErr-Dialog-Dark');
  await pg.click('#dlg-close'); await pg.wait(300);
  ok('текущая сессия с активным запуском: статус «Состояние не сохраняется» (исход запуска зависит от записи)', (await chip(pg)).includes('Состояние не сохраняется') && !(await pg.has('#db-chip')));
  for (const [id, want] of [['csv', 'Готово к ревью'], ['sql', 'Проверки не прошли'], ['onb', 'Применено']]) {
    await pg.click('#sb-' + id); await pg.wait(450);
    ok('сессия «' + id + '»: исторический статус «' + want + '» сохранён, рядом отдельный индикатор недоступности записи', (await chip(pg)).trim().endsWith(want) && (await pg.text('#db-chip')).includes('Запись состояния недоступна'), { chip: await chip(pg), db: await pg.text('#db-chip') });
    ok('сессия «' + id + '»: изменяющие действия инспектора и отправка заблокированы с объяснением', (await pg.dis('#send')) === true && (await pg.dis('#act-discard')) !== false && (await pg.text('#act-discard-why')).includes('заблокированы'), await pg.text('#act-discard-why'));
    ok('сессия «' + id + '»: в списке проектов её строка сохраняет прежний статус', (await pg.text('#sb-' + id)).includes(want));
  }
  await pg.click('#pj-parcel-service'); await pg.wait(200);
  await pg.click('#sb-par'); await pg.wait(450);
  ok('сессия в очереди (другой проект): отмена ожидания заблокирована', (await pg.dis('#cancel-wait')) === true && (await pg.text('#db-chip')).includes('Запись состояния недоступна'));
  await pg.close();

  // =====================================================================================================
  await section('A-09. Закрытие окна не прерывает обещанное сохранение результата применения');
  // сценарий из замечания: «Запись восстановлена» → «Повторить сохранение» → закрыть через ~150 мс → дождаться
  pg = await page('AR-Fail-Dark');
  ok('исходное состояние: Git-результат подтверждён, запись не сохранена; статус сессии это различает', (await chip(pg)).includes('Применено в Git · запись не сохранена') && (await body(pg)).includes('Результат применения не сохранён') && (await body(pg)).includes('Git-результат подтверждён'));
  await watchLive(pg);
  await setSel(pg, 'dlg-sim-db', 'up'); await pg.wait(200);
  await pg.click('#dlg-retry-rec'); await pg.wait(150);
  ok('после «Повторить сохранение»: идёт сверка и запись, повтор недоступен', (await pg.text('#dlg-body')).includes('Выполняется') && !(await pg.has('#dlg-retry-rec')));
  await pg.click('#dlg-close'); await pg.wait(300);
  ok('окно закрыто на 150 мс: в ленте виден ход записи, сессия по-прежнему «записано в Git, не сохранено»', !(await pg.has('#dlg')) && (await pg.has('#recop')) && (await chip(pg)).includes('запись не сохранена'));
  await pg.click('#recop-show'); await pg.wait(300);
  ok('повторное открытие окна во время записи: показан актуальный ход (идёт запись), второй операции нет', (await pg.text('#dlg-body')).includes('Выполняется') && !(await pg.has('#dlg-retry-rec')) && (await pg.dis('#dlg-view')) === true);
  await pg.wait(1700);
  ok('открытое окно само переходит в «Результат сохранён» без повторного нажатия', (await pg.text('#dlg-body')).includes('Результат сохранён') && (await pg.dis('#dlg-view')) === false, (await pg.text('#dlg-body')).slice(0, 200));
  await pg.click('#dlg-close'); await pg.wait(300);
  ok('цепочка отразилась в сессии: «Применено», ошибка записи снята, объявление для скринридера', (await chip(pg)) === 'Применено' && !(await pg.has('#db-chip')) && !(await pg.has('#recop')) && (await body(pg)).includes('Применено: c91d2e8'));
  const lv = await liveLog(pg);
  ok('вторая запись не начиналась: сообщение о повторе записи было ровно одно', lv.filter(x => x.includes('Сверка повторяется, затем результат сохраняется')).length === 1, lv);
  await pg.close();

  // закрытие на разных стадиях цепочки (запись после подтверждающей сверки), с открытым окном — контрольный прогон
  for (const [label, closeAt] of [['сразу после начала записи (стадия «подтверждено, сохраняется»)', 1300], ['в середине записи (стадия «сохраняется»)', 2100], ['после завершения записи', 3100]]) {
    pg = await page('T-Recon-Completed');
    await pg.click('#dlg-run');
    await pg.wait(closeAt);
    const closable = await pg.has('#dlg-close');
    if (closable) await pg.click('#dlg-close'); await pg.wait(250);
    await pg.wait(Math.max(0, 3600 - closeAt));
    ok('закрытие ' + label + ': запись завершилась, сессия «Применено»', closable && !(await pg.has('#dlg')) && (await chip(pg)) === 'Применено', { closable, chip: await chip(pg) });
    await pg.close();
  }
  pg = await page('T-Recon-Completed');
  await pg.click('#dlg-run'); await pg.wait(3600);
  ok('контрольный прогон с открытым окном: «Результат сохранён», «Посмотреть результат» доступно, сессия «Применено»', (await pg.text('#dlg-body')).includes('Результат сохранён') && (await pg.dis('#dlg-view')) === false && (await chip(pg)) === 'Применено');
  await pg.close();

  // отказ записи в ходе цепочки при закрытом окне: Git-результат подтверждён, сохранение — нет
  pg = await page('T-Recon-Fail');
  await pg.click('#dlg-run'); await pg.wait(1300); await pg.click('#dlg-close'); await pg.wait(2400);
  ok('отказ записи при закрытом окне: статус «Применено в Git · запись не сохранена», общий индикатор и блокировка', (await chip(pg)).includes('Применено в Git · запись не сохранена') && (await pg.has('#db-chip')) && (await pg.dis('#act-apply')) === true && (await pg.dis('#send')) === true, await chip(pg));
  ok('отказ записи: в ленте есть переход «Показать результат записи…», сессия не помечена применённой', (await pg.has('#alert-act2')) && !(await body(pg)).includes('Применено: c91d2e8'));
  await pg.click('#alert-act2'); await pg.wait(350);
  ok('окно показывает отдельно Git-результат (подтверждён) и сохранение (не удалось), доступно «Повторить сохранение»', (await pg.text('#dlg-body')).includes('Git-результат подтверждён') && (await pg.text('#dlg-body')).includes('Результат применения не сохранён') && (await pg.dis('#dlg-retry-rec')) === false);
  await setSel(pg, 'dlg-sim-db', 'up'); await pg.wait(150);
  await pg.click('#dlg-retry-rec'); await pg.wait(200); await pg.click('#dlg-close'); await pg.wait(1800);
  ok('повтор после восстановления записи при закрытом окне: «Применено», блокировка снята', (await chip(pg)) === 'Применено' && !(await pg.has('#db-chip')) && !(await pg.ev(`document.getElementById('msg').placeholder`)).includes('Состояние не сохраняется'), await chip(pg));
  await pg.close();

  // переход в другую сессию во время записи
  pg = await page('AR-Fail-Dark');
  await setSel(pg, 'dlg-sim-db', 'up'); await pg.wait(150);
  await pg.click('#dlg-retry-rec'); await pg.wait(150); await pg.click('#dlg-close'); await pg.wait(150);
  await pg.click('#sb-csv'); await pg.wait(450);
  ok('переход в «Тесты парсера CSV» во время записи: у той сессии блокировка пока действует', (await pg.text('#db-chip')).includes('Запись состояния недоступна') && (await pg.dis('#send')) === true);
  await pg.wait(1700);
  ok('запись завершилась в фоне: у «Тесты парсера CSV» блокировка снята, её статус «Готово к ревью» не изменился', !(await pg.has('#db-chip')) && (await chip(pg)).includes('Готово к ревью'), { db: await pg.has('#db-chip'), chip: await chip(pg) });
  ok('в списке проектов строка исходной сессии показывает «Применено»', (await pg.text('#sb-cur')).includes('Применено'), await pg.text('#sb-cur'));
  await pg.click('#sb-cur'); await pg.wait(450);
  ok('возврат в исходную сессию: «Применено», запись отражена', (await chip(pg)) === 'Применено' && (await body(pg)).includes('Применено: c91d2e8'));
  await pg.close();
  // отказ при переходе в другую сессию
  pg = await page('T-Recon-Fail');
  await pg.click('#dlg-run'); await pg.wait(1300); await pg.click('#dlg-close'); await pg.wait(150);
  await pg.click('#sb-csv'); await pg.wait(2300);
  ok('отказ записи при работе в другой сессии: там виден общий индикатор, исходная сессия помечена «запись не сохранена»', (await pg.has('#db-chip')) && (await pg.text('#sb-cur')).includes('запись не сохранена'), await pg.text('#sb-cur'));
  await pg.click('#sb-cur'); await pg.wait(450);
  ok('возврат в исходную сессию: «Применено в Git · запись не сохранена», переход к результату записи доступен', (await chip(pg)).includes('запись не сохранена') && (await pg.has('#alert-act2')), await chip(pg));
  await pg.close();
} catch (e) { crash(e); } finally { await done(); }
