// Проверка полноты и достоверности прогона: node tests/verify-run.mjs --expected expected.json --results каталог --run-id ID
// Прогон принимается как полный, только если для КАЖДОГО ожидаемого шага: шаг завершился с кодом 0, есть файл результата ЭТОГО прогона
// (runId совпадает, сохранённые результаты прежних прогонов не принимаются), статус passed, число проверок не меньше ожидаемого.
import fs from 'node:fs';
import path from 'node:path';
const arg = (n) => { const i = process.argv.indexOf('--' + n); return i > 0 ? process.argv[i + 1] : ''; };
const expFile = arg('expected'), dir = arg('results'), runId = arg('run-id');
const bad = [];
let exp;
try { exp = JSON.parse(fs.readFileSync(expFile, 'utf8')); } catch (e) { console.log('Нет описания ожидаемого набора: ' + expFile); process.exit(2); }
if (!exp.steps || !exp.steps.length) { console.log('Ожидаемый набор пуст: прогон не может считаться полным'); process.exit(2); }
const rcs = {};
try { fs.readFileSync(path.join(dir, 'steps.rc'), 'utf8').split('\n').filter(Boolean).forEach(l => { const [id, rc] = l.split(' '); rcs[id] = +rc; }); } catch (e) { bad.push('нет steps.rc'); }
const rows = [];
for (const st of exp.steps) {
  const why = [];
  if (!(st.id in rcs)) why.push('шаг не выполнялся'); else if (rcs[st.id] !== 0) why.push('код ' + rcs[st.id]);
  let r = null;
  if (st.result) {
    try { r = JSON.parse(fs.readFileSync(path.join(dir, st.result), 'utf8')); } catch (e) { why.push('нет результата ' + st.result); }
    if (r) {
      if (r.runId !== runId) why.push('результат от другого прогона (' + (r.runId || 'без runId') + ')');
      if (r.status !== 'passed') why.push('статус ' + r.status);
      if (st.minChecks != null) { const n = (r.pass || 0) + (r.fail || 0); if (n < st.minChecks) why.push('проверок ' + n + ' из ожидаемых ' + st.minChecks); if (r.fail) why.push('не пройдено ' + r.fail); }
      if (st.minPlatforms != null && (r.scanned || 0) < st.minPlatforms) why.push('платформ ' + (r.scanned || 0) + ' из ожидаемых ' + st.minPlatforms);
      if (st.maxIssues != null && (r.issues || []).length > st.maxIssues) why.push('замечаний ' + r.issues.length);
    }
  }
  rows.push((why.length ? 'НЕТ ' : 'ок  ') + st.id.padEnd(10) + (r && r.pass != null ? (r.pass + '/' + ((r.pass || 0) + (r.fail || 0))) : r && r.scanned != null ? ('платформ ' + r.scanned) : '').padEnd(14) + why.join('; '));
  if (why.length) bad.push(st.id + ': ' + why.join('; '));
}
console.log(rows.join('\n'));
const extra = Object.keys(rcs).filter(id => !exp.steps.some(s => s.id === id) && rcs[id] !== 0 && id !== 'boards');
if (extra.length) bad.push('сбой шагов вне ожидаемого набора: ' + extra.join(', '));
if (bad.length) { console.log('\nПрогон неполный или неуспешный:\n - ' + bad.join('\n - ')); process.exit(1); }
console.log('\nВсе ожидаемые шаги выполнены в этом прогоне и успешны (' + exp.steps.length + ').');
