// Сценарные проверки версии 14. Написаны заново при подготовке версии 14; не являются восстановленным прежним набором.
import { init, done, crash, page, ok, section } from './tlib.mjs';
await init();
const body = (pg) => pg.text('body');
try {
  await section('A1. Подтверждённое применение: автоматическая запись (SPEC §6)');
  let pg = await page('T-Recon-Completed');
  ok('до сверки кнопки «Записать результат» нет', !(await body(pg)).includes('Записать результат'));
  await pg.click('#dlg-run'); await pg.wait(2100);
  let t = await pg.text('#dlg-body');
  ok('сверка → подтверждено → сохраняется (идёт запись)', t.includes('Результат сохраняется') && t.includes('Выполняется'), t.slice(0, 300));
  ok('«Посмотреть результат» недоступно, пока идёт запись', (await pg.dis('#dlg-view')) === true);
  await pg.wait(2200);
  t = await pg.text('#dlg-body');
  ok('результат сохранён: четыре шага готовы', t.includes('Результат сохранён') && (t.match(/Готово/g) || []).length >= 4, t.slice(0, 400));
  ok('кнопки «Записать результат» нет и после сохранения', !(await body(pg)).includes('Записать результат') && !(await pg.has('#dlg-rec')));
  ok('доступны «Посмотреть результат» и «Вернуться к сессии»', (await pg.dis('#dlg-view')) === false && (await pg.dis('#dlg-close')) === false);
  ok('нет запроса дополнительного разрешения (нет флажков)', !(await pg.has('#dlg-body input[type=checkbox]')));
  await pg.click('#dlg-view'); await pg.wait(400);
  ok('«Посмотреть результат» закрывает окно и открывает вкладку «Изменения»', !(await pg.has('#dlg')) && (await pg.ev(`document.getElementById('tab-changes').getAttribute('aria-selected')`)) === 'true');
  ok('сессия помечена применённой', (await pg.text('header')).includes('Применено') || (await body(pg)).includes('Применено'));
  ok('нет сообщения о незаписанном состоянии', !(await body(pg)).includes('Состояние не сохраняется'));
  await pg.close();

  await section('A2. Запись результата не удалась (отдельный факт)');
  pg = await page('T-Recon-Fail');
  await pg.click('#dlg-run'); await pg.wait(3800);
  t = await pg.text('#dlg-body');
  ok('Git подтверждён отдельно от записи', t.includes('Git-результат подтверждён') && t.includes('Результат применения не сохранён'), t.slice(0, 200));
  ok('шаги: сохранение — ошибка, сохранён — не выполнено', t.includes('Ошибка') && t.includes('Не выполнено'));
  ok('полного успеха нет: «Результат сохранён: применение» отсутствует', !t.includes('Результат сохранён: применение'));
  ok('«Посмотреть результат» не предлагается', !(await pg.has('#dlg-view')));
  ok('есть «Повторить сохранение», «Состояние записи…», «Вернуться к сессии»', (await pg.has('#dlg-retry-rec')) && (await pg.has('#dlg-dbinfo')) && (await pg.has('#dlg-close')));
  await pg.click('#dlg-retry-rec'); await pg.wait(1300);
  t = await pg.text('#dlg-body');
  ok('повтор при недоступной базе: попытка №2, исход тот же', t.includes('Попытка №2') && t.includes('Результат применения не сохранён'), t.slice(0, 200));
  await pg.setVal('#dlg-sim-db', 'up'); await pg.wait(100);
  await pg.click('#dlg-retry-rec'); await pg.wait(500);
  t = await pg.text('#dlg-body');
  ok('после восстановления записи сначала повторная сверка', t.includes('Повторная сверка перед записью'), t.slice(0, 300));
  await pg.wait(1500);
  t = await pg.text('#dlg-body');
  ok('затем результат сохранён', t.includes('Результат сохранён: применение'), t.slice(0, 200));
  await pg.click('#dlg-close'); await pg.wait(300);
  ok('после сохранения блокировки записи нет: сессия применена, баннера ошибки нет', !(await body(pg)).includes('Состояние не сохраняется') && (await body(pg)).includes('Применено'));
  await pg.close();
  // закрыть окно при ошибке: сессия блокируется
  pg = await page('T-Recon-Fail');
  await pg.click('#dlg-run'); await pg.wait(3800); await pg.click('#dlg-close'); await pg.wait(300);
  ok('при ошибке записи сессия заблокирована: сообщение недоступно', (await pg.dis('#msg')) === true && (await pg.dis('#send')) === true);
  ok('статус сессии «Состояние не сохраняется»', (await body(pg)).includes('Состояние не сохраняется'));
  ok('действия применения/коммита/отбрасывания заблокированы', (await pg.dis('#act-apply')) === true && (await pg.dis('#act-commit')) === true && (await pg.dis('#act-discard')) === true);
  await pg.close();

  await section('A3. Другие исходы сверки сохранены');
  pg = await page('T-Recon-NotStarted');
  await pg.click('#dlg-run'); await pg.wait(1500);
  t = await pg.text('#dlg-body');
  ok('«не начиналось»: повтор не запускается сам, есть подготовка заново', t.includes('Применение не начиналось') && (await pg.has('#dlg-prep')) && !t.includes('Результат сохраняется'));
  await pg.close();
  pg = await page('T-Recon-Ambiguous');
  await pg.click('#dlg-run'); await pg.wait(1500);
  t = await pg.text('#dlg-body');
  ok('«неоднозначно»: блокировка, нет записи и «считать применённым»', t.includes('Состояние неоднозначно') && !t.includes('Считать применённым') && !t.includes('Результат сохраняется') && (await pg.has('#dlg-manual')));
  await pg.close();
  pg = await page('T-Manual');
  await pg.setVal('#dlg-sim', 'done'); await pg.click('#dlg-run'); await pg.wait(1300);
  t = await pg.text('#dlg-body');
  ok('ручной разбор → завершено: сохраняется автоматически', t.includes('Результат сохраняется') && !t.includes('Записать результат'), t.slice(0, 300));
  await pg.wait(2300);
  ok('ручной разбор: результат сохранён', (await pg.text('#dlg-body')).includes('Результат сохранён: применение'));
  await pg.close();
  pg = await page('T-Manual');
  await pg.setVal('#dlg-sim', 'revert'); await pg.click('#dlg-run'); await pg.wait(1300);
  ok('ручной разбор → не начиналось: нет автоматической записи', (await pg.text('#dlg-body')).includes('Применение не начиналось') && !(await pg.text('#dlg-body')).includes('Результат сохраняется'));
  await pg.close();

  await section('B1. Ошибка записи состояния (SPEC §4)');
  pg = await page('T-DbErr-Live');
  ok('баннер и статус', (await body(pg)).includes('Состояние не сохраняется') && (await pg.has('#alert-act')));
  ok('поле сообщения и отправка заблокированы', (await pg.dis('#msg')) === true && (await pg.dis('#send')) === true);
  ok('изменяющие действия заблокированы, остановка вручную недоступна', (await pg.dis('#act-apply')) === true && (await pg.dis('#act-commit')) === true && (await pg.dis('#act-discard')) === true && (await pg.dis('#stop-btn')) === true);
  ok('участники: исход остановки различим (подтверждена / не подтверждена)', (await body(pg)).includes('Остановка подтверждена') && (await body(pg)).includes('Остановка не подтверждена'));
  ok('последнее сохранённое состояние помечено как неактуальное', (await pg.text('#db-note')).includes('последнее сохранённое состояние'));
  ok('в ленте нет «выполняется» у прерванных инструментов', !(await pg.ev(`!!Array.from(document.querySelectorAll('main *')).find(e=>e.children.length===0&&e.textContent.trim()==='выполняется')`)));
  await pg.click('#alert-act'); await pg.wait(400);
  t = await pg.text('#dlg-body');
  ok('окно: сообщение, остановка по участникам, блокировки, порядок после восстановления', t.includes('Не удалось сохранить состояние') && t.includes('Безопасная остановка') && t.includes('Что заблокировано') && t.toLowerCase().includes('сначала сверка'));
  ok('автоматического повтора нет: операции не повторяются', t.includes('автоматически не повторяются'));
  await pg.click('#dlg-run'); await pg.wait(1400);
  ok('проверка записи при недоступной базе: исход прежний', (await pg.text('#dlg-body')).includes('Проверка записи №1') && (await pg.text('#dlg-title')).includes('Состояние не сохраняется'));
  await pg.setVal('#dlg-sim-db', 'up'); await pg.click('#dlg-run'); await pg.wait(1400);
  ok('запись восстановлена: нужна сверка', (await pg.text('#dlg-title')).includes('нужна сверка'));
  await pg.click('#dlg-close'); await pg.wait(300);
  ok('после восстановления записи, до сверки, сообщения всё ещё заблокированы', (await pg.dis('#msg')) === true && (await body(pg)).includes('Запись восстановлена: нужна сверка'));
  await pg.click('#alert-act'); await pg.wait(300);
  await pg.click('#dlg-recon'); await pg.wait(1600);
  ok('сверка выполнена: итоги, прерванный ход не повторяется', (await pg.text('#dlg-body')).includes('Итоги сверки') && (await pg.text('#dlg-body')).includes('автоматически не повторяется'));
  await pg.click('#dlg-done'); await pg.wait(300);
  ok('после сверки работа разблокирована', (await pg.dis('#msg')) === false && !(await body(pg)).includes('Состояние не сохраняется'));
  await pg.close();
  pg = await page('T-DbErr-Unsaved');
  await pg.click('#alert-act'); await pg.wait(300);
  ok('незаписанное применение показано отдельно', (await pg.text('#dlg-body')).includes('Применение завершено в Git, но не записано'));
  await pg.setVal('#dlg-sim-db', 'up'); await pg.click('#dlg-run'); await pg.wait(1400); await pg.click('#dlg-recon'); await pg.wait(1600);
  ok('сверка записывает установленный результат', (await pg.text('#dlg-body')).includes('результат записан в историю'));
  await pg.click('#dlg-done'); await pg.wait(300);
  ok('сессия применена после сверки', (await body(pg)).includes('Применено'));
  await pg.close();

  await section('C1. Рабочая копия без сессии (SPEC §9)');
  pg = await page('T-Orphan-Live');
  ok('в списке проектов есть уведомление', (await pg.has('#btn-orph')));
  await pg.click('#btn-orph'); await pg.wait(400);
  t = await pg.text('#dlg-body');
  ok('показаны владелец, состояние и причины неопределённости', t.includes('Владелец не установлен') && t.includes('Незакоммиченное: 3 файла') && t.includes('Неопубликованное: 2 коммита') && t.includes('Причины неопределённости'));
  ok('нет кнопок удаления, присвоения и очистки', !/Удалить|Очистить|Присвоить|Передать|Привязать/.test(await pg.text('.dlg-foot') + await pg.text('#dlg-body').then(x => x.split('\n').filter(l => l.length < 40).join(' '))));
  ok('явно сказано, чего приложение не делает', t.includes('Не удаляет копию'));
  await pg.click('#dlg-orph-info'); await pg.wait(200);
  ok('сведения раскрываются', (await body(pg)).includes('Путь (realpath)'));
  await pg.click('#dlg-open-orph'); await pg.wait(200);
  ok('открытие расположения: запрос в Finder', (await pg.text('#dlg-body')).includes('Запрошено открытие в Finder'));
  await pg.click('#dlg-run'); await pg.wait(1400);
  ok('повторная сверка: исход прежний, сверка №2', (await pg.text('#dlg-body')).includes('сверка №2') || (await pg.text('#dlg-body')).includes('Сверка №2'));
  await pg.setVal('#dlg-sim', 'owner'); await pg.click('#dlg-run'); await pg.wait(1400);
  ok('найден владелец: копия не передана и не удалена', (await pg.text('#dlg-body')).includes('Владелец установлен') && (await pg.text('#dlg-body')).includes('Копия никуда не передана и не удалена'));
  await pg.esc(); await pg.wait(200);
  ok('Esc закрывает окно', !(await pg.has('#dlg')));
  await pg.close();

  await section('D1. Недоступный CLI-диалог участника Swarm');
  pg = await page('T-PCtx-Live');
  ok('участник «Тесты» назван, статус не общий успех', (await body(pg)).includes('Тесты: диалог CLI недоступен') && (await body(pg)).includes('Диалог «Тесты» недоступен'));
  ok('остальные участники остаются видимы и подтверждены', (await body(pg)).includes('Исследователь') && (await body(pg)).includes('Реализация') && (await body(pg)).includes('Документация'));
  const before = await pg.ev(`document.querySelectorAll('[id^="m-"]').length`);
  await pg.click('#alert-act'); await pg.wait(400);
  t = await pg.text('#dlg-body');
  ok('окно: потеря контекста, остальные диалоги сохранены, ход не запускается', t.includes('потеряет контекст') && t.includes('Диалог CLI сохранён') && t.includes('Ход при этом не запускается'));
  ok('начать нельзя без подтверждения', (await pg.dis('#dlg-go')) === true);
  await pg.click('#dlg-ack'); await pg.click('#dlg-go'); await pg.wait(1100);
  t = await pg.text('#dlg-body');
  ok('новый диалог создан, ход не запущен', t.includes('Ход не запущен') && t.includes('диалоги остальных участников не менялись'));
  await pg.click('#dlg-done'); await pg.wait(300);
  ok('в ленте отмечено создание, ход не начат; сообщений агентов не добавилось', (await body(pg)).includes('Ход не начат') && (await pg.ev(`document.querySelectorAll('[id^="m-"]').length`)) === before);
  ok('статус «Работает» не выставлен автоматически', !(await pg.text('header')).includes('Работает'));
  await pg.close();
  pg = await page('Q-PCtx-Restart-Light');
  ok('окно восстановления: диалоги участников и действие', (await body(pg)).includes('Диалоги участников') && (await pg.has('#rs-pctx')));
  await pg.close();

  await section('E1. Собственные правила (SPEC §3)');
  pg = await page('T-Denied-None');
  await pg.click('#perm-rules'); await pg.wait(300);
  ok('список правил: «Новое правило…» и «Разрешить…»', (await pg.has('#rl-new')) && (await pg.has('#dlg-allow')));
  await pg.click('#rl-new'); await pg.wait(300);
  t = await pg.text('#dlg-body');
  ok('форма: тип, инструмент, шаблон, срок и область, «Сейчас / После сохранения»', t.includes('Тип правила') && t.includes('Инструмент') && t.includes('Шаблон вызова') && t.includes('Срок и область') && t.includes('После сохранения'));
  ok('срок по умолчанию «на следующий ход»', await pg.ev(`document.querySelectorAll('input[name=rterm]')[0].checked`));
  await pg.setVal('#dlg-rpat', 'npm run build && rm -rf x'); await pg.wait(150);
  ok('shell-конструкции отклоняются, сохранить нельзя', (await pg.text('#dlg-body')).includes('Ошибка:') && (await pg.dis('#dlg-rsave')) === true);
  await pg.setVal('#dlg-rpat', '*'); await pg.wait(150);
  ok('слишком широкое разрешение отклоняется', (await pg.text('#dlg-body')).includes('Слишком широкое'));
  await pg.setVal('#dlg-rpat', ''); await pg.wait(150);
  ok('пустой шаблон отклоняется', (await pg.text('#dlg-body')).includes('Укажите шаблон'));
  await pg.setVal('#dlg-rpat', 'npm run build'); await pg.wait(150);
  ok('после исправления сохранение доступно', (await pg.dis('#dlg-rsave')) === false);
  await pg.click('#dlg-rsave'); await pg.wait(300);
  t = await pg.text('#dlg-body');
  ok('результат: было / стало, без автоповтора', t.includes('Было') && t.includes('Стало') && t.includes('Вызов не разрешён') && t.includes('Вызов разрешён') && t.includes('не запускался'));
  await pg.click('#dlg-rall'); await pg.wait(200);
  ok('новое разрешение видно в группе «на ход и на сессию»', (await body(pg)).includes('allow Bash(npm run build)') && (await body(pg)).includes('До конца следующего хода'));
  await pg.click('#dlg-close'); await pg.wait(300);
  ok('блок отказа отражает разрешение, участник сам не продолжает', (await body(pg)).includes('Разрешение добавлено') && (await body(pg)).toLowerCase().includes('продолжение — новый ход'));
  await pg.close();

  pg = await page('T-Denied-User');
  await pg.click('#perm-rules'); await pg.wait(300);
  ok('собственный запрет: «Изменить…» и «Удалить…»', (await pg.has('#rl-edit')) && (await pg.has('#rl-del')));
  await pg.click('#rl-new'); await pg.wait(300);
  await pg.click('#dlg-rsave'); await pg.wait(300);
  t = await pg.text('#dlg-body');
  ok('allow при действующем deny: не вступает в силу, deny приоритетнее', t.includes('Разрешение не вступило в силу') && t.includes('Вызов запрещён'));
  await pg.click('#dlg-rall'); await pg.wait(200);
  ok('в списке разрешение помечено как перекрытое', (await body(pg)).includes('Перекрыто запретом'));
  await pg.click('#rl-del'); await pg.wait(250);
  ok('удаление запрета требует явного подтверждения', (await pg.dis('#dlg-rdel')) === true && (await pg.text('#dlg-body')).includes('Сейчас') && (await pg.text('#dlg-body')).includes('После удаления'));
  await pg.click('#dlg-ack, #dlg-rack'); await pg.wait(100);
  ok('после подтверждения удаление доступно', (await pg.dis('#dlg-rdel')) === false);
  await pg.click('#dlg-rdel'); await pg.wait(300);
  t = await pg.text('#dlg-body');
  ok('удаление: было запрет → стало действует ранее созданное разрешение', t.includes('Запрет удалён') && t.includes('Вызов запрещён') && t.includes('Вызов разрешён'));
  await pg.click('#dlg-close'); await pg.wait(300);
  ok('участник сам не продолжил: блок отказа остаётся, новый ход запускает пользователь', (await pg.has('#perm-block')) && (await body(pg)).toLowerCase().includes('продолжение — новый ход'));
  await pg.close();

  pg = await page('T-Denied-User');
  await pg.click('#perm-rules'); await pg.wait(300);
  await pg.click('#rl-edit'); await pg.wait(250);
  ok('изменение запрета: форма с исходным шаблоном, тип не меняется', (await pg.val('#dlg-rpat')) === 'npm run build' && !(await pg.has('input[name=rtype]')));
  await pg.setVal('#dlg-rpat', 'npm run deploy'); await pg.wait(150);
  ok('срок «правило проекта» требует подтверждения', (await pg.dis('#dlg-rsave')) === true);
  await pg.click('#dlg-rack'); await pg.click('#dlg-rsave'); await pg.wait(300);
  ok('изменённый запрет больше не относится к вызову: «Вызов не разрешён»', (await pg.text('#dlg-body')).includes('Стало') && (await pg.text('#dlg-body')).includes('Вызов не разрешён'));
  await pg.close();

  pg = await page('T-Denied-Policy');
  await pg.click('#perm-rules'); await pg.wait(300);
  ok('внешняя политика: только просмотр, правки и удаления нет', !(await pg.has('#rl-edit')) && !(await pg.has('#rl-del')) && !(await pg.has('#rl-edit-r1')) && (await body(pg)).includes('Только просмотр'));
  await pg.click('#rl-new'); await pg.wait(250); await pg.click('#dlg-rsave'); await pg.wait(250);
  ok('allow против внешнего deny: вызов остаётся запрещён, политика не обходится', (await pg.text('#dlg-body')).includes('внешняя политика') && (await pg.text('#dlg-body')).includes('Вызов запрещён'));
  await pg.close();

  pg = await page('L-Rules-NewDeny-Light');
  ok('новый запрет: те же поля, срок по умолчанию «правило проекта»', (await pg.text('#dlg-title')).includes('Новый запрет') && await pg.ev(`document.querySelectorAll('input[name=rterm]')[2].checked`));
  await pg.close();

  await section('F1. Клавиатура и фокус в новых окнах');
  const inDlg = (pg) => pg.ev(`!!(document.activeElement && document.activeElement.closest('#dlg'))`);
  for (const [name, opener, label] of [['T-DbErr-Live', 'alert-act', 'ошибка записи'], ['T-Orphan-Live', 'btn-orph', 'рабочая копия без сессии'], ['T-PCtx-Live', 'alert-act', 'диалог участника'], ['T-Denied-None', 'perm-rules', 'правила']]) {
    pg = await page(name);
    await pg.ev(`document.getElementById('${opener}').focus()`); await pg.enter(); await pg.wait(350);
    ok(label + ': Enter открывает окно, фокус на заголовке', (await pg.active()) === 'dlg-title', await pg.active());
    let stay = true; for (let i = 0; i < 16; i++) { await pg.tab(); if (!(await inDlg(pg))) stay = false; }
    ok(label + ': Tab не выводит фокус из окна', stay);
    stay = true; for (let i = 0; i < 6; i++) { await pg.tab(true); if (!(await inDlg(pg))) stay = false; }
    ok(label + ': Shift+Tab не выводит фокус из окна', stay);
    await pg.esc(); await pg.wait(250);
    ok(label + ': Esc закрывает окно, фокус возвращается на кнопку, открывшую его', !(await pg.has('#dlg')) && (await pg.active()) === opener, await pg.active());
    await pg.close();
  }
  pg = await page('T-PCtx-Live');
  await pg.ev(`document.getElementById('alert-act').focus()`); await pg.enter(); await pg.wait(300);
  await pg.ev(`document.getElementById('dlg-ack').focus()`); await pg.key(' ', { code: 'Space', vk: 32, text: ' ' }); await pg.wait(150);
  ok('флажок подтверждения переключается пробелом, кнопка становится доступной', (await pg.dis('#dlg-go')) === false);
  await pg.close();

  await section('F2. Длинные значения');
  pg = await page('T-Denied-None');
  await pg.click('#perm-rules'); await pg.wait(250); await pg.click('#rl-new'); await pg.wait(250);
  const longPat = 'npm run ' + 'очень-длинное-имя-скрипта-'.repeat(8) + 'build';
  await pg.setVal('#dlg-rpat', longPat); await pg.wait(150);
  await pg.click('#dlg-rsave'); await pg.wait(250); await pg.click('#dlg-rall'); await pg.wait(250);
  ok('длинный шаблон правила переносится: нет горизонтальной прокрутки окна', await pg.ev(`(()=>{const b=document.getElementById('dlg-body');return b.scrollWidth<=b.clientWidth+1 && document.documentElement.scrollWidth<=innerWidth+1})()`));
  ok('длинный шаблон виден целиком в строке правила', (await pg.text('#rl-r1')).includes('build'));
  await pg.close();

  await section('F3. Малые окна: 640×480, 640×452 (область содержимого при стандартной рамке macOS), 500×360');
  for (const [w, h] of [[640, 480], [640, 452], [500, 360]]) {
    for (const [name, opener] of [['T-DbErr-Live', 'alert-act'], ['T-Orphan-Live', 'btn-orph'], ['T-PCtx-Live', 'alert-act'], ['T-Denied-None', 'perm-rules']]) {
      pg = await page(name + '-' + w + 'x' + h, w, h);
      if (!(await pg.has('#' + opener))) { await pg.ev(`document.getElementById('btn-sb')&&document.getElementById('btn-sb').click()`); await pg.wait(300); }
      await pg.ev(`(()=>{const e=document.getElementById('${opener}'); if(e){e.focus(); e.click();}})()`); await pg.wait(500);
      const r = await pg.ev(`(()=>{const d=document.getElementById('dlg'); if(!d) return null; const q=d.getBoundingClientRect(); const b=document.getElementById('dlg-body'); const btns=[...d.querySelectorAll('.dlg-foot button')]; return { inside: q.top>=-1&&q.bottom<=innerHeight+1&&q.left>=-1&&q.right<=innerWidth+1, noHx: b.scrollWidth<=b.clientWidth+1, foot: btns.every(x=>{const t=x.getBoundingClientRect();return t.bottom<=innerHeight+1&&t.top>=0}), nbtn: btns.length, bodyH: Math.round(b.clientHeight) } })()`);
      ok(w + '×' + h + ' · ' + name + ': окно открылось, помещается, кнопки подвала в пределах окна, горизонтальной прокрутки нет', !!r && r.inside && r.noHx && r.foot && r.nbtn > 0, r);
      await pg.close();
    }
  }
} catch (e) { crash(e); } finally { await done(); }
