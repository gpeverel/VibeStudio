// Сравнение отрисовки платформ двух версий (замечание: «проверь все изменённые экраны»): node tests/rvdiff.mjs <базовый_адрес_v14> <базовый_адрес_v15>
// Для каждой платформы просмотра (review/rv.json) снимает оба адреса при 1:1 и сравнивает пиксели. Пишет tests/results/rvdiff.json: изменённые, новые и совпавшие.
import fs from 'node:fs';
import crypto from 'node:crypto';
import { launch, openPage } from './cdp.mjs';
const [A, B] = process.argv.slice(2);
if (!A || !B) { console.error('нужны два адреса'); process.exit(3); }
const list = JSON.parse(fs.readFileSync(new URL('../review/compare.json', import.meta.url)));
const dirA = new URL('./shots/rvA/', import.meta.url).pathname, dirB = new URL('./shots/rvB/', import.meta.url).pathname;
fs.mkdirSync(dirA, { recursive: true }); fs.mkdirSync(dirB, { recursive: true });
const c = await launch(); const res = { same: [], changed: [], onlyNew: [] };
const shot = async (base, b, dir) => {
  const pg = await openPage(c.port, base + '/project/' + b.name + '.dc.html', b.w, b.h); await pg.wait(1700);
  const ok = await pg.ev(`!!document.querySelector('.app')`);
  if (!ok) { await pg.close(); return null; }
  const f = dir + b.name + '.png'; await pg.shot(f); await pg.close();
  return crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
};
try {
  for (const b of list) {
    const ha = await shot(A, b, dirA), hb = await shot(B, b, dirB);
    if (!hb) { res.changed.push(b.name + ' (v15 не открылась)'); continue; }
    if (!ha) res.onlyNew.push(b.name); else if (ha === hb) res.same.push(b.name); else res.changed.push(b.name);
  }
} finally { c.close(); }
const dir = process.env.RESULTS_DIR || new URL('./results/', import.meta.url).pathname; fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(dir + '/rvdiff.json', JSON.stringify(Object.assign({ at: new Date().toISOString() }, res), null, 1));
console.log('совпали', res.same.length, '· изменились', res.changed.length, '· только в v15', res.onlyNew.length);
