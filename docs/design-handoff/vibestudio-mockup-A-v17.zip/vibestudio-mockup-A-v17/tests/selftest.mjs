// Самопроверка обвязки прогона (замечание C-02): ошибочные случаи ДОЛЖНЫ давать ненулевой код, нормальный — нулевой.
// Не использует tlib.mjs для собственных проверок: проверяемая библиотека не может проверять сама себя.
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const HERE = path.dirname(new URL(import.meta.url).pathname);
if (!process.env.MOCKUP_BASE) { console.log('Нужен запущенный сервер: задайте MOCKUP_BASE (его задаёт run-all.sh).'); process.exit(3); }
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'selftest-'));
const results = []; let n = 0;
const check = (name, cond, extra) => { n++; results.push({ name, ok: !!cond, extra }); console.log((cond ? '  ок   ' : '  НЕТ  ') + name + (cond ? '' : ' → ' + JSON.stringify(extra))); };
const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return null; } };
const env = (extra) => Object.assign({}, process.env, { RUN_ID: 'selftest' }, extra || {});

console.log('\nS1. Отдельные сценарии: код возврата и статус в файле результата');
const CASES = [
  ['case-pass.mjs', 0, 'passed', 'нормальный успешный прогон'],
  ['case-fail.mjs', 1, 'failed', 'неуспешное утверждение'],
  ['case-crash.mjs', 2, 'crashed', 'аварийное завершение теста (исключение внутри сценария)'],
  ['case-uncaught.mjs', null, 'aborted', 'необработанное исключение без done()'],
  ['case-finally.mjs', null, 'crashed', 'исключение внутри try и done() в finally без catch'],
  ['case-launch.mjs', null, 'crashed', 'ошибка запуска браузера', { CHROME: '/нет/такого/chrome' }],
  ['case-empty.mjs', 3, 'empty', 'пустой прогон без проверок']
];
for (const [file, code, status, label, extraEnv] of CASES) {
  const dir = path.join(tmp, file); fs.mkdirSync(dir);
  const r = spawnSync(process.execPath, [path.join(HERE, 'selftest', file)], { env: env(Object.assign({ RESULTS_DIR: dir }, extraEnv)), encoding: 'utf8', timeout: 120000 });
  const j = readJson(path.join(dir, file + '.json'));
  const wantZero = code === 0;
  check(label + ': код возврата ' + (wantZero ? '0' : code == null ? 'ненулевой' : code), wantZero ? r.status === 0 : code == null ? r.status !== 0 && r.status !== null : r.status === code, { status: r.status, signal: r.signal, tail: (r.stdout + r.stderr).slice(-300) });
  check(label + ': в файле результата статус «' + status + '»', j && j.status === status, j && { status: j.status, crash: j.crash });
  if (wantZero) check(label + ': результат содержит выполненные проверки', j && j.pass > 0 && j.fail === 0, j);
}

console.log('\nS2. Прогон run-all.sh целиком (с подменой списка шагов и ожидаемого набора)');
const sh = path.join(HERE, 'run-all.sh');
const mk = (name, steps, expected, extra) => {
  const d = path.join(tmp, 'ra-' + name); fs.mkdirSync(d);
  fs.writeFileSync(path.join(d, 'steps.txt'), steps);
  fs.writeFileSync(path.join(d, 'expected.json'), JSON.stringify(expected));
  const r = spawnSync('sh', [sh], { env: env(Object.assign({ STEPS_FILE: path.join(d, 'steps.txt'), EXPECTED_FILE: path.join(d, 'expected.json'), RESULTS_ROOT: path.join(d, 'res') }, extra)), encoding: 'utf8', timeout: 240000 });
  return { r, d, out: (r.stdout || '') + (r.stderr || '') };
};
const PASS_STEP = 'a|node selftest/case-pass.mjs';
const EXP_A = { steps: [{ id: 'a', result: 'case-pass.mjs.json', minChecks: 1 }] };
let x = mk('ok', PASS_STEP + '\n', EXP_A);
check('нормальный прогон run-all: код 0 и «ПРОГОН ПРОЙДЕН»', x.r.status === 0 && x.out.includes('ПРОГОН ПРОЙДЕН'), { status: x.r.status, tail: x.out.slice(-400) });
x = mk('cmdfail', PASS_STEP + '\nb|false\n', { steps: EXP_A.steps.concat([{ id: 'b' }]) });
check('команда шага завершилась ошибкой (false): run-all даёт ненулевой код', x.r.status !== 0 && x.out.includes('ПРОГОН НЕ ПРОЙДЕН'), { status: x.r.status, tail: x.out.slice(-300) });
x = mk('nolaunch', PASS_STEP + '\nb|node selftest/no-such-file.mjs\n', { steps: EXP_A.steps.concat([{ id: 'b' }]) });
check('команда не запустилась (нет файла): ненулевой код', x.r.status !== 0, { status: x.r.status, tail: x.out.slice(-300) });
x = mk('finally', 'a|node selftest/case-finally.mjs\n', { steps: [{ id: 'a', result: 'case-finally.mjs.json', minChecks: 1 }] });
check('исключение с finally внутри шага: run-all даёт ненулевой код', x.r.status !== 0, { status: x.r.status, tail: x.out.slice(-300) });
x = mk('failcheck', 'a|node selftest/case-fail.mjs\n', { steps: [{ id: 'a', result: 'case-fail.mjs.json', minChecks: 1 }] });
check('непройденное утверждение внутри шага: ненулевой код', x.r.status !== 0, { status: x.r.status });
x = mk('empty', '# только комментарий\n', EXP_A);
check('пустой список шагов: ненулевой код, прогон не объявлен полным', x.r.status !== 0 && !x.out.includes('ПРОГОН ПРОЙДЕН'), { status: x.r.status, tail: x.out.slice(-200) });
x = mk('incomplete', PASS_STEP + '\n', { steps: EXP_A.steps.concat([{ id: 'missing', result: 'missing.json', minChecks: 1 }]) });
check('неполный прогон (ожидаемый шаг не выполнялся): ненулевой код', x.r.status !== 0 && x.out.includes('шаг не выполнялся'), { status: x.r.status, tail: x.out.slice(-300) });
x = mk('fewchecks', PASS_STEP + '\n', { steps: [{ id: 'a', result: 'case-pass.mjs.json', minChecks: 50 }] });
check('проверок меньше ожидаемого: ненулевой код', x.r.status !== 0 && x.out.includes('проверок'), { status: x.r.status, tail: x.out.slice(-300) });
fs.writeFileSync(path.join(tmp, 'stale.json'), JSON.stringify({ script: 'stale', status: 'passed', runId: 'run-старый-прогон', pass: 99, fail: 0 }));
x = mk('stale', 'a|cp "' + path.join(tmp, 'stale.json') + '" "$RESULTS_DIR/stale.json"\n', { steps: [{ id: 'a', result: 'stale.json', minChecks: 1 }] });
check('результат от прежнего прогона не принимается за результат этого: ненулевой код', x.r.status !== 0 && x.out.includes('другого прогона'), { status: x.r.status, tail: x.out.slice(-300) });
x = mk('noexpected', PASS_STEP + '\n', { steps: [] });
check('пустое описание ожидаемого набора: ненулевой код', x.r.status !== 0, { status: x.r.status });

const failed = results.filter(r => !r.ok).length;
const status = failed ? 'failed' : n === 0 ? 'empty' : 'passed';
console.log('\nИТОГО самопроверка: ' + (n - failed) + ' ок, ' + failed + ' ошибок; статус: ' + status);
const dir = process.env.RESULTS_DIR || path.join(HERE, 'results'); fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(path.join(dir, 'selftest.json'), JSON.stringify({ script: 'selftest.mjs', status, runId: process.env.RUN_ID || '', pass: n - failed, fail: failed, failed: results.filter(r => !r.ok).map(r => r.name), at: new Date().toISOString() }, null, 1));
try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (e) {}
process.exit(status === 'passed' ? 0 : status === 'failed' ? 1 : 3);
