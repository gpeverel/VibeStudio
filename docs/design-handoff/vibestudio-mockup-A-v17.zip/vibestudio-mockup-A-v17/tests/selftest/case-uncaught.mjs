// Исключение без перехвата и без done(): процесс умирает, результата нет (код ненулевой, статус aborted).
import { init, page, ok, section } from '../tlib.mjs';
await init();
await section('необработанное исключение');
const pg = await page('Main');
ok('проверка до исключения', true);
throw new Error('необработанное исключение теста');
