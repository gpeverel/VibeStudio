// Аварийное завершение теста: исключение внутри сценария ловится, но успехом не становится (код 2, статус crashed).
import { init, done, crash, page, ok, section } from '../tlib.mjs';
await init();
try {
  await section('авария');
  const pg = await page('Main');
  ok('проверка до аварии', true);
  await pg.ev('this_function_does_not_exist()');
  ok('проверка после аварии (не должна выполниться)', true);
} catch (e) { crash(e); } finally { await done(); }
