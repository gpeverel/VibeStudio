// Исключение при выполнении с последующим finally, в котором вызывается done() БЕЗ catch.
// Именно так прежний tlib превращал исключение в успех. Теперь процесс обязан завершиться ошибкой.
import { init, done, page, ok, section } from '../tlib.mjs';
await init();
try {
  await section('исключение и finally');
  const pg = await page('Main');
  ok('проверка до исключения', true);
  throw new Error('исключение внутри try');
} finally { await done(); }
