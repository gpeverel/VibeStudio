// Ошибка запуска браузера: запускать с CHROME=/нет/такого/chrome — ожидается ненулевой код, а не «пустой успех».
import { init, done, crash, page, ok, section } from '../tlib.mjs';
await init();
try {
  await section('запуск браузера');
  const pg = await page('Main');
  ok('страница открылась', true);
  await pg.close();
} catch (e) { crash(e); } finally { await done(); }
