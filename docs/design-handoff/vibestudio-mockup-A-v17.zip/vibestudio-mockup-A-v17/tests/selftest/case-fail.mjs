// Неуспешное утверждение: ожидается код 1 и статус failed.
import { init, done, crash, page, ok, section } from '../tlib.mjs';
await init();
try {
  await section('неуспешное утверждение');
  const pg = await page('Main');
  ok('верное утверждение', true);
  ok('намеренно неверное утверждение', (await pg.text('body')) === 'такого текста на странице нет');
  await pg.close();
} catch (e) { crash(e); } finally { await done(); }
