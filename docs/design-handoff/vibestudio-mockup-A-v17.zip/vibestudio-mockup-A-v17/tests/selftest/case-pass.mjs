// Нормальный успешный прогон: страница открывается, проверка выполняется.
import { init, done, crash, page, ok, section } from '../tlib.mjs';
await init();
try {
  await section('нормальный прогон');
  const pg = await page('Main');
  ok('страница Main открылась и содержит приложение', (await pg.has('x-dc, .app, body')) && (await pg.text('body')).length > 20);
  await pg.close();
} catch (e) { crash(e); } finally { await done(); }
