// Пустой прогон: ни одной проверки. Ожидается код 3 и статус empty.
import { init, done, crash } from '../tlib.mjs';
await init();
try { /* проверок нет */ } catch (e) { crash(e); } finally { await done(); }
