// Снимки платформ: node tests/shots.mjs [имя ...]; без аргументов — все из tools/boards5.json. Пишет tests/shots/<имя>.png и ошибки консоли.
import fs from 'node:fs';
import { launch, openPage } from './cdp.mjs';
const boards = JSON.parse(fs.readFileSync(new URL('../tools/boards5.json', import.meta.url)));
const want = process.argv.slice(2);
const c = await launch();
fs.mkdirSync(new URL('./shots/', import.meta.url).pathname, { recursive: true });
try {
  for (const b of boards) {
    if (want.length && !want.includes(b.name)) continue;
    const pg = await openPage(c.port, (process.env.MOCKUP_BASE || 'http://127.0.0.1:8765') + '/project/' + b.name + '.dc.html', b.w, b.h);
    await pg.wait(1800);
    const errs = pg.logs.filter(l => /^(error|EXC)/.test(l));
    await pg.shot(new URL('./shots/' + b.name + '.png', import.meta.url).pathname);
    const sh = await pg.ev(`({sw:document.documentElement.scrollWidth,iw:innerWidth, btn: document.querySelectorAll('button').length, title:(document.querySelector('h2#dlg-title')||{}).innerText||''})`);
    console.log(b.name, JSON.stringify(sh), errs.length ? 'ERR ' + errs.slice(0, 3).join(' | ') : 'ok');
    await pg.close();
  }
} finally { c.close(); }
