// Автопроверка платформ: node tests/scan5.mjs [имя ...] (без аргументов — все платформы из canvas.json, кроме документов).
// Измеряет (не заменяет просмотр глазами): ошибки консоли, горизонтальную прокрутку, текст мельче 12 px, контраст текста (порог 4,5:1),
// контраст значков (3:1) и границ полей (3:1), выход окна за область, видимость кнопок подвала, обрезанный текст.
import { launch, openPage } from './cdp.mjs';
import fs from 'node:fs';
const root = new URL('../project/', import.meta.url).pathname;
let names = process.argv.slice(2).filter(a => !a.startsWith('--'));
if (!names.length) {
  // все платформы-обёртки приложения (содержат <dc-import name="App">), кроме тестовых T-*, обёрток просмотра RV-* и листа Handoff3 (в нём окна приложения — неинтерактивные миниатюры)
  names = fs.readdirSync(root).filter(f => f.endsWith('.dc.html') && !/^(T-|RV-|Handoff|H[123]-)/.test(f) && fs.readFileSync(root + f, 'utf8').includes('<dc-import name="App"')).map(f => f.replace('.dc.html', ''));
}
const SCAN = `(() => {
  const lum = (c) => { const f = (v) => { v/=255; return v<=0.03928 ? v/12.92 : Math.pow((v+0.055)/1.055,2.4); }; return 0.2126*f(c[0])+0.7152*f(c[1])+0.0722*f(c[2]); };
  const parse = (s) => { const m = s.match(/rgba?\\(([^)]+)\\)/); if (!m) return null; const p = m[1].split(',').map(x=>parseFloat(x)); return { r:p[0], g:p[1], b:p[2], a: p.length>3 ? p[3] : 1 }; };
  const bgOf = (el) => { let e = el; while (e) { const c = parse(getComputedStyle(e).backgroundColor); if (c && c.a > 0.5) return [c.r,c.g,c.b]; e = e.parentElement; } return [255,255,255]; };
  const cr = (a,b) => { const l1 = lum(a), l2 = lum(b); return (Math.max(l1,l2)+0.05)/(Math.min(l1,l2)+0.05); };
  const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && !e.closest('[inert]') && !e.closest('[hidden]') && !e.closest('.sr') && getComputedStyle(e).visibility !== 'hidden'; };
  const out = { theme: (document.querySelector('.app')||{getAttribute(){return ''}}).getAttribute('data-theme') || '', minIcon: 99, minBorder: 99, hscroll: document.documentElement.scrollWidth > innerWidth + 1, small: [], lowText: [], lowIcon: [], lowBorder: [], clipped: [], minText: 99, texts: 0, dlg: null, foot: null };
  document.querySelectorAll('.app *, body *').forEach((e) => {
    if (!vis(e)) return;
    const t = [...e.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent.trim()).join(' ');
    if (!t) return;
    const cs = getComputedStyle(e), fs = parseFloat(cs.fontSize);
    if (t.length > 22 && fs < 12) out.small.push(t.slice(0, 50) + ' [' + fs + ']');
    const col = parse(cs.color); if (!col) return;
    const disabled = e.closest('button[disabled],input[disabled],[aria-disabled=true]');
    const c = cr([col.r,col.g,col.b], bgOf(e));
    out.texts++; if (!disabled) out.minText = Math.min(out.minText, c);
    if (c < 4.5 && !disabled) out.lowText.push(t.slice(0, 40) + ' ' + c.toFixed(2));
    if (e.scrollWidth > e.clientWidth + 1 && /hidden|clip/.test(cs.overflowX) && cs.textOverflow !== 'ellipsis' && e.clientWidth > 0) out.clipped.push(t.slice(0, 40));
  });
  document.querySelectorAll('svg.ic').forEach((e) => {
    if (!vis(e)) return;
    const col = parse(getComputedStyle(e).color); if (!col) return;
    const c = cr([col.r,col.g,col.b], bgOf(e));
    out.minIcon = Math.min(out.minIcon, c);
    if (c < 3) out.lowIcon.push(((e.closest('button,li,div')||{}).innerText||'').slice(0,30) + ' ' + c.toFixed(2));
  });
  document.querySelectorAll('.inp:not([disabled])').forEach((e) => {
    if (!vis(e)) return;
    const b = parse(getComputedStyle(e).borderTopColor); if (!b) return;
    const c = cr([b.r,b.g,b.b], bgOf(e.parentElement));
    out.minBorder = Math.min(out.minBorder, c);
    if (c < 3) out.lowBorder.push(e.id + ' ' + c.toFixed(2));
  });
  const d = document.getElementById('dlg');
  if (d) { const r = d.getBoundingClientRect(); out.dlg = { top: Math.round(r.top), bottom: Math.round(r.bottom), left: Math.round(r.left), right: Math.round(r.right), inside: r.top >= -1 && r.bottom <= innerHeight + 1 && r.left >= -1 && r.right <= innerWidth + 1 };
    const body = document.getElementById('dlg-body'); out.dlg.bodyOverflowX = body ? body.scrollWidth > body.clientWidth + 1 : false; out.dlg.bodyScrolls = body ? body.scrollHeight > body.clientHeight + 1 : false;
    const btns = [...d.querySelectorAll('.dlg-foot button')]; out.foot = btns.length ? btns.every(b => { const q = b.getBoundingClientRect(); return q.bottom <= innerHeight + 1 && q.top >= 0 && q.right <= innerWidth + 1; }) : null; }
  return out;
})()`;
let c = null, crashErr = null;
const rows = []; const issues = []; const agg = { n: 0, withIssues: 0, icons: 0, minText: { dark: 99, light: 99 }, minIcon: { dark: 99, light: 99 }, minBorder: { dark: 99, light: 99 }, small: 0, hscroll: 0, errs: 0, dlgOutside: 0 };
try {
  c = await launch();
  for (const n of names) {
    if (!fs.existsSync(root + n + '.dc.html')) { rows.push(n + ': нет файла'); issues.push(n + ': нет файла'); continue; }
    const file = fs.readFileSync(root + n + '.dc.html', 'utf8');
    const w = +(/ w="(\d+)"/.exec(file) || [0, 1440])[1], h = +(/ h="(\d+)"/.exec(file) || [0, 900])[1];
    const pg = await openPage(c.port, `${process.env.MOCKUP_BASE || 'http://127.0.0.1:8765'}/project/${n}.dc.html`, w, h);
    await pg.wait(1600);
    const r = await pg.ev(SCAN);
    const errs = pg.logs.filter(l => /^(error|EXC)/.test(l)).length;
    const bad = r.hscroll || r.small.length || r.lowText.length || r.lowIcon.length || r.lowBorder.length || r.clipped.length || errs || (r.dlg && (!r.dlg.inside || r.dlg.bodyOverflowX)) || r.foot === false;
    const line = n + ' [' + w + '×' + h + ']: ' + (bad ? 'ЗАМЕЧАНИЯ ' + JSON.stringify({ errs, hscroll: r.hscroll, small: r.small.slice(0, 2), lowText: r.lowText.slice(0, 3), lowIcon: r.lowIcon.slice(0, 2), lowBorder: r.lowBorder.slice(0, 2), clipped: r.clipped.slice(0, 2), dlg: r.dlg, foot: r.foot }) : 'чисто, мин. контраст текста ' + r.minText.toFixed(2) + ', текстов ' + r.texts);
    rows.push(line); if (bad) issues.push(line);
    agg.n++; if (bad) agg.withIssues++; const th = r.theme === 'light' ? 'light' : 'dark'; agg.minText[th] = Math.min(agg.minText[th], r.minText); agg.minIcon[th] = Math.min(agg.minIcon[th], r.minIcon); agg.minBorder[th] = Math.min(agg.minBorder[th], r.minBorder); agg.small += r.small.length; agg.hscroll += r.hscroll ? 1 : 0; agg.errs += errs; if (r.dlg && !r.dlg.inside) agg.dlgOutside++;
    await pg.close();
  }
} catch (e) { crashErr = e; console.log('АВАРИЙНОЕ ЗАВЕРШЕНИЕ: ' + (e && e.message || e)); } finally { if (c) c.close(); }
console.log(rows.join('\n'));
const scanned = rows.length - issues.filter(x => x.endsWith('нет файла')).length;
const status = crashErr ? 'crashed' : (names.length === 0 || scanned < names.length) ? (scanned === 0 ? 'empty' : 'failed') : issues.length ? 'failed' : 'passed';
console.log('\nИТОГО: платформ ' + names.length + ', просмотрено ' + scanned + ', с замечаниями ' + issues.length + '; статус: ' + status);
const rd = process.env.RESULTS_DIR || new URL('./results/', import.meta.url).pathname; fs.mkdirSync(rd, { recursive: true });
fs.writeFileSync(rd + '/scan5.json', JSON.stringify(Object.assign({ script: 'scan5.mjs', status, runId: process.env.RUN_ID || '', crash: crashErr ? String(crashErr.message || crashErr) : null, requested: names.length, scanned, issues, at: new Date().toISOString() }, agg), null, 1));
console.log(JSON.stringify(agg));
process.exit(status === 'passed' ? 0 : status === 'failed' ? 1 : status === 'crashed' ? 2 : 3);
