// ИЗМЕНЕНО при подготовке версии 13 (оригинал — в recovered-verbatim снимка версии 12). Порядок ошибок формы (имя раньше команды), время завершения анимации подготовки, текущая формулировка про создание.
import { init, done, crash, page, ok, section } from './tlib.mjs';
await init();
try {
  await section('R1. Регрессия: Stop → сверка → возобновление (Swarm)');
  let pg = await page('D-Stop-Out-Dark');
  ok('исход по участникам и баннер', (await pg.text('#stop-banner')).includes('Остановка подтверждена не у всех'));
  ok('Возобновить недоступно, «Считать остановленным» нет', (await pg.dis('#stop-resume')) === true && !(await pg.ev(`document.body.innerText.includes('Считать остановленным')`)));
  await pg.click('#stop-retry'); await pg.wait(1600);
  ok('после повтора: Реализация подтверждена', (await pg.text('#stop-banner')).includes('После повтора основной процесс вышел'));
  await pg.click('#stop-recon'); await pg.wait(300); await pg.click('#dlg-run'); await pg.wait(1500);
  ok('сверка подтверждает Тесты', (await pg.text('#dlg-body')).includes('по сверке'));
  ok('возобновление доступно в окне', (await pg.dis('#dlg-resume')) === false);
  await pg.click('#dlg-resume'); await pg.wait(400);
  ok('работа возобновлена', (await pg.text('#status-chip')).includes('Работает'));
  await pg.close();

  await section('R2. Регрессия: Stop в сценарии «ход идёт»');
  pg = await page('Main');
  ok('Return отправляет, Shift+Return — подсказка в интерфейсе', (await pg.text('#msg-hint')).includes('Return — отправить, Shift+Return'));
  await pg.click('#msg'); await pg.ev(`document.getElementById('msg').value='Привет'; document.getElementById('msg').dispatchEvent(new Event('input',{bubbles:true}))`);
  await pg.key('Enter', { vk: 13, text: '\r' }); await pg.wait(300);
  ok('Return отправил сообщение', (await pg.text('main')).includes('Привет') && (await pg.val('#msg')) === '');
  await pg.close();

  await section('R3. Регрессия: ревью и доработка');
  pg = await page('A-Done-Dark');
  await pg.click('#to-result'); await pg.wait(200);
  await pg.click('#tab-changes'); await pg.wait(150);
  await pg.click('#open-review'); await pg.wait(400);
  ok('ревью открыто', await pg.has('#rv-title'));
  ok('замечания: 2 открыто · 1 решено · 1 устарело', (await pg.text('#rv-send')).includes('(2)') || (await pg.text('main')).includes('открыто'), await pg.text('#rv-send'));
  await pg.click('#rv-send'); await pg.wait(200); await pg.click('#rv-send-go'); await pg.wait(500);
  ok('отправка: ход доработки, ревизия не изменена', (await pg.text('#status-chip')).includes('доработки') || (await pg.text('#status-chip')).includes('Работает'), await pg.text('#status-chip'));
  await pg.wait(2200);
  ok('файлы изменены, проверки устарели', (await pg.text('#status-chip')).includes('файлы изменены') || (await pg.text('main')).includes('не относятся'), await pg.text('#status-chip'));
  await pg.wait(2200);
  ok('новая ревизия, проверки устарели', (await pg.text('#status-chip')).includes('Проверки устарели'), await pg.text('#status-chip'));
  await pg.close();

  await section('R4. Регрессия: Применить → условия → кандидат → подтверждение');
  pg = await page('A-Done-Dark');
  await pg.click('#act-apply'); await pg.wait(300);
  ok('шаг 1: условия, основная копия не меняется', (await pg.text('#dlg-body')).includes('Первое нажатие ничего не меняет'));
  await pg.click('#dlg-go'); await pg.wait(1300);
  ok('шаг 3: diff и проверки кандидата', (await pg.text('#dlg-body')).includes('Проверки этого кандидата'));
  await pg.click('#dlg-next'); await pg.wait(200);
  ok('шаг 4: окончательное подтверждение', (await pg.text('#dlg-body')).includes('Окончательное подтверждение'));
  await pg.click('#dlg-go2'); await pg.wait(1300);
  ok('применено', (await pg.text('#dlg-body')).includes('Применено: main теперь на'));
  await pg.click('#dlg-done'); await pg.wait(300);
  ok('статус «Применено», отмена доступна', (await pg.text('#status-chip')).includes('Применено') && await pg.has('#act-undo'));
  await pg.close();

  await section('R5. Регрессия: обход проверок (причина из пробелов не принимается)');
  pg = await page('O-Bypass-Dark');
  ok('Применить без проверок недоступно без причины', (await pg.dis('#dlg-go')) === true);
  await pg.setVal('#dlg-reason', '   '); await pg.click('#dlg-ack'); await pg.wait(100);
  ok('пробелы не принимаются', (await pg.dis('#dlg-go')) === true);
  await pg.setVal('#dlg-reason', 'ok'); await pg.wait(100);
  ok('короткая причина принимается', (await pg.dis('#dlg-go')) === false);
  await pg.close();

  await section('R6. Регрессия: коммит → push → отбросить');
  pg = await page('A-Done-Dark');
  await pg.click('#act-commit'); await pg.wait(300); await pg.click('#dlg-go'); await pg.wait(1100);
  ok('коммит создан', (await pg.text('#dlg-body')).includes('Коммит b7d20e4 создан'));
  await pg.click('#dlg-done'); await pg.wait(300);
  await pg.click('#act-push'); await pg.wait(300); await pg.click('#dlg-confirm'); await pg.click('#dlg-go'); await pg.wait(1300);
  ok('push отправлен', (await pg.text('#dlg-body')).includes('Отправлено'));
  await pg.click('#dlg-done'); await pg.wait(300);
  await pg.click('#act-discard'); await pg.wait(300); await pg.click('#dlg-go'); await pg.wait(1100);
  await pg.click('#dlg-done'); await pg.wait(300);
  ok('сессия отброшена', (await pg.text('h1')).includes('отброшена'));
  await pg.close();

  await section('R7. Регрессия: конфликт → слияние → подготовка заново');
  pg = await page('T-Conflict');
  await pg.click('#dlg-check'); await pg.wait(1100); await pg.click('#dlg-check'); await pg.wait(1100);
  ok('все файлы разрешены', (await pg.dis('#dlg-merge')) === false);
  await pg.click('#dlg-merge'); await pg.wait(1200);
  ok('слияние завершено, новая ревизия', (await pg.text('#dlg-body')).includes('5d09ab1'));
  await pg.click('#dlg-prep'); await pg.wait(400);
  ok('возврат к подготовке кандидата', (await pg.text('#dlg-title')).includes('Применить в main'));
  await pg.close();

  await section('R8. Регрессия: команды проверок');
  pg = await page('K-Config-Dark');
  await pg.setVal('#cfg-n-0', 'Тесты'); await pg.setVal('#cfg-c-0', 'npm test && rm -rf x'); await pg.wait(100);
  ok('shell-конструкции отклоняются', (await pg.text('#cfg-e-0')).includes('без shell'));
  ok('«Сохранить» недоступно', (await pg.dis('#dlg-go')) === true);
  await pg.setVal('#cfg-n-0', 'Тесты'); await pg.setVal('#cfg-c-0', 'npm test'); await pg.click('#dlg-cons'); await pg.wait(100);
  ok('после исправления и согласия доступно', (await pg.dis('#dlg-go')) === false);
  await pg.close();

  await section('R9. Регрессия: отказ в правах');
  pg = await page('P-Denied-None-Dark');
  await pg.click('#perm-allow'); await pg.wait(300);
  ok('по умолчанию «на следующий ход»', await pg.ev(`document.querySelectorAll('input[name=scope]')[0].checked`));
  await pg.click('#dlg-go'); await pg.wait(1000);
  ok('участник сам не продолжает', (await pg.text('#dlg-body')).includes('не продолжит сам'));
  await pg.close();
  pg = await page('P-Denied-Policy-Dark');
  ok('внешняя политика: нет «Изменить правило» и «Разрешить»', !(await pg.has('#perm-rule')) && !(await pg.has('#perm-allow')));
  await pg.close();

  await section('R10. Регрессия: форма и подготовка');
  pg = await page('N4-Prep-Fail-Dark'); await pg.wait(3200);
  ok('сбой подготовки: сохранено и неизвестно', (await pg.text('main')).includes('Сохранено') && (await pg.text('main')).includes('Не завершено или неизвестно'));
  await pg.close();
  pg = await page('N2-New-Light');
  ok('Codex: авторизация не проверена, создание не блокируется', (await pg.text('main')).includes('Авторизация не проверена') && (await pg.text('main')).includes('Создание не блокируется'), '');
  await pg.close();

  await section('R11. Регрессия: длинный ввод');
  pg = await page('D-Long-Dark');
  const sh = await pg.ev(`(()=>{const t=document.getElementById('msg');return [t.scrollHeight>t.clientHeight, t.clientHeight]})()`);
  ok('длинное сообщение прокручивается внутри поля, ограничение высоты', sh[0] === true && sh[1] <= 170, sh);
  await pg.close();
} catch (e) { crash(e); } finally { await done(); }
