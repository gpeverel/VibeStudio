import { init, done, crash, page, ok, section } from './tlib.mjs';
await init();
try {
  await section('Расхождения старых тестов: ожидаемое поведение');
  const pg = await page('Main');
  await pg.click('#stop-info'); await pg.wait(150);
  const t = await pg.text('#stop-info-panel');
  ok('Stop: пояснение называет три исхода и условие «остановлено»', t.includes('подтверждена, не подтверждена или ошибка') && t.includes('«остановлено» не показывается'), t);
  await pg.esc();
  await pg.click('#msg'); await pg.ev(`document.getElementById('msg').value='x'; document.getElementById('msg').dispatchEvent(new Event('input',{bubbles:true}))`);
  await pg.click('#rc-btn'); await pg.wait(150);
  ok('список «Кому»: фокус на выбранном варианте', (await pg.active()).startsWith('rc-opt-'), await pg.active());
  await pg.tab(); await pg.wait(150);
  ok('Tab из списка закрывает его и ведёт к «Отправить», минуя кнопку выбора', !(await pg.has('#rc-list')) && (await pg.active()) === 'send', await pg.active());
  await pg.click('#rc-btn'); await pg.wait(150); await pg.esc(); await pg.wait(150);
  ok('Escape из списка возвращает фокус на кнопку выбора', (await pg.active()) === 'rc-btn', await pg.active());
  await pg.close();
} catch (e) { crash(e); } finally { await done(); }
