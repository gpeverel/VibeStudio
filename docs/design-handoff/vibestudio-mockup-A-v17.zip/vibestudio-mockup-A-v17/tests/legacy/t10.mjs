// ИЗМЕНЕНО при подготовке версии 13 (оригинал — в recovered-verbatim снимка версии 12). В просмотре правил «Изменить…» теперь открывает форму (возврат — «Отмена»), быстрый диалог удаления остался за кнопкой «Изменить правило…» в блоке отказа. Кнопка «Записать результат» убрана по SPEC §6: запись выполняется автоматически.
import { init, done, crash, page, ok, section } from './tlib.mjs';
await init();
try {
  await section('D. Ручной разбор: путь из сверки');
  let pg = await page('T-Recon-Interrupted');
  ok('прерванное применение: алерт и статус', (await pg.text('#status-chip')).includes('Применение прервано') && await pg.has('#alert-act'));
  await pg.click('#act-recon'); await pg.wait(300);
  ok('сверка применения открыта', (await pg.text('#dlg-title')).includes('Сверка состояния'));
  await pg.click('#dlg-run'); await pg.wait(1500);
  ok('результат: состояние неоднозначно', (await pg.text('#dlg-body')).includes('Состояние неоднозначно'));
  ok('нет кнопки «Считать применённым»', !(await pg.ev(`document.body.innerText.includes('Считать применённым')`)));
  await pg.wait(300);
  ok('статус сессии стал «исход не установлен»', await pg.ev(`document.getElementById('status-chip').innerText.includes('исход не установлен')`));
  await pg.click('#dlg-manual'); await pg.wait(500);
  ok('открыт ручной разбор', (await pg.text('#dlg-title')).includes('Разбор прерванного применения'));
  await pg.click('#dlg-close'); await pg.wait(200);
  ok('Вернуться к сессии: диалог закрыт', !(await pg.has('#dlg')));
  ok('Применить и Отбросить заблокированы, объяснены', (await pg.dis('#act-apply')) === true && (await pg.dis('#act-discard')) === true && (await pg.text('#act-apply-why')).includes('не установлен'), await pg.text('#act-apply-why'));
  await pg.close();

  await section('D2. Ручной разбор: три исхода повторной сверки');
  pg = await page('Y-Manual-Banner-Dark');
  ok('баннер: исход не установлен', (await pg.text('#status-chip')).includes('исход не установлен') && (await pg.text('#act-recon')) === 'Открыть разбор…');
  await pg.click('#act-recon'); await pg.wait(300);
  const body = await pg.text('#dlg-body');
  ok('объяснение простым языком: что прервалось, ожидалось, наблюдается, мешает, почему заблокировано', ['Что прервалось', 'Ожидалось', 'Наблюдается', 'Что мешает установить исход', 'Почему повторное применение заблокировано'].every(t => body.includes(t)), null);
  ok('нет reset/clean/stash как действий', !(await pg.ev(`[...document.querySelectorAll('#dlg button')].some(b=>/reset|clean|stash|Считать/i.test(b.innerText))`)));
  ok('технические подробности свёрнуты', (await pg.ev(`document.getElementById('dlg-tech').open`)) === false);
  await pg.click('#dlg-tech summary'); await pg.wait(100);
  ok('подробности раскрываются (SHA, индекс)', (await pg.text('#dlg-tech')).includes('c91d2e8') && (await pg.text('#dlg-tech')).includes('Индекс'));
  await pg.click('#dlg-open-main'); await pg.wait(100);
  ok('открыть расположение копии: подтверждение действия', (await pg.text('#dlg-body')).includes('Запрошено открытие в Finder: ~/Projects/ledger-web'));
  await pg.click('#dlg-diag-show'); await pg.wait(150);
  ok('сводка показана, только чтение', (await pg.ev(`document.getElementById('dlg-diag').readOnly`)) === true && (await pg.val('#dlg-diag')).includes('op-7f3a91'));
  await pg.click('#dlg-copy'); await pg.wait(100);
  ok('копирование подтверждается', (await pg.text('#dlg-body')).includes('Сводка скопирована'));
  // исход 1: ничего не менял
  await pg.click('#dlg-run'); await pg.wait(1400);
  ok('исход «не изменилось»: блокировка и объяснение остаются', (await pg.text('#dlg-body')).includes('Исход по-прежнему не установлен') && (await pg.text('#dlg-body')).includes('Сверка №2') && (await pg.text('#dlg-body')).includes('Почему повторное применение заблокировано'));
  // исход 2: завершено
  await pg.setVal('#dlg-sim', 'done'); await pg.click('#dlg-run'); await pg.wait(1400);
  ok('исход «завершилось»: подтверждение по состоянию, не по HEAD', (await pg.text('#dlg-body')).includes('Применение завершилось') && (await pg.text('#dlg-body')).includes('не только по HEAD'));
  await pg.wait(2600);
  ok('результат записан автоматически, без кнопки «Записать результат»', !(await pg.has('#dlg-rec')) && (await pg.text('#dlg-body')).includes('Результат сохранён'));
  await pg.click('#dlg-view'); await pg.wait(300);
  ok('результат отражён: Применено, отмена доступна', (await pg.text('#status-chip')).includes('Применено') && await pg.has('#act-undo') && !(await pg.has('#dlg')));
  await pg.close();

  pg = await page('Y-Manual-Banner-Dark');
  await pg.click('#act-recon'); await pg.wait(300);
  await pg.setVal('#dlg-sim', 'revert'); await pg.click('#dlg-run'); await pg.wait(1400);
  ok('исход «не начиналось»: автоматического повтора нет', (await pg.text('#dlg-body')).includes('Применение не начиналось') && (await pg.text('#dlg-body')).includes('Автоматического повтора нет'));
  await pg.click('#dlg-prep'); await pg.wait(500);
  ok('ведёт к подготовке кандидата (шаг 1), статус разблокирован', (await pg.text('#dlg-title')).includes('Применить в main') && (await pg.text('#dlg-body')).includes('Условия'));
  await pg.click('#dlg-cancel'); await pg.wait(200);
  ok('после закрытия: готово к ревью, Применить доступно', (await pg.text('#status-chip')).includes('Готово к ревью') && (await pg.dis('#act-apply')) === false, await pg.text('#status-chip'));
  await pg.close();

  await section('D3. Фокус и клавиатура в разборе');
  pg = await page('Y-Manual-Banner-Dark');
  await pg.click('#act-recon'); await pg.wait(300);
  ok('фокус на заголовке диалога', (await pg.active()) === 'dlg-title');
  await pg.esc(); await pg.wait(150);
  ok('Esc: фокус вернулся на «Открыть разбор…»', (await pg.active()) === 'act-recon', await pg.active());
  await pg.close();

  await section('E. Правила проекта');
  pg = await page('P-Denied-User-Light');
  ok('в отказе есть кнопка просмотра правила', (await pg.text('#perm-rules')) === 'Посмотреть правило');
  await pg.click('#perm-rules'); await pg.wait(300);
  ok('правило, вызвавшее отказ, помечено', (await pg.text('#rl-user')).includes('Вызвало отказ') && (await pg.text('#rl-user')).includes('Bash(npm run build)'));
  ok('у правила: источник, область, срок', ['Источник', 'Область', 'Срок'].every(t => body.length && true));
  const ru = await pg.text('#rl-user');
  ok('поля правила видны', ['Источник', 'Область', 'Срок', 'Весь проект', 'Постоянное'].every(t => ru.includes(t)), ru);
  ok('внешняя политика без кнопок и с объяснением', !(await pg.ev(`!!document.querySelector('#rl-policy button')`)) && (await pg.text('#rl-policy')).includes('не обходит'));
  ok('сказано: allow не снимает deny', (await pg.text('#dlg-sub')).includes('не снимает'));
  await pg.click('#dlg-close'); await pg.wait(150);
  ok('Вернуться к сессии: фокус на кнопке отказа', (await pg.active()) === 'perm-rules', await pg.active());
  await pg.click('#perm-rules'); await pg.wait(300); await pg.click('#rl-edit'); await pg.wait(500);
  ok('«Изменить…» ведёт к явному изменению собственного deny', (await pg.text('#dlg-title')).includes('Изменить собственное правило'));
  await pg.click('#dlg-rcancel'); await pg.wait(400);
  ok('из формы можно вернуться к просмотру', (await pg.text('#dlg-title')).includes('Правила проекта'));
  await pg.click('#dlg-close'); await pg.wait(300);
  await pg.click('#perm-rule'); await pg.wait(500);
  await pg.click('input[name=rule]:nth-of-type(1)'); 
  await pg.ev(`document.querySelectorAll('input[name=rule]')[1].click()`); await pg.wait(100);
  await pg.click('#dlg-ack'); await pg.click('#dlg-go'); await pg.wait(1200);
  ok('правило удалено', (await pg.text('#dlg-body')).includes('Правило удалено'));
  await pg.click('#dlg-next'); await pg.wait(500);
  ok('после удаления deny — выбор срока разрешения, по умолчанию «на следующий ход»', (await pg.text('#dlg-title')).includes('Разрешить действие') && await pg.ev(`document.querySelectorAll('input[name=scope]')[0].checked`));
  await pg.click('#dlg-go'); await pg.wait(1000);
  await pg.click('#dlg-next'); await pg.wait(500);
  ok('«Продолжить новым ходом»: новый ход, а не повтор вызова', (await pg.text('#status-chip')).includes('Работает'));
  await pg.close();

  pg = await page('L-Rules-Policy-Light');
  ok('политика: причина отказа — внешняя политика, нет кнопки изменения', (await pg.text('#rl-policy-hit')).includes('Вызвало отказ') && !(await pg.has('#rl-edit')) && !(await pg.has('#dlg-allow')));
  await pg.close();
  pg = await page('L-Rules-None-Dark');
  ok('нет разрешения: ни одно правило не вызвало отказ, доступно «Разрешить…»', !(await pg.ev(`document.body.innerText.includes('Вызвало отказ')`)) && await pg.has('#dlg-allow'));
  await pg.click('#dlg-allow'); await pg.wait(400);
  ok('«Разрешить…» ведёт к срокам, по умолчанию «на следующий ход»', await pg.ev(`document.querySelectorAll('input[name=scope]')[0].checked`));
  await pg.close();
} catch (e) { crash(e); } finally { await done(); }
