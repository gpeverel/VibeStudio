// ИЗМЕНЕНО при подготовке версии 13 (оригинал — в recovered-verbatim снимка версии 12). Строка контекста начинается со служебной подписи «Контекст сессии:», проверка сравнивает содержимое.
import { init, done, crash, page, ok, section } from './tlib.mjs';
await init();
try {
  await section('A. Переключение сессий');
  let pg = await page('Main');
  ok('в списке есть сессии ledger-web', await pg.has('#sb-cur') && await pg.has('#sb-csv') && await pg.has('#sb-sql') && await pg.has('#sb-onb'));
  ok('группы atlas-cli и parcel-service свёрнуты', !(await pg.has('#sb-atl')) && !(await pg.has('#sb-par')));
  await pg.click('#msg'); await pg.setVal('#msg', 'Черновик А');
  await pg.click('#sb-csv'); await pg.wait(300);
  ok('открылась сессия CSV', (await pg.text('h1')).includes('Тесты парсера CSV'), await pg.text('h1'));
  ok('черновик не перенесён', (await pg.val('#msg')) === '', await pg.val('#msg'));
  ok('фокус на заголовке сессии', (await pg.active()) === 'sess-title', await pg.active());
  ok('в CSV участник Codex', (await pg.text('#in-panel')).includes('Codex'));
  ok('контекст: проект, ветка, режим', (await pg.text('#ctx-bar')).includes('vs/csv-parser-tests') && (await pg.text('#ctx-bar')).includes('Тесты'), await pg.text('#ctx-bar'));
  await pg.click('#sb-cur'); await pg.wait(300);
  ok('вернулась сессия Гонка', (await pg.text('h1')).includes('Гонка'));
  ok('черновик восстановлен', (await pg.val('#msg')) === 'Черновик А', await pg.val('#msg'));
  await pg.click('#stop-btn'); await pg.wait(1700);
  ok('Stop дошёл до баннера', await pg.has('#stop-banner'));
  await pg.click('#sb-csv'); await pg.wait(200); await pg.click('#sb-cur'); await pg.wait(300);
  ok('состояние Stop сохранилось после переключения', await pg.has('#stop-banner') && (await pg.text('#status-chip')).includes('Ошибка остановки'), await pg.text('#status-chip'));
  await pg.click('#pj-atlas-cli'); await pg.wait(150);
  ok('группа atlas-cli раскрывается', await pg.has('#sb-atl'));
  ok('aria-expanded у группы', (await pg.ev(`document.querySelector('#pj-atlas-cli').getAttribute('aria-expanded')`)) === 'true');
  await pg.click('#sb-atl'); await pg.wait(300);
  ok('сессия atlas-cli: заголовок и проект', (await pg.text('h1')).includes('dry-run') && (await pg.text('#ctx-bar')).includes('atlas-cli · vs/sync-dry-run'), await pg.text('#ctx-bar'));
  ok('статус Работает', (await pg.text('#status-chip')).includes('Работает'));
  await pg.click('#pj-parcel-service'); await pg.click('#sb-par'); await pg.wait(300);
  ok('сессия в очереди', (await pg.text('#status-chip')).includes('В очереди') && await pg.has('#cancel-wait'));
  await pg.click('#sb-sql'); await pg.wait(300);
  ok('SQL: проверки не прошли, обход вместо Применить', (await pg.text('#status-chip')).includes('Проверки не прошли') && (await pg.text('#act-apply')).includes('Применить без проверок'), await pg.text('#act-apply'));
  await pg.click('#sb-onb'); await pg.wait(300);
  ok('Онбординг: применено, отмена доступна', (await pg.text('#status-chip')).includes('Применено') && await pg.has('#act-undo'));
  // клавиатура
  await pg.ev(`document.getElementById('sb-csv').focus()`); await pg.enter(); await pg.wait(300);
  ok('Enter на строке сессии открывает её', (await pg.text('h1')).includes('CSV'));
  await pg.close();
} catch (e) { crash(e); } finally { await done(); }
