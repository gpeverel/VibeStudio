// Общая библиотека лежит в ../tlib.mjs; результаты пишутся рядом со сценарием (legacy/results).
export * from '../tlib.mjs';
