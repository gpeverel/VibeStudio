// Снимки платформ для просмотра глазами и сравнения версий (версия 16): каждая платформа из review/rv.json в своей теме и
// своём размере, через Playwright без сервера и порта отладки. KIT_ROOT — комплект, SHOTS_DIR — каталог снимков.
import fs from 'node:fs';
import path from 'node:path';
import { context, open, wrapper, ok, crash, finish, ROOT, W } from './lib.mjs';
const list = JSON.parse(fs.readFileSync(path.join(ROOT, 'review', 'rv.json'), 'utf8'));
const out = path.resolve(process.env.SHOTS_DIR || 'shots-ui7'); fs.mkdirSync(out, { recursive: true });
const want = process.argv.slice(2);
try {
  const ctxs = new Map();
  for (const b of list) {
    if (want.length && !want.some((w) => b.base.includes(w))) continue;
    const key = b.w + 'x' + b.h; if (!ctxs.has(key)) ctxs.set(key, await context({ width: b.w, height: b.h }));
    const page = await open(ctxs.get(key), wrapper(b.base, { theme: b.theme, w: b.w, h: b.h }));
    await W(1400);
    await page.screenshot({ path: path.join(out, b.name + '.png'), animations: 'disabled', caret: 'hide' });
    ok('Снимки', b.name, page._errs.length === 0, page._errs.slice(0, 2));
    await page.close();
  }
} catch (e) { crash(e); } finally { await finish(); }
