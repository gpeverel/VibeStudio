// Попиксельное сравнение двух каталогов снимков (версия 16): node rvdiff.mjs <до> <после> → JSON со списком изменившихся.
import fs from 'node:fs';
import path from 'node:path';
import { png } from './png.mjs';
const [, , A, B, OUT] = process.argv;
const res = { same: [], changed: [], onlyAfter: [], onlyBefore: [] };
for (const f of fs.readdirSync(B).filter((x) => x.endsWith('.png')).sort()) {
  if (!fs.existsSync(path.join(A, f))) { res.onlyAfter.push(f); continue; }
  const a = png(fs.readFileSync(path.join(A, f))), b = png(fs.readFileSync(path.join(B, f)));
  if (a.w !== b.w || a.h !== b.h) { res.changed.push({ f, px: -1, why: 'размер' }); continue; }
  let n = 0; for (let i = 0; i < a.px.length; i += 4) if (a.px[i] !== b.px[i] || a.px[i + 1] !== b.px[i + 1] || a.px[i + 2] !== b.px[i + 2]) n++;
  (n ? res.changed : res.same).push(n ? { f, px: n } : f);
}
for (const f of fs.readdirSync(A).filter((x) => x.endsWith('.png'))) if (!fs.existsSync(path.join(B, f))) res.onlyBefore.push(f);
fs.writeFileSync(OUT, JSON.stringify(res, null, 1));
console.log('совпали', res.same.length, '· изменились', res.changed.length, '· только после', res.onlyAfter.length, '· только до', res.onlyBefore.length);
