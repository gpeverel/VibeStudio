// Высоты листов-документов для холста (версия 16): та же формула, что tests/heights.mjs (низ последнего блока + 32 px,
// округление вверх до 20 px), но через Playwright без HTTP-сервера и порта отладки. → RESULTS_DIR/heights.json
import fs from 'node:fs';
import path from 'node:path';
import { context, open, sheet, ok, crash, finish, W } from './lib.mjs';
const out = {};
try {
  const ctx = await context({ width: 1440, height: 900 });
  for (const [comp, sel] of [['Handoff1', '#ho1'], ['Handoff2', '#ho2'], ['Handoff3', '#ho3'], ['Handoff4', '#ho4'], ['Trace', '#trace'], ['Map', '#mapsheet'], ['Prop2', '.sheet']]) {
    const page = await open(ctx, sheet(comp), sel);
    await W(comp === 'Handoff3' ? 5000 : 1800);
    const h = await page.evaluate((s) => { const e = document.querySelector(s); return e ? Math.ceil(e.lastElementChild.getBoundingClientRect().bottom - e.getBoundingClientRect().top + 32) : 0; }, sel);
    out[comp] = Math.ceil(h / 20) * 20;
    ok('Высоты листов', comp + ': высота измерена, ошибок страницы нет', h > 0 && page._errs.length === 0, { h, errs: page._errs.slice(0, 2) });
    await page.close();
  }
  const dir = path.resolve(process.env.RESULTS_DIR || 'results-ui7'); fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'heights.json'), JSON.stringify(out)); console.log(JSON.stringify(out));
  await ctx.close();
} catch (e) { crash(e); } finally { await finish(); }
