// B-02: полный путь «Тесты парсера CSV → Проверки → Настроить команды → ввод команд → согласие → попытка сохранения»
// при отказе записи и тот же путь без сбоя. Все действия — настоящие нажатия мыши и ввод с клавиатуры.
// Подготовка: состояние ошибки записи и открытое окно ошибки — параметрами обёртки E-DbErr-Dialog-Dark; контроль — та же обёртка без dbw/dialog.
import { context, open, wrapper, ok, crash, finish, has, text, disabled, chip, W } from './lib.mjs';
async function fillCommands(page) {
  // имя и команда первой проверки: набор с клавиатуры (поле очищается выделением всего текста)
  for (const [sel, val] of [['#cfg-n-0', 'lint'], ['#cfg-c-0', 'npm run lint']]) {
    if (!(await has(page, sel))) return false;
    await page.locator(sel).click(); await page.keyboard.press('ControlOrMeta+A'); await page.keyboard.type(val, { delay: 5 });
  }
  return (await page.inputValue('#cfg-n-0')) === 'lint' && (await page.inputValue('#cfg-c-0')) === 'npm run lint';
}
try {
  const ctx = await context({ width: 1440, height: 900 });
  for (const theme of ['dark', 'light']) {
    const G = 'B-02 путь «б» · ' + theme;
    let page = await open(ctx, wrapper('E-DbErr-Dialog-Dark', { theme }));
    await page.locator('#dlg-close').click(); await W(300);
    await page.locator('#sb-csv').click(); await W(500);
    ok(G, 'сессия «Тесты парсера CSV» открыта мышью, её статус «Готово к ревью» не затёрт общей ошибкой', ((await text(page, '#sess-title')) || '').includes('Тесты парсера CSV') && ((await chip(page)) || '').includes('Готово к ревью'), await chip(page), 'отказ записи — параметр обёртки');
    ok(G, 'общая недоступность записи видна в этой сессии: индикатор, предупреждение, примечание инспектора', ((await text(page, '#db-chip')) || '').includes('Запись состояния недоступна') && (await page.evaluate(() => document.body.innerText)).includes('а не только в этой') && (await has(page, '#db-note')));
    ok(G, 'чтение доступно: вкладки и результат открываются', (await disabled(page, '#tab-checks')) !== true);
    await page.locator('#tab-checks').click(); await W(250);
    await page.locator('#cfg-open2').click(); await W(500);
    ok(G, 'окно настройки команд проверок открывается (открытие формы не является побочным эффектом)', await has(page, '#dlg') && await has(page, '#dlg-go'));
    ok(G, 'команды набраны с клавиатуры', await fillCommands(page), { n: await page.inputValue('#cfg-n-0').catch(() => null) });
    await page.locator('#dlg-cons').click(); await W(200);
    ok(G, 'согласие отмечено нажатием мыши', await page.isChecked('#dlg-cons'));
    ok(G, '«Сохранить и разрешить» недоступна даже при согласии; в окне — «действие не будет выполнено»', (await disabled(page, '#dlg-go')) === true && ((await text(page, '#dlg-body')) || '').includes('действие не будет выполнено'));
    ok(G, 'причина в подвале и кнопка «Состояние записи…» (действие восстановления) доступна', ((await text(page, '#dlg-foot')) || '').includes('Запись состояния недоступна') && (await disabled(page, '#dlg-dbstate')) === false);
    await page.locator('#dlg-go').click({ force: true }); await W(400);           // настоящее нажатие мыши по отключённой кнопке
    await page.locator('#cfg-c-0').click(); await page.keyboard.press('Enter'); await W(400); // и Enter в поле команды
    ok(G, 'попытка сохранения (мышью по кнопке и Enter в поле) ничего не сохранила, окно осталось', !(await page.evaluate(() => document.body.innerText)).includes('Проверки сохранены') && await has(page, '#dlg-go'));
    await page.locator('#dlg-dbstate').click(); await W(400);
    ok(G, '«Состояние записи…» открывает окно ошибки записи (восстановление доступно)', ((await text(page, '#dlg')) || '').includes('Состояние не сохраняется') && await has(page, '#dlg-close'), ((await text(page, '#dlg')) || '').slice(0, 120));
    ok(G, 'ошибок страницы нет', page._errs.length === 0, page._errs);
    await page.close();

    const C = 'B-02 контроль без сбоя · ' + theme;
    page = await open(ctx, wrapper('E-DbErr-Dialog-Dark', { theme, attrs: { dbw: null, dbv: null, dialog: null } }));
    ok(C, 'в контроле нет индикатора ошибки записи', !(await has(page, '#db-chip')), null, 'та же обёртка без dbw/dialog');
    await page.locator('#sb-csv').click(); await W(500);
    await page.locator('#tab-checks').click(); await W(250);
    await page.locator('#cfg-open2').click(); await W(500);
    ok(C, 'команды набраны с клавиатуры', await fillCommands(page));
    await page.locator('#dlg-cons').click(); await W(200);
    ok(C, '«Сохранить и разрешить» доступна при согласии', (await disabled(page, '#dlg-go')) === false);
    await page.locator('#dlg-go').click(); await W(1500);
    ok(C, 'конфигурация сохранена', (await page.evaluate(() => document.body.innerText)).includes('Проверки сохранены'));
    await page.close();

    // путь «а»: новая сессия при отказе записи — нажатия мышью
    const A = 'B-02 путь «а» · ' + theme;
    page = await open(ctx, wrapper('E-DbErr-Dialog-Dark', { theme }));
    await page.locator('#dlg-close').click(); await W(300);
    await page.locator('#btn-new').click(); await W(500);
    ok(A, 'форма новой сессии открывается', await has(page, '#ns-create'));
    for (const id of await page.evaluate(() => [...document.querySelectorAll('#ns-scroll input[type=checkbox]')].filter((c) => !c.checked && /ns-(trust|consent)/.test(c.id)).map((c) => c.id))) await page.locator('#' + id).click();
    await W(250);
    ok(A, '«Создать сессию» недоступна при заполненной форме; причина над формой и в подвале', (await disabled(page, '#ns-create')) === true && ((await text(page, '#ns-dbw')) || '').includes('создать сессию и пройти подготовку нельзя') && ((await text(page, '#ns-dbwhy')) || '').includes('во всех сессиях и проектах'));
    await page.locator('#ns-create').click({ force: true }); await W(1800);
    ok(A, 'нажатие по отключённой кнопке подготовку не начало', !(await has(page, '#ns-ph')) && !(await page.evaluate(() => document.body.innerText)).includes('Создаём рабочую копию'));
    await page.close();
    page = await open(ctx, wrapper('N1-New-Dark', { theme }));
    for (const id of await page.evaluate(() => [...document.querySelectorAll('#ns-scroll input[type=checkbox]')].filter((c) => !c.checked && /ns-(trust|consent)/.test(c.id)).map((c) => c.id))) await page.locator('#' + id).click();
    await W(250); await page.locator('#ns-create').click(); await W(900);
    ok('B-02 контроль «а» · ' + theme, 'без сбоя: подготовка начинается', ((await text(page, '#ns-ph')) || '').includes('Создаём рабочую копию'));
    await W(5500);
    ok('B-02 контроль «а» · ' + theme, 'без сбоя: сессия создана', ((await text(page, '#ns-ph')) || '').includes('Сессия создана'));
    await page.close();
  }
  await ctx.close();
} catch (e) { crash(e); } finally { await finish(); }
