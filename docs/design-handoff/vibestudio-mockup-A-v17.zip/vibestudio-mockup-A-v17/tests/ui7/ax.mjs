// Дерево доступности Chrome (CDP Accessibility.getFullAXTree) — то, что браузер передаёт вспомогательным технологиям.
// ЭТО НЕ ПРОВЕРКА VOICEOVER: озвучивание, порядок чтения и поведение VoiceOver на macOS здесь не проверяются.
// Проверяется: имена интерактивных элементов, окно как dialog с именем и modal, недоступность фона при открытом окне,
// ошибки как alert/status с текстом, живая область, вкладки. Возврат фокуса — настоящими нажатиями мыши и Escape.
import { context, open, wrapper, ok, crash, finish, active, W } from './lib.mjs';
const INTERACTIVE = new Set(['button', 'link', 'checkbox', 'radio', 'textbox', 'combobox', 'tab', 'menuitem', 'switch', 'searchbox', 'spinbutton', 'slider', 'listbox', 'option']);
const STATES = [['D-Solo-Running-Dark'], ['D-Long-Light'], ['N1-New-Dark'], ['N3-New-NoAuth-Dark', 'err', 'вход', '#ns-create'], ['W-NotGit-Light', 'err', 'не Git-репозиторий', '#ap-add-off'], ['R-Review-Light'], ['E-DbErr-Banner-Light', 'err', 'Состояние не сохраняется', '#send'], ['E-DbErr-Dialog-Dark', 'dlg'], ['O-Apply-Dark', 'dlg'], ['X-Restart-Dialog-Dark', 'dlg'], ['P-Perm-Dialog-Dark', 'dlg'], ['L-Rules-New-Dark', 'dlg'], ['AR-Fail-Dark', 'dlg'], ['G-Orphan-Known-Light', 'dlg'], ['K-Config-Dark', 'dlg']];
async function tree(ctx, page) {
  const cdp = await ctx.newCDPSession(page); await cdp.send('Accessibility.enable');
  const { nodes } = await cdp.send('Accessibility.getFullAXTree'); await cdp.detach();
  const by = new Map(nodes.map((n) => [n.nodeId, n]));
  const prop = (n, k) => { const p = (n.properties || []).find((x) => x.name === k); return p ? p.value.value : undefined; };
  return { nodes, by, prop, role: (n) => n.role && n.role.value, name: (n) => (n.name && n.name.value || '').trim() };
}
const desc = (t, root) => { const s = new Set(); const st = [root]; while (st.length) { const n = st.pop(); s.add(n.nodeId); for (const c of n.childIds || []) { const x = t.by.get(c); if (x) st.push(x); } } return s; };
try {
  const ctx = await context({ width: 1440, height: 900 });
  for (const [base, kind, errText, errBtn] of STATES) {
    const G = 'Дерево доступности · ' + base;
    const page = await open(ctx, wrapper(base, {}));
    await W(300);
    const t = await tree(ctx, page);
    const live = t.nodes.filter((n) => !n.ignored && ['polite', 'assertive'].includes(t.prop(n, 'live')));
    const inter = t.nodes.filter((n) => !n.ignored && INTERACTIVE.has(t.role(n)));
    const noname = inter.filter((n) => !t.name(n)).map((n) => t.role(n) + '#' + (n.backendDOMNodeId || ''));
    ok(G, 'у всех интерактивных элементов есть доступное имя (' + inter.length + ')', inter.length > 0 && noname.length === 0, noname.slice(0, 10));
    ok(G, 'есть живая область (status/alert) для объявлений', live.length >= 1, live.map((n) => t.role(n)));
    if (kind === 'dlg') {
      const d = t.nodes.filter((n) => !n.ignored && ['dialog', 'alertdialog'].includes(t.role(n)));
      ok(G, 'окно — dialog/alertdialog с именем и modal=true', d.length >= 1 && d.every((n) => t.name(n) && t.prop(n, 'modal') === true), d.map((n) => ({ role: t.role(n), name: t.name(n), modal: t.prop(n, 'modal') })));
      if (d.length) {
        const inside = desc(t, d[d.length - 1]);
        const leak = inter.filter((n) => !inside.has(n.nodeId)).map((n) => t.role(n) + ': ' + t.name(n));
        ok(G, 'элементы за окном недоступны вспомогательным технологиям (inert)', leak.length === 0, leak.slice(0, 10));
      }
    }
    if (kind === 'err') {
      // ошибка сообщена: её текст в живой области (alert/status) или в доступном описании заблокированного действия
      const liveTxt = await page.evaluate(() => [...document.querySelectorAll('[role=alert],[role=status],[aria-live]')].filter((e) => !e.closest('[inert]')).map((e) => e.innerText.trim()).filter(Boolean));
      let descr = '';
      if (errBtn && await page.evaluate((s) => !!document.querySelector(s), errBtn)) { const cdp = await ctx.newCDPSession(page); const o = await cdp.send('Runtime.evaluate', { expression: 'document.querySelector(' + JSON.stringify(errBtn) + ')' }); const dn = await cdp.send('DOM.describeNode', { objectId: o.result.objectId }); const { nodes } = await cdp.send('Accessibility.getPartialAXTree', { backendNodeId: dn.node.backendNodeId, fetchRelatives: false }); descr = (nodes[0].description && nodes[0].description.value) || ''; await cdp.detach(); }
      const inLive = liveTxt.some((x) => x.includes(errText)), inDescr = descr.toLowerCase().includes(errText.toLowerCase());
      ok(G, 'ошибка «' + errText + '» сообщается: живая область или описание заблокированного действия', inLive || inDescr, { liveTxt: liveTxt.map((x) => x.slice(0, 80)), descr });
    }
    const tabs = t.nodes.filter((n) => !n.ignored && t.role(n) === 'tab');
    if (tabs.length) ok(G, 'вкладки: роль tab, ровно одна выбрана', tabs.filter((n) => t.prop(n, 'selected') === true).length === 1, tabs.map((n) => t.name(n) + ':' + t.prop(n, 'selected')));
    // возврат фокуса после закрытия окна (настоящие нажатия): кнопка закрытия мышью и Escape
    if (kind === 'dlg' && await page.evaluate(() => !!document.getElementById('dlg-close'))) {
      await page.locator('#dlg-close').click(); await W(300);
      const a = await active(page);
      ok(G, 'после закрытия окна мышью фокус в сессии, а не на body', a && a !== 'BODY' && !(await page.evaluate(() => !!document.getElementById('dlg'))), a);
    }
    await page.close();
  }
  // возврат фокуса к кнопке, открывшей окно: кнопки с «…» в названии открывают окно (соглашение макета);
  // открыть клавишей Enter, закрыть Escape; затем открыть мышью и закрыть кнопкой «Закрыть»
  for (const base of ['A-Done-Dark', 'E-DbErr-Banner-Light', 'K-NotRun-Light']) {
    const page = await open(ctx, wrapper(base, {}));
    const btns = await page.evaluate(() => [...document.querySelectorAll('main button:not([disabled]), #in-panel button:not([disabled])')].filter((b) => /…$/.test(b.innerText.trim()) && b.id && b.getClientRects().length).map((b) => b.id).slice(0, 3));
    ok('Возврат фокуса · ' + base, 'есть кнопки, открывающие окно (' + btns.join(', ') + ')', btns.length > 0, btns);
    for (const btn of btns) {
      await page.locator('#' + btn).focus(); await page.keyboard.press('Enter'); await W(450);
      const opened = await page.evaluate(() => !!document.getElementById('dlg'));
      const inDlg = await page.evaluate(() => !!document.activeElement && !!document.activeElement.closest('#dlg'));
      await page.keyboard.press('Escape'); await W(400);
      const back = await active(page), closed = !(await page.evaluate(() => !!document.getElementById('dlg')));
      ok('Возврат фокуса · ' + base, '#' + btn + ': Enter открывает окно, фокус внутри; Escape закрывает и возвращает фокус на кнопку', opened && inDlg && closed && back === btn, { opened, inDlg, closed, back }, 'фокус на кнопке — locator.focus()');
      if (opened) {
        await page.locator('#' + btn).click(); await W(450);
        const closer = await page.evaluate(() => { const b = [...document.querySelectorAll('#dlg button:not([disabled])')].find((x) => /^(Закрыть|Отмена)$/.test(x.innerText.trim())); if (!b) return null; if (!b.id) b.id = 'ui7-dlg-closer'; return b.id; });
        if (closer) { const label = (await page.locator('#' + closer).innerText()).trim(); await page.locator('#' + closer).click(); await W(400);
          ok('Возврат фокуса · ' + base, '#' + btn + ': открыто мышью, закрыто кнопкой «' + label + '» — фокус на кнопке', (await active(page)) === btn && !(await page.evaluate(() => !!document.getElementById('dlg'))), await active(page), closer.startsWith('ui7-') ? 'у кнопки закрытия нет id: назначен временный' : ''); }
        else { await page.keyboard.press('Escape'); await W(400); }
      }
    }
    await page.close();
  }
  await ctx.close();
} catch (e) { crash(e); } finally { await finish(); }
