// Нативные флажки и радиокнопки в обеих темах: контраст по отрисованным пикселям, клавиатура, видимый фокус, подпись.
// Контраст: снимок области вокруг элемента при плотности 2; фон — самый частый цвет кольца шириной 5 px снаружи элемента;
// контраст элемента — наибольший контраст пикселя внутри элемента к этому фону (порог WCAG 1.4.11 — 3:1).
// Клавиатура: подготовка — focus() на самом элементе; проверяемые действия — Shift+Tab, Tab (возврат на элемент), Space, стрелки.
import { context, open, wrapper, ok, crash, finish, note, W, png } from './lib.mjs';
const lin = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
const L = (r, g, b) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
const CR = (a, b) => { const x = L(...a), y = L(...b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
async function measure(page, sel) {
  const r = await page.evaluate((s) => { const e = document.querySelector(s); e.scrollIntoView({ block: 'center' }); const b = e.getBoundingClientRect(); return { x: b.x, y: b.y, w: b.width, h: b.height }; }, sel);
  const M = 5, clip = { x: Math.max(0, r.x - M), y: Math.max(0, r.y - M), width: r.w + 2 * M, height: r.h + 2 * M };
  const img = png(await page.screenshot({ clip, animations: 'disabled', caret: 'hide' })), s = img.w / clip.width;
  const ix0 = Math.round((r.x - clip.x) * s), iy0 = Math.round((r.y - clip.y) * s), ix1 = Math.round((r.x - clip.x + r.w) * s), iy1 = Math.round((r.y - clip.y + r.h) * s);
  const cnt = new Map(); let best = 0, bestPx = null;
  const at = (x, y) => { const i = (y * img.w + x) * 4; return [img.px[i], img.px[i + 1], img.px[i + 2]]; };
  for (let y = 0; y < img.h; y++) for (let x = 0; x < img.w; x++) { const inside = x >= ix0 && x < ix1 && y >= iy0 && y < iy1; if (!inside) { const k = at(x, y).join(','); cnt.set(k, (cnt.get(k) || 0) + 1); } }
  const bg = [...cnt.entries()].sort((a, b) => b[1] - a[1])[0][0].split(',').map(Number);
  for (let y = iy0; y < iy1; y++) for (let x = ix0; x < ix1; x++) { const c = CR(at(x, y), bg); if (c > best) { best = c; bestPx = at(x, y); } }
  return { contrast: +best.toFixed(2), bg: 'rgb(' + bg + ')', edge: bestPx && 'rgb(' + bestPx + ')' };
}
const STATES = ['N1-New-Dark', 'W-Selected-Light', 'K-Config-Dark', 'K-Consent-Missing-Dark', 'O-Bypass-Dark', 'L-Rules-New-Dark', 'L-Rules-Delete-Light', 'Q-PCtx-Confirm-Dark', 'X-CtxLost-Light'];
const summary = { checkbox: { dark: [], light: [] }, radio: { dark: [], light: [] } };
try {
  const ctx = await context({ width: 1440, height: 900, dsf: 2 });
  for (const base of STATES) for (const theme of ['dark', 'light']) {
    const page = await open(ctx, wrapper(base, { theme }));
    const inputs = await page.evaluate(() => [...document.querySelectorAll('input[type=checkbox],input[type=radio]')].filter((e) => !e.disabled && e.getClientRects().length && !e.closest('[inert]')).map((e, i) => { if (!e.id) e.id = 'ui7-in-' + i; const nm = (e.labels && e.labels.length ? [...e.labels].map((l) => l.innerText).join(' ') : '') || e.getAttribute('aria-label') || (e.getAttribute('aria-labelledby') ? document.getElementById(e.getAttribute('aria-labelledby'))?.innerText : ''); return { id: e.id, type: e.type, name: (nm || '').trim().slice(0, 60), group: e.name || '' }; }));
    if (!inputs.length) { note(base + '/' + theme + ': нет доступных флажков и радиокнопок'); await page.close(); continue; }
    const doneGroups = new Set();
    for (const inp of inputs) {
      const G = 'Нативные ' + (inp.type === 'checkbox' ? 'флажки' : 'радиокнопки') + ' · ' + base + '/' + theme;
      const sel = '#' + inp.id;
      ok(G, inp.id + ': есть доступное имя (подпись)', inp.name.length > 0, inp, inp.id.startsWith('ui7-') ? 'у элемента нет id: назначен временный id для адресации' : '');
      const c0 = await measure(page, sel);
      summary[inp.type][theme].push({ state: base, id: inp.id, checked: await page.isChecked(sel), contrast: c0.contrast });
      ok(G, inp.id + ': контраст границы к фону ≥ 3:1 (' + (await page.isChecked(sel) ? 'отмечен' : 'не отмечен') + ')', c0.contrast >= 3, c0);
      if (inp.type === 'checkbox') {
        await page.evaluate((s) => document.querySelector(s).focus(), sel); await page.keyboard.press('Shift+Tab'); await page.keyboard.press('Tab');
        const back = await page.evaluate((s) => document.activeElement === document.querySelector(s), sel);
        const fv = await page.evaluate((s) => { const e = document.querySelector(s), cs = getComputedStyle(e); return { fv: e.matches(':focus-visible'), outline: cs.outlineStyle + ' ' + cs.outlineWidth, shadow: cs.boxShadow }; }, sel);
        ok(G, inp.id + ': достижим клавишей Tab, фокус виден (:focus-visible и контур)', back && fv.fv && ((fv.outline.split(' ')[0] !== 'none' && parseFloat(fv.outline.split(' ')[1]) > 0) || fv.shadow !== 'none'), fv, 'focus() на элементе, затем Shift+Tab и Tab');
        const before = await page.isChecked(sel); await page.keyboard.press('Space'); await W(120);
        const after = await page.isChecked(sel);
        ok(G, inp.id + ': Space переключает', after !== before, { before, after });
        const c1 = await measure(page, sel);
        summary.checkbox[theme].push({ state: base, id: inp.id, checked: after, contrast: c1.contrast });
        ok(G, inp.id + ': контраст в другом состоянии (' + (after ? 'отмечен' : 'не отмечен') + ') ≥ 3:1', c1.contrast >= 3, c1);
        if (await page.evaluate((s) => !!document.querySelector(s), sel)) { await page.evaluate((s) => document.querySelector(s).focus(), sel); await page.keyboard.press('Space'); await W(120); }
      } else if (!doneGroups.has(inp.group)) {
        doneGroups.add(inp.group);
        const grp = inputs.filter((x) => x.type === 'radio' && x.group === inp.group);
        const cur = (await page.evaluate((g) => { const c = [...document.querySelectorAll('input[type=radio]')].find((e) => e.name === g && e.checked); return c ? c.id : null; }, inp.group)) || grp[0].id;
        await page.evaluate((s) => document.querySelector(s).focus(), '#' + cur); await page.keyboard.press('Shift+Tab'); await page.keyboard.press('Tab');
        const fv = await page.evaluate(() => { const e = document.activeElement, cs = getComputedStyle(e); return { id: e.id, type: e.type, fv: e.matches(':focus-visible'), outline: cs.outlineStyle + ' ' + cs.outlineWidth }; });
        ok(G, 'группа «' + (inp.group || '—') + '»: Tab приводит к выбранной радиокнопке, фокус виден', fv.type === 'radio' && fv.fv && fv.outline.split(' ')[0] !== 'none', fv, 'focus() на выбранной радиокнопке, затем Shift+Tab и Tab');
        if (grp.length > 1) {
          await page.keyboard.press('ArrowDown'); await W(150);
          const moved = await page.evaluate(() => ({ id: document.activeElement.id, checked: document.activeElement.checked, type: document.activeElement.type }));
          ok(G, 'группа «' + (inp.group || '—') + '»: стрелка переводит выбор на соседнюю радиокнопку', moved.type === 'radio' && moved.checked && moved.id !== fv.id, moved);
        }
      }
    }
    ok('Нативные · ' + base + '/' + theme, 'ошибок страницы нет', page._errs.length === 0, page._errs);
    await page.close();
  }
  const mins = {}; for (const t of ['checkbox', 'radio']) for (const th of ['dark', 'light']) { const a = summary[t][th]; mins[t + '/' + th] = a.length ? Math.min(...a.map((x) => x.contrast)) : null; }
  note('минимальный контраст: ' + JSON.stringify(mins));
  (await import('./lib.mjs')).setNote('nativeContrast', { min: mins, samples: summary });
  await ctx.close();
} catch (e) { crash(e); } finally { await finish(); }
