// A-09: запись результата применения при закрытом окне. Все переходы — настоящие нажатия мыши.
// Подготовка: состояние — параметрами обёртки; переключатель «Только в макете: состояние записи» (#dlg-sim-db) —
// selectOption (это управление имитацией, а не действие пользователя приложения); наблюдатель живой области (только чтение).
import { context, open, wrapper, ok, crash, finish, has, text, disabled, chip, watchLive, liveLog, W } from './lib.mjs';
const REC = { scenario: 'done', conflict: 'interrupted', dialog: 'reconcile', rkind: 'apply', ar: 'completed' };
const PREP_SIM = 'переключатель имитации #dlg-sim-db → «up» (selectOption)';
try {
  const ctx = await context({ width: 1440, height: 900 });
  for (const theme of ['dark', 'light']) {
    const T = ' · ' + theme;
    // 1. Закрытие на разных стадиях записи после «Выполнить сверку»
    for (const [label, at] of [['сразу после начала записи', 1300], ['в середине записи', 2100], ['после завершения записи', 3100]]) {
      const page = await open(ctx, wrapper('AR-Fail-Dark', { theme, attrs: Object.assign({}, REC, { dstep: null, wr: null }) }));
      await watchLive(page);
      await page.locator('#dlg-run').click(); await W(at);
      const closable = await has(page, '#dlg-close'); if (closable) await page.locator('#dlg-close').click();
      await W(250);
      const during = { dlg: await has(page, '#dlg'), recop: await has(page, '#recop'), chip: await chip(page) };
      if (at < 3000 && during.recop) {
        await page.locator('#recop-show').click(); await W(300);
        const body = (await text(page, '#dlg-body')) || '';
        ok('A-09 стадии' + T, 'закрыто ' + label + ': повторное открытие показывает текущий ход записи, кнопки запуска нет', body.length > 0 && !(await has(page, '#dlg-run')) && !(await has(page, '#dlg-retry-rec')) && !/Выполнить сверку/.test(body.slice(0, 80)), body.slice(0, 160));
        await page.locator('#dlg-close').click();
      }
      await W(Math.max(0, 3800 - at));
      const lv = await liveLog(page);
      ok('A-09 стадии' + T, 'закрыто ' + label + ': запись завершилась, сессия «Применено», окно не нужно', closable && !(await has(page, '#dlg')) && (await chip(page)) === 'Применено', Object.assign(during, { after: await chip(page) }));
      ok('A-09 стадии' + T, 'закрыто ' + label + ': запись начиналась один раз (одно объявление о начале сохранения)', lv.filter((x) => x.includes('Результат сохраняется')).length === 1, lv, 'наблюдатель живой области');
      ok('A-09 стадии' + T, 'закрыто ' + label + ': объявлено завершение записи', lv.some((x) => x.includes('Результат применения сохранён')), lv);
      await page.close();
    }
    // 2. Контроль: окно открыто до конца
    {
      const page = await open(ctx, wrapper('AR-Fail-Dark', { theme, attrs: Object.assign({}, REC, { dstep: null, wr: null }) }));
      await page.locator('#dlg-run').click(); await W(3800);
      ok('A-09 контроль' + T, 'с открытым окном: «Результат сохранён», «Посмотреть результат» доступно, сессия «Применено»', ((await text(page, '#dlg-body')) || '').includes('Результат сохранён') && (await disabled(page, '#dlg-view')) === false && (await chip(page)) === 'Применено');
      await page.close();
    }
    // 3. Ошибка записи при закрытом окне
    {
      const page = await open(ctx, wrapper('AR-Fail-Dark', { theme, attrs: Object.assign({}, REC, { dstep: null, wr: 'fail' }) }));
      await page.locator('#dlg-run').click(); await W(1300); await page.locator('#dlg-close').click(); await W(2500);
      ok('A-09 ошибка' + T, 'отказ записи при закрытом окне: «Применено в Git · запись не сохранена», общий индикатор, изменяющие действия заблокированы', ((await chip(page)) || '').includes('Применено в Git · запись не сохранена') && (await has(page, '#db-chip')) && (await disabled(page, '#send')) === true, await chip(page));
      ok('A-09 ошибка' + T, 'в ленте есть переход к результату записи, сессия не помечена применённой', (await has(page, '#alert-act2')) && !((await page.evaluate(() => document.body.innerText)).includes('Применено: c91d2e8')));
      await page.locator('#alert-act2').click(); await W(350);
      const body = (await text(page, '#dlg-body')) || '';
      ok('A-09 ошибка' + T, 'окно разделяет Git-результат (подтверждён) и сохранение (не удалось), «Повторить сохранение» доступно', body.includes('Git-результат подтверждён') && body.includes('Результат применения не сохранён') && (await disabled(page, '#dlg-retry-rec')) === false);
      await page.close();
    }
    // 4. Повтор с закрытием через 150 мс и повторным открытием (сценарий ревью)
    {
      const page = await open(ctx, wrapper('AR-Fail-Dark', { theme }));
      await watchLive(page);
      await page.selectOption('#dlg-sim-db', 'up'); await W(200);
      await page.locator('#dlg-retry-rec').click(); await W(150); await page.locator('#dlg-close').click(); await W(300);
      ok('A-09 повтор' + T, 'окно закрыто через 150 мс: блок хода записи в ленте, статус «запись не сохранена»', !(await has(page, '#dlg')) && (await has(page, '#recop')) && ((await chip(page)) || '').includes('запись не сохранена'), await chip(page), PREP_SIM);
      await page.locator('#recop-show').click(); await W(300);
      ok('A-09 повтор' + T, 'повторное открытие: идёт запись, «Повторить сохранение» нет, «Посмотреть результат» недоступна', ((await text(page, '#dlg-body')) || '').includes('Выполняется') && !(await has(page, '#dlg-retry-rec')) && (await disabled(page, '#dlg-view')) === true);
      await W(1900);
      ok('A-09 повтор' + T, 'открытое окно само переходит в «Результат сохранён»', ((await text(page, '#dlg-body')) || '').includes('Результат сохранён'));
      await page.locator('#dlg-close').click(); await W(300);
      const lv = await liveLog(page);
      ok('A-09 повтор' + T, 'сессия «Применено», ошибка записи снята, лента показывает результат', (await chip(page)) === 'Применено' && !(await has(page, '#db-chip')) && (await page.evaluate(() => document.body.innerText)).includes('Применено: c91d2e8'));
      ok('A-09 повтор' + T, 'вторая запись не начиналась: объявление о повторе ровно одно', lv.filter((x) => x.includes('Сверка повторяется, затем результат сохраняется')).length === 1, lv, 'наблюдатель живой области');
      await page.close();
    }
    // 5. Переход в другую сессию во время записи: результат принадлежит исходной сессии
    {
      const page = await open(ctx, wrapper('AR-Fail-Dark', { theme }));
      await page.selectOption('#dlg-sim-db', 'up'); await W(150);
      await page.locator('#dlg-retry-rec').click(); await W(150); await page.locator('#dlg-close').click(); await W(150);
      await page.locator('#sb-csv').click(); await W(450);
      ok('A-09 другая сессия' + T, 'в «Тесты парсера CSV» во время записи общая блокировка действует', ((await text(page, '#db-chip')) || '').includes('Запись состояния недоступна') && (await disabled(page, '#send')) === true, null, PREP_SIM);
      ok('A-09 другая сессия' + T, 'в «Тесты парсера CSV» нет блока хода чужой записи', !(await has(page, '#recop')));
      await W(1800);
      ok('A-09 другая сессия' + T, 'после записи в фоне: блокировка снята, статус «Тесты парсера CSV» прежний', !(await has(page, '#db-chip')) && ((await chip(page)) || '').includes('Готово к ревью'), await chip(page));
      ok('A-09 другая сессия' + T, 'строка исходной сессии в списке — «Применено»', ((await text(page, '#sb-cur')) || '').includes('Применено'), await text(page, '#sb-cur'));
      await page.locator('#sb-cur').click(); await W(450);
      ok('A-09 другая сессия' + T, 'возврат в исходную сессию: «Применено», результат записан в её ленту', (await chip(page)) === 'Применено' && (await page.evaluate(() => document.body.innerText)).includes('Применено: c91d2e8'));
      await page.close();
    }
    // 6. Отказ записи, пока пользователь в другой сессии
    {
      const page = await open(ctx, wrapper('AR-Fail-Dark', { theme, attrs: Object.assign({}, REC, { dstep: null, wr: 'fail' }) }));
      await page.locator('#dlg-run').click(); await W(1300); await page.locator('#dlg-close').click(); await W(150);
      await page.locator('#sb-csv').click(); await W(2400);
      ok('A-09 отказ в другой сессии' + T, 'в другой сессии виден общий индикатор, строка исходной — «запись не сохранена»', (await has(page, '#db-chip')) && ((await text(page, '#sb-cur')) || '').includes('запись не сохранена'), await text(page, '#sb-cur'));
      ok('A-09 отказ в другой сессии' + T, 'статус «Тесты парсера CSV» не затёрт', ((await chip(page)) || '').includes('Готово к ревью'), await chip(page));
      await page.locator('#sb-cur').click(); await W(450);
      ok('A-09 отказ в другой сессии' + T, 'исходная сессия: «Применено в Git · запись не сохранена», переход к результату записи доступен', ((await chip(page)) || '').includes('запись не сохранена') && (await has(page, '#alert-act2')), await chip(page));
      await page.close();
    }
  }
  await ctx.close();
} catch (e) { crash(e); } finally { await finish(); }
