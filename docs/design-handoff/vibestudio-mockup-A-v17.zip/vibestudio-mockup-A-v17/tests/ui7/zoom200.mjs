// Настоящий масштаб браузера 200% (уровень масштаба страницы Chrome в профиле — тот же механизм, что ⌘+), обе темы.
// Приложение раскладывается по реальному окну (обёртка «по размеру окна»), окно браузера 1440×900, 1000×720 и 640×480 точек экрана
// (640×480 — минимальное окно приложения; CSS viewport при 200% — 320×240, фиксируется в detail первой проверки).
// Признак настоящего масштаба: devicePixelRatio = 2, CSS-ширина окна = половина ширины окна, CSS zoom = 1, visualViewport.scale = 1.
// Маленький viewport, масштаб холста и CSS zoom этой проверкой не являются и не используются.
// Проверяемые действия: Tab (настоящие события клавиатуры), колесо мыши, наведение и пробное нажатие Playwright (trial).
// Ключ элемента без id при обходе Tab — тег и позиция в DOM (в версии 16 — тег и текст: две радиокнопки из разных групп
// давали один ключ, и обход останавливался раньше конца).
// Подвал окна — блок .dlg-foot с кнопками (в версии 16 проверка брала подпись #dlg-foot, и проверки кнопок мышью не выполнялись).
// Снимки — CDP Page.captureScreenshot: page.screenshot Playwright при масштабе браузера снимает только левую верхнюю четверть окна
// (ограничение инструмента, проверено 25.10.2026).
import fs from 'node:fs';
import path from 'node:path';
import { context, open, wrapper, ok, crash, finish, note, W } from './lib.mjs';
const OUT = path.resolve(process.env.SHOTS_DIR || path.join(process.env.RESULTS_DIR || 'results-ui7', 'zoom200'));
fs.mkdirSync(OUT, { recursive: true });
const STATES = ['N1-New-Dark', 'W-Selected-Light', 'L-Rules-New-Dark', 'K-Config-Dark', 'O-Apply-Dark', 'O-Bypass-Light', 'E-DbErr-Dialog-Dark', 'X-Restart-Dialog-Dark', 'P-Perm-Dialog-Dark', 'A-Recon-Apply-Dark', 'AR-Fail-Dark', 'Q-PCtx-Confirm-Dark', 'G-Orphan-Known-Light', 'D-Long-Dark', 'D-Solo-Running-Dark', 'R-Review-Light'];
// ZOOM_WINDOWS=640x480 — прогон одного размера (для записи «до/после»); по умолчанию все три окна
const WINDOWS = process.env.ZOOM_WINDOWS ? process.env.ZOOM_WINDOWS.split(',').map((x) => x.split('x').map(Number)) : [[1440, 900], [1000, 720], [640, 480]];
// обрезанный текст: элемент с собственным видимым текстом, у которого содержимое не помещается, а прокрутки нет.
// Если раскладка выше области окна (минимальная высота раскладки 320 CSS px), прокручивается само окно: текст в пределах
// прокручиваемой высоты документа доступен и обрезанным не считается.
const CLIP = () => {
  const out = [], seen = new Set();
  const de = document.documentElement, docY = de.scrollHeight > innerHeight + 1 && !/hidden|clip/.test(getComputedStyle(de).overflowY) && !/hidden|clip/.test(getComputedStyle(document.body).overflowY);
  const scrollY = (cs) => /auto|scroll/.test(cs.overflowY), scrollX = (cs) => /auto|scroll/.test(cs.overflowX);
  for (const e of document.querySelectorAll('body *')) {
    if (/^(SELECT|OPTION|SCRIPT|STYLE|svg|SVG|TEXTAREA|INPUT)$/.test(e.tagName) || e.closest('.sr,[inert],[aria-hidden="true"],svg,select') || !e.getClientRects().length) continue;
    const tn = [...e.childNodes].filter((n) => n.nodeType === 3 && n.textContent.trim());
    if (!tn.length) continue;
    const cs0 = getComputedStyle(e); if (cs0.visibility === 'hidden' || cs0.textOverflow === 'ellipsis') continue;
    const rg = document.createRange(); let tr = null;
    for (const n of tn) { rg.selectNodeContents(n); for (const r of rg.getClientRects()) { if (!r.width) continue; tr = tr ? { l: Math.min(tr.l, r.left), t: Math.min(tr.t, r.top), r: Math.max(tr.r, r.right), b: Math.max(tr.b, r.bottom) } : { l: r.left, t: r.top, r: r.right, b: r.bottom }; } }
    if (!tr) continue;
    let cutX = false, cutY = false, sx = false, sy = false;
    for (let a = e; a && a !== document.documentElement; a = a.parentElement) {
      const cs = getComputedStyle(a), ar = a.getBoundingClientRect();
      if (a !== e && cs.textOverflow === 'ellipsis') { sx = true; }
      if (!sx) { if (scrollX(cs)) sx = true; else if (/hidden|clip/.test(cs.overflowX) && (tr.r > ar.right + 1 || tr.l < ar.left - 1)) cutX = true; }
      if (!sy) { if (scrollY(cs)) sy = true; else if (/hidden|clip/.test(cs.overflowY) && (tr.b > ar.bottom + 1 || tr.t < ar.top - 1)) cutY = true; }
    }
    if (!sx && (tr.r > innerWidth + 1 || tr.l < -1)) cutX = true;
    if (!sy && (docY ? (tr.b > de.scrollHeight - scrollY + 1 || tr.t < -scrollY - 1) : (tr.b > innerHeight + 1 || tr.t < -1))) cutY = true;
    if ((cutX || cutY) && !seen.has(e)) { seen.add(e); out.push({ id: e.id || e.tagName, axis: (cutX ? 'x' : '') + (cutY ? 'y' : ''), text: e.textContent.trim().slice(0, 50), tr: [Math.round(tr.l), Math.round(tr.t), Math.round(tr.r), Math.round(tr.b)], vw: [innerWidth, innerHeight] }); }
  }
  const ell = [...document.querySelectorAll('body *')].filter((e) => !e.closest('.sr,[inert]') && e.getClientRects().length && getComputedStyle(e).textOverflow === 'ellipsis' && e.scrollWidth > e.clientWidth + 1).map((e) => ({ id: e.id || e.tagName, text: e.innerText.slice(0, 50), title: e.getAttribute('title') || (e.closest('[title]') ? e.closest('[title]').getAttribute('title') : '') }));
  return { cut: out, ellipsis: ell };
};
// точка над участком без собственной прокрутки (ни один предок, кроме документа, не прокручивается по вертикали)
const PLAIN = () => {
  for (let y = 4; y < innerHeight - 2; y += 8) for (const x of [4, innerWidth / 2, innerWidth - 12]) {
    const e = document.elementFromPoint(x, y); if (!e) continue; let own = false;
    for (let a = e; a && a !== document.documentElement && a !== document.body; a = a.parentElement) { const cs = getComputedStyle(a); if (/auto|scroll/.test(cs.overflowY) && a.scrollHeight > a.clientHeight + 1) { own = true; break; } }
    if (!own && !/^(TEXTAREA|SELECT|INPUT)$/.test(e.tagName)) return [x, y];
  }
  return null;
};
try {
  for (const [ww, wh] of WINDOWS) {
    const ctx = await context({ zoom: 200, width: ww, height: wh });
    for (const base of STATES) for (const theme of ['dark', 'light']) {
      const G = 'Масштаб 200% · ' + base + '/' + theme + ' · окно ' + ww + '×' + wh;
      const page = await open(ctx, wrapper(base, { theme, fill: true }));
      await W(300);
      const vp = await page.evaluate(() => ({ dpr: devicePixelRatio, iw: innerWidth, ih: innerHeight, ow: outerWidth, oh: outerHeight, css: getComputedStyle(document.documentElement).zoom, vv: visualViewport ? visualViewport.scale : null, layoutH: document.documentElement.scrollHeight }));
      const docScroll = vp.layoutH > vp.ih + 1;
      ok(G, 'настоящий масштаб браузера 200% (devicePixelRatio 2, CSS-ширина = половина окна, CSS zoom 1, visualViewport 1)', vp.dpr === 2 && Math.abs(vp.iw * 2 - vp.ow) <= 2 && vp.css === '1' && vp.vv === 1, vp);
      if (docScroll) {
        // раскладка выше области окна: окно прокручивается колесом мыши до низа раскладки и обратно. Курсор ставится над участком
        // без собственной прокрутки (шапка, подвал формы, затемнение). Если такого участка в области окна нет (её целиком занимает
        // форма или ревью со своей прокруткой), колесо крутится над серединой: браузер сначала листает форму до конца, затем
        // передаёт прокрутку окну (так же, как у пользователя; серии событий разделены паузой).
        const wheelDoc = async (dy) => { const via = new Set(); for (let k = 0; k < 40; k++) {
            const st = await page.evaluate(() => [scrollY, document.documentElement.scrollHeight - innerHeight]); if (dy > 0 ? st[0] >= st[1] - 1 : st[0] <= 0) break;
            const pt = await page.evaluate(PLAIN); via.add(pt ? 'участок без своей прокрутки' : 'через прокрутку формы');
            await page.mouse.move(...(pt || [vp.iw / 2, vp.ih / 2])); for (let i = 0; i < 4; i++) await page.mouse.wheel(0, dy); await W(250); }
          return [...via].join(', '); };
        const e1 = await wheelDoc(120); const down = await page.evaluate(() => [scrollY, document.documentElement.scrollHeight - innerHeight]);
        const e2 = await wheelDoc(-120); const up = await page.evaluate(() => scrollY);
        ok(G, 'раскладка ' + vp.layoutH + ' CSS px выше области окна ' + vp.ih + ': окно прокручивается колесом мыши до низа раскладки и обратно', down[0] >= down[1] - 1 && down[1] > 0 && up === 0, { down, up, вниз: e1, вверх: e2 }, 'начальная прокрутка 0');
      }
      ok(G, 'нет горизонтальной прокрутки страницы', await page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth + 1), await page.evaluate(() => [document.documentElement.scrollWidth, document.documentElement.clientWidth]));
      const clip = await page.evaluate(CLIP);
      ok(G, 'текст не обрезан (нет переполнения без прокрутки)', clip.cut.length === 0, clip.cut.slice(0, 6));
      ok(G, 'текст, сокращённый многоточием, доступен полностью через title', clip.ellipsis.every((x) => x.title), clip.ellipsis.filter((x) => !x.title).slice(0, 6));
      const dlg = await page.evaluate(() => { const d = document.getElementById('dlg'); if (!d) return null; const r = d.getBoundingClientRect(); const f = document.querySelector('#dlg .dlg-foot'); const fr = f ? f.getBoundingClientRect() : null; return { x: r.x, y: r.y, r: r.right, b: r.bottom, iw: innerWidth, ih: innerHeight, foot: fr && { y: fr.y, b: fr.bottom } }; });
      if (dlg && !docScroll) {
        ok(G, 'окно помещается в область просмотра', dlg.x >= -1 && dlg.y >= -1 && dlg.r <= dlg.iw + 1 && dlg.b <= dlg.ih + 1, dlg);
        ok(G, 'подвал окна с действиями виден целиком', !dlg.foot || (dlg.foot.y >= -1 && dlg.foot.b <= dlg.ih + 1), dlg.foot);
      }
      if (dlg && docScroll) {
        // область окна ниже раскладки: окно умещается в раскладку по ширине и высоте, подвал с действиями становится виден целиком
        // после прокрутки колесом мыши (курсор над затемнением слева от окна)
        ok(G, 'окно помещается в раскладку ' + vp.iw + '×' + vp.layoutH + ' CSS px', dlg.x >= -1 && dlg.y >= -1 && dlg.r <= dlg.iw + 1 && dlg.b <= vp.layoutH + 1, dlg);
        await page.mouse.move(Math.max(dlg.x / 2, 2), 8); for (let i = 0; i < 12; i++) await page.mouse.wheel(0, 120); await W(400);
        const ft = await page.evaluate(() => { const r = document.querySelector('#dlg .dlg-foot').getBoundingClientRect(); return { y: r.y, b: r.bottom, ih: innerHeight, sy: scrollY }; });
        ok(G, 'подвал окна с действиями виден целиком после прокрутки колесом мыши', ft.y >= -1 && ft.b <= ft.ih + 1, ft, 'начальная прокрутка 0');
      }
      if (dlg) {
        const foot = await page.evaluate(() => [...document.querySelectorAll('#dlg .dlg-foot button:not([disabled])')].map((b) => b.id).filter(Boolean));
        for (const id of foot) {
          let can = true; try { await page.locator('#' + id).click({ trial: true, timeout: 2500 }); } catch (e) { can = String(e).split('\n')[0]; }
          ok(G, 'кнопка «' + ((await page.locator('#' + id).innerText()).trim().slice(0, 40)) + '» доступна мыши (видима, не перекрыта)', can === true, can);
        }
      }
      // прокрутка колесом мыши: контейнер — прокручиваемый предок элемента под курсором (до обхода Tab)
      const pickScroll = (inDlg) => page.evaluate((inDlg) => {
        const cands = [...document.querySelectorAll(inDlg ? '#dlg *' : 'main *, #ns-scroll, #ap-scroll, #rv-scroll')].filter((e) => /auto|scroll/.test(getComputedStyle(e).overflowY) && e.scrollHeight > e.clientHeight + 20 && e.getClientRects().length && !e.closest('[inert]') && e.tagName !== 'TEXTAREA' && (inDlg || !e.closest('#dlg')));
        for (const c of cands) { const r = c.getBoundingClientRect(); for (const fy of [0.5, 0.25, 0.75]) { const x = r.left + r.width / 2, y = r.top + r.height * fy; if (y < 0 || y > innerHeight) continue; const hit = document.elementFromPoint(x, y); if (hit && c.contains(hit)) { document.querySelectorAll('[data-ui7-scroll]').forEach((z) => z.removeAttribute('data-ui7-scroll')); c.setAttribute('data-ui7-scroll', '1'); c.scrollTop = 0; return { x, y, id: c.id || c.tagName, max: c.scrollHeight - c.clientHeight, rev: /reverse/.test(getComputedStyle(c).flexDirection) }; } } }
        return null; }, inDlg);
      const sc = await pickScroll(!!dlg);
      // лента сессии прижата к низу (flex-direction: column-reverse): scrollTop 0 — низ, прокрутка к началу идёт вверх (отрицательные значения)
      if (sc) { await page.mouse.move(sc.x, sc.y); for (let i = 0; i < 80; i++) await page.mouse.wheel(0, sc.rev ? -120 : 120); await W(400);
        const end = await page.evaluate(() => { const c = document.querySelector('[data-ui7-scroll]'); return { top: c.scrollTop, max: c.scrollHeight - c.clientHeight }; });
        ok(G, (dlg ? 'содержимое окна' : 'основная область') + ' (' + sc.id + (sc.rev ? ', лента прижата к низу' : '') + ') прокручивается колесом мыши до ' + (sc.rev ? 'начала' : 'конца'), Math.abs(end.top) > 0 && Math.abs(end.top) >= end.max - 2, end, 'контейнер найден по стилю и попаданию курсора, помечен data-ui7-scroll, начальная прокрутка 0');
        await page.evaluate(() => { const c = document.querySelector('[data-ui7-scroll]'); if (c) c.scrollTop = 0; }); }
      // обход клавишей Tab: каждый элемент в фокусе виден целиком и имеет видимый индикатор фокуса
      const scope = dlg ? '#dlg' : 'body';
      await page.evaluate((s) => { const r = document.querySelector(s); const f = [...r.querySelectorAll('button:not([disabled]),a[href],input:not([disabled]),textarea,select,summary,[tabindex]')].find((e) => e.tabIndex >= 0 && e.getClientRects().length && !e.closest('[inert]')); if (f) f.focus(); }, scope);
      const seen = new Set(), bad = [], fields = []; let steps = 0;
      for (; steps < 45; steps++) {
        const a = await page.evaluate(() => { const e = document.activeElement; if (!e || e === document.body) return null; const r = e.getBoundingClientRect(), cs = getComputedStyle(e); const ring = (cs.outlineStyle !== 'none' && parseFloat(cs.outlineWidth) > 0) || cs.boxShadow !== 'none';
          return { key: e.id || e.tagName + '#' + [...document.querySelectorAll('*')].indexOf(e) + ':' + (e.innerText || e.value || '').slice(0, 20), inView: r.top >= -1 && r.left >= -1 && r.bottom <= innerHeight + 1 && r.right <= innerWidth + 1, big: r.height > innerHeight || r.width > innerWidth, field: e.matches('textarea, input:not([type]), input[type="text"], input[type="search"]') && !e.disabled && !e.readOnly, fv: e.matches(':focus-visible'), ring }; });
        if (!a) break; if (seen.has(a.key)) break; seen.add(a.key);
        if (steps > 0 && !(a.inView || a.big)) bad.push({ key: a.key, why: 'вне области просмотра' });
        if (steps > 0 && !(a.fv && a.ring)) bad.push({ key: a.key, why: 'фокус не виден', fv: a.fv, ring: a.ring });
        // текстовое поле в фокусе принимает ввод с клавиатуры: стрелка вправо снимает выделение
        // (Tab выделяет текст однострочного поля; End на macOS прокручивает документ), символ набирается и стирается,
        // значение возвращается к исходному. Латинская «x» — настоящие события клавиши (keydown/keypress/input);
        // символы вне раскладки Playwright вводит через insertText без событий клавиш
        if (a.field) { const val = () => page.evaluate(() => document.activeElement.value); const v0 = await val(); await page.keyboard.press('ArrowRight'); await page.keyboard.type('x'); await W(60); const v1 = await val();
          await page.keyboard.press('Backspace'); await W(60); const v2 = await val(); fields.push({ key: a.key, ok: v1.length === v0.length + 1 && v1.includes('x') && v2 === v0 }); }
        await page.keyboard.press('Tab'); await W(40);
      }
      ok(G, 'обход Tab (' + seen.size + ' элементов): каждый элемент в фокусе виден целиком и с индикатором фокуса', seen.size >= 3 && bad.length === 0, bad.slice(0, 8), 'начальный фокус — focus() на первом элементе ' + (dlg ? 'окна' : 'страницы'));
      if (fields.length) ok(G, 'текстовые поля (' + fields.map((f) => f.key).join(', ') + ') в фокусе принимают ввод с клавиатуры', fields.every((f) => f.ok), fields);
      // основные действия: включённые основные и опасные кнопки окна или страницы достижимы клавишей Tab и доступны мыши
      // (пробное нажатие Playwright: элемент прокручивается в область просмотра, виден, не перекрыт)
      const prim = await page.evaluate((s) => [...document.querySelector(s).querySelectorAll('button.btn-primary:not([disabled]), button.btn-danger:not([disabled])')].filter((b) => b.getClientRects().length && !b.closest('[inert]')).map((b) => b.id || '(без id) ' + b.innerText.slice(0, 30)), scope);
      for (const id of prim) {
        let can = true; if (id.startsWith('(без id)')) can = 'нет id'; else { try { await page.locator('#' + id).click({ trial: true, timeout: 2500 }); } catch (e) { can = String(e).split('\n')[0]; } }
        ok(G, 'основное действие «' + id + '» достижимо клавишей Tab и доступно мыши', seen.has(id) && can === true, { tab: seen.has(id), mouse: can });
      }
      { const cdp = await ctx.newCDPSession(page); const { data } = await cdp.send('Page.captureScreenshot', { format: 'png' }); fs.writeFileSync(path.join(OUT, base + '-' + theme + '-' + ww + 'x' + wh + '.png'), Buffer.from(data, 'base64')); await cdp.detach(); }
      ok(G, 'ошибок страницы нет', page._errs.length === 0, page._errs);
      await page.close();
    }
    await ctx.close();
  }
  note('снимки: ' + OUT);
} catch (e) { crash(e); } finally { await finish(); }
