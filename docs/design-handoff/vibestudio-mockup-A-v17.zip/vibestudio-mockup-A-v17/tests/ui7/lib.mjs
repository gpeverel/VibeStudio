// Общая обвязка UI-проверок версии 16 (Playwright). Написана заново при подготовке версии 16.
// Проверяемые действия — только события Playwright: locator.click() / mouse.* (настоящие события мыши по координатам)
// и keyboard.* (настоящие события клавиатуры). DOM click()/dispatchEvent в проверяемых действиях не используются.
// Подготовка состояния (параметры обёртки, переключатели «Только в макете», начальный фокус) записывается отдельно
// в поле prep каждой проверки.
// Порты не нужны: Chrome запускается Playwright по pipe, файлы комплекта отдаются перехватом запросов к http://mockup.test.
//
// Окружение: PLAYWRIGHT_DIR — каталог пакета playwright (обязательно); CHROME — путь к Chrome;
// KIT_ROOT — корень распакованного комплекта (по умолчанию два уровня выше); RESULTS_DIR — куда писать результат.
import { createRequire } from 'node:module';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(process.env.KIT_ROOT || path.join(here, '..', '..'));
export const BASE = 'http://mockup.test';
const RESULTS_DIR = path.resolve(process.env.RESULTS_DIR || path.join(ROOT, 'tests', 'results-ui7'));
const CHROME = process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const script = path.basename(process.argv[1] || 'ui7');

const R = { script, runId: process.env.RUN_ID || '', started: new Date().toISOString(), status: 'running', tool: {}, checks: [], notes: [] };
let crashed = null;
export function note(s) { R.notes.push(s); console.log('  · ' + s); }
export function ok(group, name, cond, detail, prep) {
  const c = { group, name, ok: !!cond, prep: prep || '', detail: detail === undefined ? '' : detail };
  R.checks.push(c);
  console.log((c.ok ? '  ок   ' : '  НЕТ  ') + group + ' · ' + name + (c.ok ? '' : ' → ' + JSON.stringify(detail).slice(0, 400)));
  return c.ok;
}
export function crash(e) { crashed = String(e && e.stack || e); console.log('АВАРИЯ: ' + crashed); }
process.on('exit', (code) => {
  const fail = R.checks.filter((c) => !c.ok).length;
  R.pass = R.checks.length - fail; R.fail = fail; R.finished = new Date().toISOString();
  R.status = crashed ? 'crashed' : (R.checks.length === 0 ? 'empty' : (fail ? 'failed' : 'passed'));
  if (crashed) R.crash = crashed;
  try { fs.mkdirSync(RESULTS_DIR, { recursive: true }); fs.writeFileSync(path.join(RESULTS_DIR, script + '.json'), JSON.stringify(R, null, 1)); } catch (e) { console.log('не записан результат: ' + e); }
  console.log('ИТОГО ' + script + ': ' + R.pass + ' пройдено, ' + fail + ' не пройдено; статус ' + R.status);
  process.exitCode = R.status === 'passed' ? 0 : (R.status === 'failed' ? 1 : 2);
});

const PW = process.env.PLAYWRIGHT_DIR;
if (!PW) { crash('не задан PLAYWRIGHT_DIR (каталог пакета playwright)'); process.exit(); }
const require = createRequire(import.meta.url);
const { chromium } = require(PW);
R.tool.playwright = JSON.parse(fs.readFileSync(path.join(PW, 'package.json'), 'utf8')).version;

// --- обёртки: берутся атрибуты опубликованной платформы, подставляются тема, размер или режим «по размеру окна»
const reg = new Map(); let seq = 0;
function setAttr(tag, k, v) { const re = new RegExp(' ' + k + '="[^"]*"'); return re.test(tag) ? tag.replace(re, v === null ? '' : ' ' + k + '="' + v + '"') : (v === null ? tag : tag.replace('></dc-import>', ' ' + k + '="' + v + '"></dc-import>')); }
export function wrapper(base, o = {}) {
  const src = fs.readFileSync(path.join(ROOT, 'project', base + '.dc.html'), 'utf8');
  let tag = (src.match(/<dc-import name="App"[^>]*><\/dc-import>/) || [])[0];
  if (!tag) throw new Error('в ' + base + ' нет dc-import App');
  if (o.theme) tag = setAttr(tag, 'theme', o.theme);
  for (const [k, v] of Object.entries(o.attrs || {})) tag = setAttr(tag, k, v);
  let logic = 'renderVals() { return {}; }', props = '{}';
  if (o.fill) { tag = setAttr(setAttr(setAttr(tag, 'w', '{{w}}'), 'h', '{{h}}'), 'hint-size', null);
    logic = "componentDidMount() { this._r = () => this.setState({ t: Date.now() }); window.addEventListener('resize', this._r); }\n  componentWillUnmount() { window.removeEventListener('resize', this._r); }\n  renderVals() { return { w: window.innerWidth, h: window.innerHeight }; }"; }
  else { const w = o.w || 1440, h = o.h || 900; tag = setAttr(setAttr(setAttr(tag, 'w', String(w)), 'h', String(h)), 'hint-size', w + 'px,' + h + 'px'); }
  const id = 'T7-' + (++seq) + '-' + base;
  reg.set('/project/' + id + '.dc.html', '<!doctype html>\n<html lang="ru">\n<head>\n<meta charset="utf-8">\n<title>' + id + '</title>\n<script src="./support.js"></script>\n</head>\n<body>\n<x-dc>\n<helmet>\n<style>body{margin:0}</style>\n</helmet>\n' + tag + '\n</x-dc>\n<script type="text/x-dc" data-dc-script data-props=\'' + props + '\'>\nclass Component extends DCLogic {\n  ' + logic + '\n}\n</script>\n</body>\n</html>\n');
  return BASE + '/project/' + id + '.dc.html';
}
// обёртка листа-документа (Handoff1–4, Trace, Map, Prop2) — как SHEET в tools/mkboards5.py
export function sheet(comp, o = {}) {
  const h = o.h || 9000, theme = o.theme || 'dark', id = 'T7-' + (++seq) + '-' + comp;
  reg.set('/project/' + id + '.dc.html', '<!doctype html>\n<html lang="ru">\n<head>\n<meta charset="utf-8">\n<title>' + id + '</title>\n<script src="./support.js"></script>\n</head>\n<body>\n<x-dc>\n<helmet>\n<style>body{margin:0}</style>\n</helmet>\n<dc-import name="' + comp + '" theme="' + theme + '" h="' + h + '" hint-size="1440px,' + h + 'px"></dc-import>\n</x-dc>\n<script type="text/x-dc" data-dc-script data-props=\'{"$preview":{"width":1440,"height":' + h + '}}\'>\nclass Component extends DCLogic {\n  renderVals() { return {}; }\n}\n</script>\n</body>\n</html>\n');
  return BASE + '/project/' + id + '.dc.html';
}
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.json': 'application/json', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml' };
async function serve(ctx) {
  await ctx.route(BASE + '/**', (r) => {
    const u = new URL(r.request().url()); const p = decodeURIComponent(u.pathname);
    if (reg.has(p)) return r.fulfill({ status: 200, contentType: MIME['.html'], body: reg.get(p) });
    const f = path.join(ROOT, p); if (!f.startsWith(ROOT) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) return r.fulfill({ status: 404, body: 'нет файла' });
    return r.fulfill({ status: 200, contentType: MIME[path.extname(f)] || 'application/octet-stream', body: fs.readFileSync(f) });
  });
}

// --- браузер: обычный контекст (масштаб 100%) или профиль с настоящим масштабом браузера (zoom, %)
let browser = null; const toClose = [];
export async function context(o = {}) {
  if (o.zoom && o.zoom !== 100) {
    const prof = fs.mkdtempSync(path.join(os.tmpdir(), 'vs-ui7-zoom-'));
    fs.mkdirSync(path.join(prof, 'Default'), { recursive: true });
    // Настоящий масштаб страницы Chrome (HostZoomMap, как ⌘+), задаётся уровнем по умолчанию в профиле: уровень = log_1.2(масштаб).
    fs.writeFileSync(path.join(prof, 'Default', 'Preferences'), JSON.stringify({ partition: { default_zoom_level: { x: Math.log(o.zoom / 100) / Math.log(1.2) } } }));
    const ctx = await chromium.launchPersistentContext(prof, { executablePath: CHROME, headless: true, viewport: null, args: ['--window-size=' + (o.width || 1440) + ',' + (o.height || 900)], reducedMotion: 'no-preference', colorScheme: 'no-preference' });
    toClose.push(async () => { await ctx.close(); fs.rmSync(prof, { recursive: true, force: true }); });
    await serve(ctx); if (!R.tool.chrome && ctx.browser()) R.tool.chrome = ctx.browser().version();
    return ctx;
  }
  if (!browser) { browser = await chromium.launch({ executablePath: CHROME, headless: true }); R.tool.chrome = browser.version(); toClose.push(() => browser.close()); }
  const ctx = await browser.newContext({ viewport: { width: o.width || 1440, height: o.height || 900 }, deviceScaleFactor: o.dsf || 1 });
  await serve(ctx); return ctx;
}
export async function finish() { for (const f of toClose.reverse()) { try { await f(); } catch (e) {} } }

export async function open(ctx, url, ready = '#live, #ns-create, #ap-h, #rv-title') {
  const page = ctx.pages().find((p) => p.url() === 'about:blank') || await ctx.newPage();
  const errs = []; page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(url); await page.waitForSelector(ready, { state: 'attached', timeout: 15000 }); await page.waitForTimeout(350);
  page._errs = errs; return page;
}
export const W = (ms) => new Promise((r) => setTimeout(r, ms));
// Области фокуса — как в suite6
export const region = (page) => page.evaluate(() => { const a = document.activeElement; if (!a || a === document.body) return 'body'; return a.closest('#dlg') ? 'dlg' : a.closest('#sb-panel') ? 'sb' : a.closest('#in-panel') ? 'in' : a.closest('main') ? 'main' : 'other'; });
export const active = (page) => page.evaluate(() => document.activeElement ? (document.activeElement.id || document.activeElement.tagName) : null);
export const focusables = (page, root) => page.evaluate((root) => { const r = document.querySelector(root); if (!r) return []; return [...r.querySelectorAll('button:not([disabled]),summary,a[href],input:not([disabled]),textarea,select,[tabindex]')].filter((el) => el.tabIndex >= 0 && el.getClientRects().length > 0 && !el.closest('[inert]')).map((el) => el.id || ''); }, root);
// подготовка: начальный фокус (не проверяемое действие)
export const prepFocus = (page, id) => page.evaluate((id) => { const e = document.getElementById(id); if (!e) return false; e.focus(); return document.activeElement === e; }, id);
export const text = (page, sel) => page.evaluate((s) => { const e = document.querySelector(s); return e ? e.innerText : null; }, sel);
export const has = (page, sel) => page.evaluate((s) => !!document.querySelector(s), sel);
export const disabled = (page, sel) => page.evaluate((s) => { const e = document.querySelector(s); return e ? e.disabled : null; }, sel);
export const chip = (page) => page.evaluate(() => { const e = document.getElementById('status-chip'); return e ? e.innerText.trim() : null; });
// наблюдение за живой областью (только чтение, ставится при подготовке)
export const watchLive = (page) => page.evaluate(() => { window.__live = []; const el = document.getElementById('live'); if (!el) return false; new MutationObserver(() => { const t = el.textContent.trim(); if (t) window.__live.push(t); }).observe(el, { childList: true, characterData: true, subtree: true }); return true; });
export const liveLog = (page) => page.evaluate(() => window.__live || []);
export function setNote(k, v) { R[k] = v; }
// декодер PNG вынесен в png.mjs (без обвязки отчёта: его подключает и rvdiff.mjs)
export { png } from './png.mjs';
