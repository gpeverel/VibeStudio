// B-01: обход боковых панелей клавиатурой. Полная матрица: 4 состояния × 2 темы × 7 ширин (границы режимов 1280/1279 и 800/799),
// панель проектов и инспектор. Открытие и закрытие панелей — настоящими нажатиями мыши; обход — настоящими Tab/Shift+Tab/Escape.
// Подготовка: начальный фокус на первом/последнем элементе панели (focus()), состояние — параметрами обёртки.
import { context, open, wrapper, ok, crash, finish, region, active, focusables, prepFocus, W } from './lib.mjs';
const STATES = [['D-Solo-Running-Dark', 'D-Solo-Running'], ['R-Review-Light', 'R-Review'], ['N1-New-Dark', 'N1-New'], ['X-Restart-Banner-Light', 'X-Restart-Banner']];
const WIDTHS = [[1440, 900], [1280, 800], [1279, 800], [1000, 720], [800, 600], [799, 600], [640, 480]];
try {
  for (const [w, h] of WIDTHS) {
    const ctx = await context({ width: w, height: h });
    for (const [base, label] of STATES) for (const theme of ['dark', 'light']) {
      const G = 'B-01 ' + label + '/' + theme + ' · ' + w;
      const page = await open(ctx, wrapper(base, { theme, w, h }));
      const mode = w >= 1280 ? 'full' : w >= 800 ? 'mid' : 'compact';
      // --- панель проектов
      if (mode === 'full') {
        const sb = await focusables(page, '#sb-panel');
        ok(G, 'панель проектов закреплена (без role=dialog), в ней есть элементы фокуса', sb.length >= 3 && !(await page.evaluate(() => document.getElementById('sb-panel').getAttribute('role'))), sb);
        await prepFocus(page, sb[sb.length - 1]); await page.keyboard.press('Tab'); const r1 = await region(page); await page.keyboard.press('Tab'); const r2 = await region(page);
        ok(G, 'Tab с последнего элемента панели выходит из неё и ведёт в основную область', r1 !== 'sb' && r1 !== 'body' && (r1 === 'main' || r2 === 'main'), { r1, r2 }, 'фокус на последнем элементе панели');
        await prepFocus(page, sb[0]); await page.keyboard.press('Shift+Tab');
        ok(G, 'Shift+Tab с первого элемента панели выходит из неё', (await region(page)) !== 'sb', await region(page), 'фокус на первом элементе панели');
      } else {
        await page.locator('#btn-sb').click(); await W(250);
        const ov = await focusables(page, '#sb-panel');
        ok(G, 'панель проектов открывается нажатием мыши как модальная (role=dialog, aria-modal=true)', ov.length >= 3 && await page.evaluate(() => { const p = document.getElementById('sb-panel'); return p.getAttribute('role') === 'dialog' && p.getAttribute('aria-modal') === 'true'; }), ov);
        ok(G, 'при открытой накладке основная область недоступна (inert)', await page.evaluate(() => { const m = document.querySelector('main'); return !!m && !!m.closest('[inert]'); }));
        await prepFocus(page, ov[ov.length - 1]); await page.keyboard.press('Tab');
        ok(G, 'накладка удерживает фокус: Tab с последнего — на первый', (await region(page)) === 'sb' && (await active(page)) === ov[0], await active(page), 'фокус на последнем элементе накладки');
        await prepFocus(page, ov[0]); await page.keyboard.press('Shift+Tab');
        ok(G, 'Shift+Tab с первого — на последний', (await region(page)) === 'sb' && (await active(page)) === ov[ov.length - 1], await active(page), 'фокус на первом элементе накладки');
        await page.keyboard.press('Escape'); await W(250);
        ok(G, 'Escape закрывает накладку и возвращает фокус на кнопку панели', !(await page.evaluate(() => !!document.getElementById('sb-panel') && document.getElementById('sb-panel').getAttribute('role') === 'dialog')) && (await active(page)) === 'btn-sb', await active(page));
        await page.locator('#btn-sb').click(); await W(250); await page.locator('#sb-close').click(); await W(250);
        ok(G, 'закрытие кнопкой «Закрыть» мышью тоже возвращает фокус на кнопку панели', (await active(page)) === 'btn-sb', await active(page));
      }
      // --- инспектор (есть только у открытой сессии)
      if (await page.evaluate(() => !!document.getElementById('btn-in'))) {
        if (mode !== 'compact') {
          let inl = await focusables(page, '#in-panel');
          if (!inl.length) { await page.locator('#btn-in').click(); await W(250); inl = await focusables(page, '#in-panel'); }
          ok(G, 'инспектор закреплён (без role=dialog)', inl.length >= 1 && await page.evaluate(() => document.getElementById('in-panel').getAttribute('role') !== 'dialog'), inl);
          await prepFocus(page, inl[inl.length - 1]); await page.keyboard.press('Tab');
          ok(G, 'Tab с последнего элемента инспектора выходит из него', (await region(page)) !== 'in', await region(page), 'фокус на последнем элементе инспектора');
          await prepFocus(page, inl[0]); await page.keyboard.press('Shift+Tab');
          ok(G, 'Shift+Tab с первого элемента инспектора выходит из него', (await region(page)) !== 'in', await region(page), 'фокус на первом элементе инспектора');
        } else {
          await page.locator('#btn-in').click(); await W(250);
          const il = await focusables(page, '#in-panel');
          ok(G, 'инспектор открывается нажатием мыши как модальный', il.length >= 1 && await page.evaluate(() => { const p = document.getElementById('in-panel'); return p.getAttribute('role') === 'dialog' && p.getAttribute('aria-modal') === 'true'; }), il);
          await prepFocus(page, il[il.length - 1]); await page.keyboard.press('Tab');
          ok(G, 'модальный инспектор удерживает фокус: Tab с последнего — на первый', (await region(page)) === 'in' && (await active(page)) === il[0], await active(page), 'фокус на последнем элементе инспектора');
          await prepFocus(page, il[0]); await page.keyboard.press('Shift+Tab');
          ok(G, 'Shift+Tab с первого — на последний', (await region(page)) === 'in' && (await active(page)) === il[il.length - 1], await active(page), 'фокус на первом элементе инспектора');
          await page.keyboard.press('Escape'); await W(250);
          ok(G, 'Escape закрывает инспектор и возвращает фокус на его кнопку', (await active(page)) === 'btn-in' && await page.evaluate(() => { const p = document.getElementById('in-panel'); return !p || p.getAttribute('role') !== 'dialog' || !!p.closest('[inert]') || p.getClientRects().length === 0; }), await active(page));
        }
      }
      ok(G, 'ошибок страницы нет', page._errs.length === 0, page._errs);
      await page.close();
    }
    await ctx.close();
  }
} catch (e) { crash(e); } finally { await finish(); }
