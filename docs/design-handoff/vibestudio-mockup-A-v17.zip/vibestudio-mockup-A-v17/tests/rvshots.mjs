// Снимки для просмотра глазами: node tests/rvshots.mjs → tests/shots/rv/<имя>.png (обе темы каждой платформы)
import fs from 'node:fs';
import { launch, openPage } from './cdp.mjs';
const list = JSON.parse(fs.readFileSync(new URL('../review/rv.json', import.meta.url)));
const want = process.argv.slice(2);
const dir = new URL('./shots/rv/', import.meta.url).pathname; fs.mkdirSync(dir, { recursive: true });
const c = await launch();
try {
  for (const b of list) {
    if (want.length && !want.some(w => b.name.includes(w))) continue;
    const pg = await openPage(c.port, (process.env.MOCKUP_BASE || 'http://127.0.0.1:8765') + '/project/' + b.name + '.dc.html', b.w, b.h);
    await pg.wait(1700);
    await pg.shot(dir + b.name + '.png'); await pg.close();
  }
} finally { c.close(); }
console.log('готово');
