// Измерение высот листов-документов (для холста): node tests/heights.mjs → tests/results/heights.json
import fs from 'node:fs';
import { launch, openPage } from './cdp.mjs';
const c = await launch(); const out = {};
try {
  for (const [n, sel, key] of [['T-H1', '#ho1', 'Handoff1'], ['T-H2', '#ho2', 'Handoff2'], ['T-H3', '#ho3', 'Handoff3'], ['T-H4', '#ho4', 'Handoff4'], ['T-Trace', '#trace', 'Trace'], ['T-Map', '#mapsheet', 'Map'], ['T-Prop2', '.sheet', 'Prop2']]) {
    const pg = await openPage(c.port, (process.env.MOCKUP_BASE || 'http://127.0.0.1:8765') + '/project/' + n + '.dc.html', 1440, 900);
    await pg.wait(n === 'T-H3' ? 5000 : 1800);
    const h = await pg.ev(`(()=>{const e=document.querySelector('${sel}');return e? Math.ceil(e.lastElementChild.getBoundingClientRect().bottom - e.getBoundingClientRect().top + 32) : 0})()`);
    out[key] = Math.ceil(h / 20) * 20;
    console.log(key, h, pg.logs.filter(l => /^(error|EXC)/.test(l)).slice(0, 2).join(' | '));
    await pg.close();
  }
} finally { c.close(); }
const dir = new URL('./results/', import.meta.url).pathname; fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(dir + 'heights.json', JSON.stringify(out));
console.log(JSON.stringify(out));
