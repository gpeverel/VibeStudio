// Вспомогательные функции сценариев. Версия 15: прогон не может завершиться успехом, если было исключение,
// не выполнено ни одной проверки или браузер не запустился (замечание C-02).
import { launch, openPage } from './cdp.mjs';
import fs from 'node:fs';
import path from 'node:path';
export const BASE = (process.env.MOCKUP_BASE || 'http://127.0.0.1:8765') + '/project/';
let C = null; const res = { pass: 0, fail: 0, list: [], crash: null, pageErrors: [] }; let curSec = ''; const bySec = {};
const pages = new Set();
// Запуск браузера. Ошибка запуска не глотается: исключение уходит наверх, а скрипт записывает результат «авария».
export async function init() {
  try { C = await launch(); } catch (e) { crash(e); throw e; }
}
// Записывает исключение, пойманное в сценарии. Вызывать в catch перед done().
export function crash(e) {
  if (!res.crash) res.crash = { message: String(e && e.message || e), stack: String(e && e.stack || '').split('\n').slice(0, 6).join('\n') };
  console.log('\nАВАРИЙНОЕ ЗАВЕРШЕНИЕ: ' + res.crash.message);
}
// Итог прогона. Файл результата пишется в обработчике завершения процесса, когда известен ФАКТИЧЕСКИЙ код выхода:
// исключение, которое пролетает после done() (например, при try { … } finally { await done() } без catch), не может дать успех.
let finished = false, intended = 'aborted';
const CODES = { passed: 0, failed: 1, crashed: 2, empty: 3, aborted: 5 };
function summary() {
  for (const pg of pages) { try { res.pageErrors.push(...pg.logs.filter(l => l.startsWith('EXC:')).map(l => pg.url + ' ' + l)); } catch (e) {} }
  pages.clear();
  const total = res.pass + res.fail;
  return res.crash ? 'crashed' : res.fail || res.pageErrors.length ? 'failed' : total === 0 ? 'empty' : 'passed';
}
export async function done() {
  if (finished) return;
  finished = true;
  if (C) C.close();
  intended = summary();
  console.log(`\nИТОГО: ${res.pass} ок, ${res.fail} ошибок, исключений страниц ${res.pageErrors.length}; статус: ${intended}`);
  if (res.fail) console.log(res.list.join('\n'));
  if (res.pageErrors.length) console.log(res.pageErrors.slice(0, 5).join('\n'));
  // выходим сами, но не раньше, чем исключение (если оно ещё летит из finally) успеет завершить процесс с ненулевым кодом
  setTimeout(() => process.exit(CODES[intended]), 50);
}
process.on('exit', (code) => {
  if (C) { try { C.close(); } catch (e) {} }
  let status = res.crash ? 'crashed' : finished ? intended : 'aborted';
  if (!finished) summary();
  if (finished && code !== 0 && status === 'passed') status = 'crashed';
  const exitCode = status === 'passed' ? 0 : code !== 0 ? code : CODES[status];
  try {
    const dir = process.env.RESULTS_DIR || path.join(path.dirname(path.resolve(process.argv[1])), 'results');
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, path.basename(process.argv[1]) + '.json'), JSON.stringify({ script: path.basename(process.argv[1]), status, exitCode, runId: process.env.RUN_ID || '', pass: res.pass, fail: res.fail, failed: res.list, crash: res.crash, pageErrors: res.pageErrors.slice(0, 20), sections: bySec, at: new Date().toISOString() }, null, 1));
  } catch (e) { console.log('Не удалось записать результат: ' + e.message); process.exitCode = 4; return; }
  process.exitCode = exitCode;
});
export async function page(name, w = 1440, h = 900) {
  const url = BASE + name + '.dc.html';
  const pg = await openPage(C.port, url, w, h); await pg.wait(1500);
  pg.url = name;
  const nav = await pg.ev(`(()=>{const n=performance.getEntriesByType('navigation')[0]; return n? n.responseStatus : 0})()`);
  if (nav !== 200) throw new Error('Страница ' + url + ' не загрузилась: HTTP ' + nav);
  pages.add(pg);
  pg.text = (sel) => pg.ev(`(document.querySelector(${JSON.stringify(sel)})||{}).innerText||''`);
  pg.has = (sel) => pg.ev(`!!document.querySelector(${JSON.stringify(sel)})`);
  pg.active = () => pg.ev(`(document.activeElement||{}).id||document.activeElement.tagName`);
  pg.val = (sel) => pg.ev(`(document.querySelector(${JSON.stringify(sel)})||{}).value`);
  pg.dis = (sel) => pg.ev(`(()=>{const e=document.querySelector(${JSON.stringify(sel)});return e? !!e.disabled : null})()`);
  pg.setVal = (sel, v) => pg.ev(`(()=>{const e=document.querySelector(${JSON.stringify(sel)});const set=Object.getOwnPropertyDescriptor(e.constructor.prototype,'value').set;set.call(e,${JSON.stringify(v)});e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));})()`);
  pg.tab = async (shift) => { await pg.key('Tab', { vk: 9, mod: shift ? 8 : 0 }); await pg.wait(60); };
  pg.enter = async () => { await pg.key('Enter', { vk: 13, text: '\r' }); await pg.wait(80); };
  pg.esc = async () => { await pg.key('Escape', { vk: 27 }); await pg.wait(80); };
  pg.chk = (sel) => pg.click(sel);
  return pg;
}
export function ok(name, cond, extra) { const sb = bySec[curSec] || (bySec[curSec] = { pass: 0, fail: 0 }); if (cond) sb.pass++; else sb.fail++; if (cond) { res.pass++; console.log('  ок   ' + name); } else { res.fail++; res.list.push('  НЕТ  ' + name + (extra !== undefined ? ' → ' + JSON.stringify(extra) : '')); console.log('  НЕТ  ' + name + (extra !== undefined ? ' → ' + JSON.stringify(extra) : '')); } }
export async function section(t) { curSec = t; console.log('\n' + t); }
