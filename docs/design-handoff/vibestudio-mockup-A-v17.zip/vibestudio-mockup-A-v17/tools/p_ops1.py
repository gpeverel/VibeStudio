import sys
sys.path.insert(0, '..')
from pt import Patch
o = Patch('project/Ops.dc.html')

# --- свойства
o.rep('''"mvar":{"editor":"text","default":"none"},"$preview"''', '''"mvar":{"editor":"text","default":"none"},"wr":{"editor":"text","default":"ok"},"dbw":{"editor":"text","default":"err"},"dbv":{"editor":"text","default":"stopped"},"solo":{"editor":"bool","default":false},"act":{"editor":"bool","default":true},"ap":{"editor":"text","default":""},"ctxp":{"editor":"text","default":""},"orph":{"editor":"text","default":""},"rls":{"editor":"text","default":""},"$preview"''')

# --- сброс состояния при смене вида
o.rep("msim: undefined, mres: undefined, mcount: undefined, dshow: undefined, opened: undefined, copied: undefined }",
      "msim: undefined, mres: undefined, mcount: undefined, dshow: undefined, opened: undefined, copied: undefined, wp: undefined, wfail: undefined, wtry: undefined, dbsim: undefined, dbph: undefined, dbtry: undefined, osim: undefined, ores: undefined, ocount: undefined, rlm: undefined, rf: undefined, rack: undefined, rchg: undefined, rtgt: undefined }")

# --- методы записи результата
o.rep('''  go(step, ms, then) {''', '''  beginRec(src) {
    const p = this.props, fail = (this.state.dbsim ?? (p.wr === 'fail' ? 'down' : 'up')) === 'down';
    this.setState({ wp: 1, wfail: false, wtry: 0 });
    this.later(() => this.setState({ wp: 2 }), 700);
    this.later(() => { this.setState({ wp: 3, wfail: fail }); if (p.onDone) p.onDone({ kind: src, result: 'completed', saved: !fail }); }, 1700);
  }
  retryRec(src) {
    const p = this.props, up = (this.state.dbsim ?? 'down') === 'up', n = (this.state.wtry || 0) + 1;
    if (up) { this.setState({ wp: 4, wtry: n }); this.later(() => { this.setState({ wp: 3, wfail: false }); if (p.onDone) p.onDone({ kind: src, result: 'completed', saved: true, recovered: true }); }, 1100); }
    else { this.setState({ wp: 2, wtry: n }); this.later(() => this.setState({ wp: 3, wfail: true }), 800); }
  }
  go(step, ms, then) {''')

# --- REC: общий блок «сверка → подтверждено → сохраняется → сохранено»
o.rep('''    // ---------- Коммит
    if (kind === 'commit') {''', '''    const WPS = { recsaving: 2, recsaved: 3, recfail: 3, donesaving: 2, donesaved: 3, donefail: 3 };
    const REC = (src) => {
      const stt = String(p.start || '');
      const wp = s.wp ?? (WPS[stt] || 1), wfail = s.wfail ?? /fail$/.test(stt), tries = s.wtry || 0;
      const fin = wp === 3, retry = wp === 4, saving = wp === 2 || retry, sha = 'c91d2e8';
      if (fin && wfail) {
        blocks.push(AL('ok', 'Git-результат подтверждён: main на ' + sha, 'Файлы, индекс и HEAD согласованы с деревом кандидата, незавершённых операций Git нет.'));
        blocks.push(AL('err', 'Результат применения не сохранён', 'База не приняла запись. Git-результат и сохранение состояния — разные факты: изменение в `main` уже есть, а сессия в приложении ещё не помечена применённой. Новые изменяющие действия заблокированы.', 'alert'));
        if (tries > 0) blocks.push({ isStatus: true, ic: ico('err'), text: 'Попытка №' + (tries + 1) + ': база по-прежнему не принимает запись. Git при этом не изменялся.' });
      } else if (fin) {
        blocks.push(AL('ok', 'Результат сохранён: применение ' + sha + ' записано в историю', 'Сверка однозначно подтвердила завершение, поэтому запись выполнена автоматически. Это запись установленного факта, а не новое применение; отдельное разрешение не требовалось.'));
      } else {
        blocks.push(AL('ok', 'Применение завершилось: main на ' + sha, retry ? 'Запись восстановлена. Перед записью сверка повторяется: Git только читается.' : 'Результат подтверждён сверкой и сейчас сохраняется автоматически. Отдельное подтверждение не нужно.'));
      }
      const st4 = (a, b) => retry ? a : b;
      blocks.push(LS('Ход восстановления', [
        [retry ? 'run' : 'ok', 'Сверка', retry ? 'Повторная сверка перед записью: Git только читается' : 'HEAD, индекс и файлы сопоставлены с намерением операции', retry ? 'Выполняется' : 'Готово'],
        ['ok', 'Завершение подтверждено', 'main на ' + sha + ': дерево совпадает с кандидатом, незавершённых операций Git нет', 'Готово'],
        [saving ? 'run' : fin ? (wfail ? 'err' : 'ok') : 'wait', 'Результат сохраняется', retry ? 'Запись восстановлена, записываем результат' : saving ? 'Записываем результат применения в базу' : fin ? (wfail ? 'База не приняла запись' : 'Запись принята базой') : 'Начнётся сразу после подтверждения', saving ? 'Выполняется' : fin ? (wfail ? 'Ошибка' : 'Готово') : 'Ожидает'],
        [fin && !wfail ? 'ok' : fin ? 'err' : 'wait', 'Результат сохранён', fin && !wfail ? 'Применение ' + sha + ' записано в историю сессии' : fin ? 'Результат применения не записан' : 'Появится после записи', fin && !wfail ? 'Готово' : fin ? 'Не выполнено' : 'Ожидает']]));
      if (fin && wfail) {
        blocks.push(KV([['Git', 'подтверждено: main = ' + sha + ', дерево совпадает с кандидатом `' + rev + '`'], ['Сохранение состояния', 'не удалось (попыток: ' + (tries + 1) + ')'], ['Сессия', 'не отмечена применённой, пока результат не записан']]));
        blocks.push({ isDetails: true, id: 'dlg-tech-db', open: false, title: 'Технические подробности записи', rows: [{ k: 'Ошибка', v: 'SQLITE_FULL: database or disk is full' }, { k: 'База', v: '~/Library/Application Support/VibeStudio/state.db' }, { k: 'Операция', v: 'op-7f3a91, запись исхода «применено»' }, { k: 'Первая ошибка', v: '14:47:02' }] });
        blocks.push({ isSelect: true, id: 'dlg-sim-db', label: 'Только в макете: состояние записи в базу перед повтором', value: s.dbsim ?? 'down', opts: [{ v: 'down', t: 'Запись по-прежнему недоступна' }, { v: 'up', t: 'Запись восстановлена' }], change: (e) => this.setState({ dbsim: e.currentTarget.value }) });
        blocks.push(P('Повторное применение не запускается. Когда запись восстановится, приложение сначала повторит сверку и только потом допишет результат.', 'muted sm'));
      } else if (fin) blocks.push(P('Просмотр результата и возврат к сессии доступны. Повторное применение не запускалось.', 'muted sm'));
      else blocks.push(P('Окно можно закрыть: запись продолжится.', 'muted sm'));
      if (fin && wfail) {
        B('dlg-close', 'Вернуться к сессии', '', false, closeIt);
        B('dlg-dbinfo', 'Состояние записи…', '', false, () => { if (p.onSwitch) p.onSwitch('dberr', ''); });
        B('dlg-retry-rec', 'Повторить сохранение', 'btn-primary', false, () => this.retryRec(src));
        foot = 'Git при сверке и записи не изменялся.';
      } else if (fin) {
        B('dlg-close', 'Вернуться к сессии', '', false, closeIt);
        B('dlg-view', 'Посмотреть результат', 'btn-primary', false, () => { done({ kind: src, view: 'result' }); closeIt(); });
        foot = 'Основная копия сверкой не изменялась.';
      } else {
        B('dlg-close', 'Закрыть', '', false, closeIt);
        B('dlg-view', 'Посмотреть результат', 'btn-primary', true, () => {});
        foot = 'Идёт запись результата. «Посмотреть результат» станет доступно после сохранения.';
      }
    };

    // ---------- Коммит
    if (kind === 'commit') {''')

# --- reconcile apply
o.rep("const res = s.rres || '';\n        const V = p.rvariant || 'notstarted';", "const res = s.rres ?? (String(p.start || '').startsWith('rec') ? 'completed' : '');\n        const V = p.rvariant || 'notstarted';")
o.rep("B('dlg-run', 'Выполнить сверку', 'btn-primary', false, () => { this.setState({ rres: V }); this.go('working', 1000, 'form'); if (V === 'ambiguous') this.later(() => done({ kind: 'reconcile', flag: 'ambiguous' }), 1000); });",
      "B('dlg-run', 'Выполнить сверку', 'btn-primary', false, () => { this.setState({ rres: V, wp: undefined, wfail: undefined }); this.go('working', 1000, 'form'); if (V === 'ambiguous') this.later(() => done({ kind: 'reconcile', flag: 'ambiguous' }), 1000); if (V === 'completed') this.later(() => this.beginRec('reconcile'), 1000); });")
o.rep('''              blocks.push(AL('ok', 'Применение завершилось: main на c91d2e8', 'Результат согласован, не хватало только записи в БД.'));
              blocks.push(LS('Подтверждено', [['ok', 'HEAD main = c91d2e8', 'коммит с деревом кандидата `' + rev + '`'], ['ok', 'Индекс и отслеживаемые файлы согласованы с деревом'], ['ok', 'Неотслеживаемых изменений нет']].concat(base)));
              blocks.push(P('Однозначно завершённое применение дописывается в историю. Это запись факта, а не новое применение.', 'muted sm'));
              B('dlg-close', 'Закрыть', '', false, closeIt);
              B('dlg-rec', 'Записать результат', 'btn-primary', false, () => { done({ kind: 'reconcile', result: 'completed' }); closeIt(); });''',
'''              REC('reconcile');''')
o.rep("            foot = 'Сверка не изменила основную копию.';\n          }", "            if (res !== 'completed') foot = 'Сверка не изменила основную копию.';\n          }")

# --- manual
o.rep("const mres = s.mres ?? (start === 'done' ? 'done' :", "const mres = s.mres ?? (start.startsWith('done') ? 'done' :")
o.rep("this.later(() => this.setState({ mres: sim, mcount: (this.state.mcount || 1) + 1 }), 900); });", "this.later(() => this.setState({ mres: sim, mcount: (this.state.mcount || 1) + 1, wp: undefined, wfail: undefined }), 900); if (sim === 'done') this.later(() => this.beginRec('manual'), 900); });")
o.rep('''        blocks.push(AL('ok', 'Применение завершилось: main на c91d2e8', 'Файлы совпадают с деревом кандидата, индекс согласован, незавершённых операций Git нет. Это подтверждено по состоянию, а не только по HEAD.'));
        blocks.push(LS('Что изменилось с прошлой сверки', [['ok', 'Файлы совпадают с кандидатом', '`src/import/queue.ts`, `src/import/worker.ts`'], ['ok', 'Индекс согласован с деревом', 'лишнего подготовленного файла нет'], ['ok', 'Файл-замок Git (index.lock) исчез', 'незавершённых операций Git нет']]));
        blocks.push(P('Однозначно завершённое применение дописывается в историю. Это запись факта, а не новое применение.', 'muted sm'));
        B('dlg-close', 'Закрыть', '', false, closeIt);
        B('dlg-rec', 'Записать результат', 'btn-primary', false, () => { done({ kind: 'manual', result: 'completed' }); closeIt(); });
        foot = 'Основная копия сверкой не изменялась.';''',
'''        blocks.push(LS('Что изменилось с прошлой сверки', [['ok', 'Файлы совпадают с кандидатом', '`src/import/queue.ts`, `src/import/worker.ts`'], ['ok', 'Индекс согласован с деревом', 'лишнего подготовленного файла нет'], ['ok', 'Файл-замок Git (index.lock) исчез', 'незавершённых операций Git нет']]));
        REC('manual');''')
o.save()
