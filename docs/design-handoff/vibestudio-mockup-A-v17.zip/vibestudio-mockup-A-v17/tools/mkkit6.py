# -*- coding: utf-8 -*-
# Собирает каталог комплекта версии 15 и MANIFEST.json (замечание C-01).
#   python3 tools/mkkit6.py <каталог_назначения> --results <каталог_результатов> --evidence <каталог_доказательств> --shots <каталог_снимков>
# MANIFEST.json перечисляет ВСЕ файлы комплекта, включая PNG, с размером и SHA-256. Единственное исключение — сам MANIFEST.json (самоссылка).
import os, re, shutil, json, sys, hashlib

def arg(name, default=None):
    return sys.argv[sys.argv.index('--' + name) + 1] if ('--' + name) in sys.argv else default
dest = [a for a in sys.argv[1:] if not a.startswith('--')][0]
RES, EVI, SHOTS = arg('results', 'tests/results'), arg('evidence', 'tests/evidence'), arg('shots', 'tests/shots/rv')
if os.path.exists(dest): shutil.rmtree(dest)
def mk(*d): os.makedirs(os.path.join(dest, *d), exist_ok=True)
def cp(src, dst):
    mk(os.path.dirname(dst)); shutil.copy(src, os.path.join(dest, dst))

# project: страницы приложения и документов, холст, рантайм (обёртки T-* и RV-* создаются сценариями и в комплект не входят)
for f in sorted(os.listdir('project')):
    if re.match(r'^(T-|RV-)', f): continue
    if f.endswith('.dc.html') or f in ('canvas.json', 'support.js'): cp('project/' + f, 'project/' + f)
# tools
for f in sorted(os.listdir('tools')):
    p = os.path.join('tools', f)
    if os.path.isfile(p) and not f.endswith('.pyc'): cp(p, 'tools/' + f)
# tests: сценарии, обвязка, самопроверка
for f in ('cdp.mjs', 'tlib.mjs', 'suite5.mjs', 'suite6.mjs', 'selftest.mjs', 'scan5.mjs', 'shots.mjs', 'rvshots.mjs', 'rvdiff.mjs', 'tokens5.mjs', 'heights.mjs', 'montage.mjs', 'verify-run.mjs', 'run-all.sh', 'steps.txt', 'expected.json', 'README.md', 'tokens5.json', 'visual-review.json', 'play-check.json'):
    if os.path.exists('tests/' + f): cp('tests/' + f, 'tests/' + f)
for f in sorted(os.listdir('tests/selftest')): cp('tests/selftest/' + f, 'tests/selftest/' + f)
for f in ('t7.mjs', 't8.mjs', 't9.mjs', 't10.mjs', 't11.mjs', 't12.mjs', 'tlib.mjs', 'cdp.mjs', 'CHANGES.md'): cp('tests/legacy/' + f, 'tests/legacy/' + f)
# результаты прогона на распакованной копии (получены ПОСЛЕ сборки: добавляются в комплект как данные) и доказательства «до»
for root, _, files in os.walk(RES):
    for f in files:
        rel = os.path.relpath(os.path.join(root, f), RES)
        cp(os.path.join(root, f), 'tests/results/' + rel)
if os.path.isdir(EVI):
    for root, _, files in os.walk(EVI):
        for f in files:
            rel = os.path.relpath(os.path.join(root, f), EVI)
            cp(os.path.join(root, f), 'tests/evidence/' + rel)
if os.path.exists('review/rv.json'): cp('review/rv.json', 'review/rv.json')
# visual: ключевые состояния версии 15, обе темы, 1:1
VIS = json.load(open('tools/visual_list.json', encoding='utf-8'))
idx = []
for name, title in VIS:
    have = True
    for t in ('dark', 'light'):
        src = os.path.join(SHOTS, 'RV-%s-%s.png' % (name, t))
        if not os.path.exists(src): have = False; print('нет снимка', src)
    if not have: continue
    for t in ('dark', 'light'): cp(os.path.join(SHOTS, 'RV-%s-%s.png' % (name, t)), 'visual/%s-%s.png' % (name, t))
    idx.append({'name': name, 'title': title})
mk('visual'); json.dump(idx, open(os.path.join(dest, 'visual/index.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# --- состав и числа для README
def allfiles():
    out = []
    for root, _, files in os.walk(dest):
        for f in files: out.append(os.path.relpath(os.path.join(root, f), dest).replace(os.sep, '/'))
    return sorted(out)
pre = [p for p in allfiles()]
n_png_pre = sum(1 for p in pre if p.endswith('.png'))
def count(prefix): return sum(1 for p in pre if p.startswith(prefix))
n_total = len(pre) + 2   # + README.md и PROVENANCE.md, создаваемые ниже (MANIFEST.json не считается)
n_png = n_png_pre
README = """# VibeStudio · макет A «Три панели» · версия 15

Редактируемый комплект финальной версии дизайн-макета: страницы, раскладка холста, платформенный рантайм, скрипты сборки и проверок, результаты прогона, доказательства «до» на версии 14 и снимки ключевых состояний. Репозиторий VibeStudio, DESIGN.md и tokens.css этот комплект не затрагивает; макет — не реализация приложения (SPEC §0: UI сессий в коде ещё нет).

Версия 15 выпущена по замечаниям независимого ревью версии 14. Версия 14 сохранена неизменным снимком (`bundles/v14-final.json` на странице комплекта).

**Нумерация.** «Версия 15» — номер ревизии макета и этого комплекта. На платформе она опубликована как Version 17 (`1792286621-25ae`); Version 15 и Version 16 — промежуточные публикации того же проекта. Сверка опубликованных файлов с комплектом, на которую ссылается этот README, выполнена именно для Version 17.

## Состав

| Каталог | Файлов | Содержимое |
|---|---|---|
| `project/` | %(project)d | Страницы `.dc.html`: приложение (`App`, `Ops`, `NewSession`, `AddProject`, `Review`), документы (`Map`, `Trace`, `Prop2`, `Proposals`, `Handoff1–3`), платформы-обёртки, `canvas.json` (раскладка холста), `support.js` (платформенный рантайм) |
| `tools/` | %(tools)d | Скрипты сборки, правок и проверки комплекта; происхождение — в `tools/README.md` |
| `tests/` | %(tests)d | Сценарии, самопроверка обвязки, автоскан, результаты прогона в `tests/results/`, доказательства «до» в `tests/evidence/`; описание — `tests/README.md` |
| `visual/` | %(visual)d | Снимки ключевых состояний при 1:1 в обеих темах (PNG) и `index.json` |
| `review/` | %(review)d | Список платформ просмотра |
| корень | 2 | `README.md`, `PROVENANCE.md` |

Всего файлов в комплекте, не считая `MANIFEST.json`: **%(total)d**, в том числе PNG: **%(png)d**.

## Манифест

`MANIFEST.json` — список `{path, size, sha256}` для каждого файла комплекта, включая PNG и этот README. **Исключён только сам `MANIFEST.json`** (он не может содержать собственную сумму). Других исключений нет: содержимое ZIP, этот README и манифест сверяются командой

```sh
python3 -I tools/verify_kit.py .      # из каталога распакованного комплекта; код возврата 0 — всё совпало
```

Скрипт проверяет, что каждый файл на диске есть в манифесте и наоборот, размеры и суммы совпадают, число файлов и PNG равно числам выше.

## Как открыть и запустить проверки

Распакуйте комплект в отдельный каталог (не в тот, где лежит исходный, чтобы не затереть результаты). Нужны Node 22+, Python 3 и Google Chrome.

```sh
sh tests/run-all.sh        # сам выбирает свободные порты, поднимает сервер, прогоняет все шаги
```

Код возврата 0 — только при полном успешном прогоне: любой неуспешный шаг, исключение, ошибка запуска, пустой или неполный прогон дают ненулевой код. Прежние результаты переносятся в `tests/results.prev`. Порты можно задать переменными `MOCKUP_PORT` и `CDP_PORT` (или адрес готового сервера — `MOCKUP_BASE`). Страницы можно открыть и вручную: `sh tools/serve.sh`, затем `http://127.0.0.1:8765/project/Main.dc.html`.

## Что здесь не так, как кажется

- Исходная сборка версий 10–12 утрачена; версия 15 получена правкой опубликованных файлов версии 14. Источник правды — `project/`. Скрипты `tools/p_v15_*.py` описывают правки версии 15 и проверены на воспроизведение (`tools/README.md`).
- Скрипты `tests/legacy/` извлечены из журнала рабочей сессии и изменены; это не восстановленный прежний набор тестов.
- `support.js` — копия платформенного `artifact-type/dc-runtime.js`; `canvas.json` платформа может переписывать. Совпадение с опубликованной версией проверено на дату публикации и в этот README не обещается навсегда.
- Автоматические проверки не заменяют просмотр глазами; масштаб 200%% и VoiceOver, системные функции macOS не проверены.
"""
PROV = """# Происхождение файлов, версия 15

## project/
- Страницы приложения и документов: опубликованная версия 14 (`1792072575-8814`) плюс правки версии 15. Версия 14 — правка опубликованной версии 12 (`1791973368-bfe9`). Исходная сборка версий 10–12 (каталог `src/`, `build.py` и др.) находилась во временной папке сессии, была очищена и **не восстановлена**.
- Платформенные номера: версия 14 = Version 14 (`1792072575-8814`); версия 15 опубликована как Version 15 (`1792254701-820a`, промежуточная), Version 16 (`1792285287-9078`, промежуточная) и окончательная Version 17 (`1792286621-25ae`). Между 16 и 17 изменена только одна строка листа `Handoff2` (код вместо буквальных обратных кавычек).
- Платформы-обёртки этапов 5 и 15 создаёт `tools/mkboards5.py`; обёртки `T-*` (тестовые) и `RV-*` (просмотр) в комплект не входят и создаются по необходимости.
- `support.js` — копия `artifact-type/dc-runtime.js` из опубликованной версии (платформенный рантайм Design-артефакта). Побайтное совпадение с опубликованной версией проверено на дату публикации (`verify/v15-published-compare.json` на странице комплекта, вне архива); платформа может обновлять рантайм независимо от этого комплекта.
- `canvas.json` описывает раскладку холста; платформа может переписывать его при правках в редакторе. Сравнение с опубликованной версией — там же.
- В документах номера строк `docs/SPEC.md` пересчитаны по таблице `tools/spec-linemap-68472d5-07776e2.json`: SPEC изменился 15.10.2026 (коммит 07776e2) после версии 14.

## tools/ и tests/
Таблица происхождения каждого файла — в `tools/README.md` и `tests/README.md`. Коротко:
- извлечены из журнала сессии без изменений: `tools/gen_handoff_v12.py`, `tools/pt.py`;
- извлечены из журнала и изменены: `tests/legacy/t7–t12.mjs` (список изменений — `tests/legacy/CHANGES.md`); общие `tlib.mjs` и `cdp.mjs` в версии 15 переписаны (замечание C-02), `tests/legacy/tlib.mjs` и `cdp.mjs` теперь ссылаются на них;
- написаны заново при подготовке версий 14 и 15: остальные файлы `tools/` и `tests/` (в версии 15: `suite6.mjs`, `selftest.mjs` и `selftest/`, `verify-run.mjs`, `run-all.sh`, `steps.txt`, `expected.json`, `rvdiff.mjs`, `tools/mkkit6.py`, `tools/verify_kit.py`, `tools/check_docs15.py`, `tools/p_v15_*.py`, `tools/p_gen6.py`, `tools/p_checks6*.py`).

Не выдаётся за сохранённое: старые скрипты версий 10–12 в исходном рабочем каталоге утрачены; их результаты известны только из прежних отчётов. Первые записанные версии скриптов лежат без изменений в комплекте «Снимок версии 12» на странице комплекта.

## tests/evidence/
- `v14-before/`: запуск регрессий версии 15 на неизменённой версии 14 (до исправлений), воспроизведения замечаний и поведение прежней обвязки.
- `v14-baseline-new-harness/`: версия 14 под новой обвязкой (все прежние проверки проходят).

## visual/
Снимки сделаны скриптом `tests/rvshots.mjs` в настоящем Chrome (1440×900, 640×480) на страницах версии 15.
"""
mk('.')
open(os.path.join(dest, 'README.md'), 'w', encoding='utf-8').write(README % dict(project=count('project/'), tools=count('tools/'), tests=count('tests/'), visual=count('visual/'), review=count('review/'), total=n_total, png=n_png))
open(os.path.join(dest, 'PROVENANCE.md'), 'w', encoding='utf-8').write(PROV)

# --- манифест: все файлы, кроме самого MANIFEST.json
files = [p for p in allfiles() if p != 'MANIFEST.json']
assert len(files) == n_total, (len(files), n_total)
man = []
for p in files:
    b = open(os.path.join(dest, p), 'rb').read()
    man.append({'path': p, 'size': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
json.dump(man, open(os.path.join(dest, 'MANIFEST.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('комплект:', dest, '· файлов', len(man), '· PNG', sum(1 for m in man if m['path'].endswith('.png')), '· состояний', len(idx))
