# -*- coding: utf-8 -*-
# Генератор платформ-обёрток этапа 5 (написан заново при подготовке версии 14).
# python3 tools/mkboards5.py [каталог_project] → пишет <имя>.dc.html для каждой платформы и boards5.json
import json, sys, os
TPL = '''<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>%(title)s</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<style>body{margin:0}</style>
</helmet>
<dc-import name="App" theme="%(theme)s"%(attrs)s w="%(w)d" h="%(h)d" hint-size="%(w)dpx,%(h)dpx"></dc-import>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":%(w)d,"height":%(h)d}}'>
class Component extends DCLogic {
  renderVals() { return {}; }
}
</script>
</body>
</html>
'''
RUN = dict(scenario='running')
RS = dict(RUN, stop='rs', restart='true')
GONE = 'impl:gone,tests:gone'
UNSAVED = dict(scenario='done', conflict='unsaved', dbw='err', dbv='stopped')
RULES0 = '{"user":false,"denyPat":"npm run build","added":[]}'
RULES_ALLOW = '{"user":false,"denyPat":"npm run build","added":[{"id":"r1","type":"allow","tool":"Bash","pat":"npm run build","term":"turn"}]}'
APPLY = dict(scenario='done', conflict='interrupted', dialog='reconcile', rkind='apply', ar='completed')
MAN = dict(scenario='done', conflict='ambiguous', dialog='manual')
# (имя, заголовок, тема, параметры, w, h)
BOARDS = [
 ('AR-Seq-Dark', 'Применение: результат сохраняется · тёмная', 'dark', dict(APPLY, dstep='recsaving', recst='busy'), 1440, 900),
 ('AR-Saved-Light', 'Применение: результат сохранён · светлая', 'light', dict(APPLY, dstep='recsaved'), 1440, 900),
 ('AR-Fail-Dark', 'Применение: запись результата не удалась · тёмная', 'dark', dict(APPLY, dstep='recfail', wr='fail'), 1440, 900),
 ('AR-ManualDone-Light', 'Разбор: завершено и сохранено · светлая', 'light', dict(MAN, dstep='donesaved'), 1440, 900),
 ('AR-ManualFail-Dark', 'Разбор: завершено, запись не удалась · тёмная', 'dark', dict(MAN, dstep='donefail'), 1440, 900),
 ('AR-Unsaved-Banner-Light', 'Сессия: применено в Git, запись не сохранена · светлая', 'light', dict(UNSAVED), 1440, 900),
 ('E-DbErr-Dialog-Dark', 'Ошибка записи состояния: окно · тёмная', 'dark', dict(RUN, dbw='err', dbv='stopped', dialog='dberr'), 1440, 900),
 ('E-DbErr-Active-Light', 'Ошибка записи: остановка идёт · светлая', 'light', dict(RUN, dbw='err', dbv='active', dialog='dberr'), 1440, 900),
 ('E-DbErr-Mixed-Dark', 'Ошибка записи: остановка подтверждена не у всех · тёмная', 'dark', dict(RUN, dbw='err', dbv='mixed', dialog='dberr'), 1440, 900),
 ('E-DbErr-Banner-Light', 'Ошибка записи: сессия заблокирована · светлая', 'light', dict(RUN, dbw='err', dbv='mixed'), 1440, 900),
 ('E-DbErr-Solo-Dark', 'Ошибка записи: Solo · тёмная', 'dark', dict(RUN, team='solo', dbw='err', dbv='stopped', dialog='dberr'), 1440, 900),
 ('E-DbErr-Unsaved-Dark', 'Ошибка записи при незаписанном применении · тёмная', 'dark', dict(UNSAVED, dialog='dberr'), 1440, 900),
 ('E-DbErr-Recovered-Light', 'Запись восстановлена: нужна сверка · светлая', 'light', dict(RUN, dbw='rec', dbv='stopped', dialog='dberr'), 1440, 900),
 ('E-DbErr-Reconciled-Dark', 'Сверка после восстановления записи · тёмная', 'dark', dict(RUN, dbw='rec', dbv='mixed', dialog='dberr', dstep='reconciled'), 1440, 900),
 ('G-Orphan-Known-Light', 'Рабочая копия без сессии: владелец известен · светлая', 'light', dict(RUN, orph='known', dialog='orphan'), 1440, 900),
 ('G-Orphan-Unknown-Dark', 'Рабочая копия без сессии: владелец не установлен · тёмная', 'dark', dict(RUN, orph='unknown', dialog='orphan'), 1440, 900),
 ('G-Orphan-Recheck-Dark', 'Рабочая копия: повторная сверка не изменила исход · тёмная', 'dark', dict(RUN, orph='unknown', dialog='orphan', dstep='recheck'), 1440, 900),
 ('G-Orphan-Details-Light', 'Рабочая копия: сведения и сводка · светлая', 'light', dict(RUN, orph='known', dialog='orphan', dstep='details'), 1440, 900),
 ('G-Orphan-Restart-Light', 'Восстановление: рабочая копия без сессии · светлая', 'light', dict(RS, orph='unknown', dialog='restart', dstep='scroll:4000'), 1440, 900),
 ('G-Orphan-Sidebar-Dark', 'Список проектов: найдена копия без сессии · тёмная', 'dark', dict(RUN, orph='known'), 1440, 900),
 ('Q-PCtx-Banner-Dark', 'Swarm: диалог участника недоступен · тёмная', 'dark', dict(RS, rs=GONE, pctx='lost'), 1440, 900),
 ('Q-PCtx-Restart-Light', 'Восстановление: диалог «Тесты» недоступен · светлая', 'light', dict(RS, rs=GONE, pctx='lost', dialog='restart', dstep='scroll:470'), 1440, 900),
 ('Q-PCtx-Confirm-Dark', 'Новый диалог участника: подтверждение · тёмная', 'dark', dict(RS, rs=GONE, pctx='lost', dialog='ctxlost'), 1440, 900),
 ('Q-PCtx-Done-Light', 'Swarm: новый диалог создан, ход не начат · светлая', 'light', dict(RS, rs=GONE, pctx='new'), 1440, 900),
 ('L-Rules-New-Dark', 'Правила: новое разрешение · тёмная', 'dark', dict(scenario='denied', perm='none', dialog='rules', dstep='new'), 1440, 900),
 ('L-Rules-NewDeny-Light', 'Правила: новый запрет · светлая', 'light', dict(scenario='denied', perm='none', dialog='rules', dstep='newdeny'), 1440, 900),
 ('L-Rules-Error-Dark', 'Правила: ошибка в шаблоне вызова · тёмная', 'dark', dict(scenario='denied', perm='none', dialog='rules', dstep='newerr'), 1440, 900),
 ('L-Rules-Edit-Dark', 'Правила: изменение собственного запрета · тёмная', 'dark', dict(scenario='denied', perm='user', dialog='rules', dstep='edit'), 1440, 900),
 ('L-Rules-Delete-Light', 'Правила: удаление собственного запрета · светлая', 'light', dict(scenario='denied', perm='user', dialog='rules', dstep='del'), 1440, 900),
 ('L-Rules-Shadowed-Light', 'Правила: разрешение перекрыто запретом · светлая', 'light', dict(scenario='denied', perm='user', dialog='rules', dstep='shadow'), 1440, 900),
 ('L-Rules-Changed-Dark', 'Правила: запрет удалён, было и стало · тёмная', 'dark', dict(scenario='denied', perm='none', rls=RULES0, dialog='rules', dstep='changed'), 1440, 900),
 ('L-Rules-ChangedAllow-Light', 'Правила: разрешение сохранено, было и стало · светлая', 'light', dict(scenario='denied', perm='granted', rls=RULES_ALLOW, dialog='rules', dstep='changedallow'), 1440, 900),
 ('Z640-AutoRec-Dark', 'Окно 640×480: запись результата не удалась · тёмная', 'dark', dict(APPLY, dstep='recfail', wr='fail'), 640, 480),
 ('Z640-DbErr-Light', 'Окно 640×480: ошибка записи состояния · светлая', 'light', dict(RUN, dbw='err', dbv='mixed', dialog='dberr'), 640, 480),
 ('Z640-Orphan-Dark', 'Окно 640×480: рабочая копия без сессии · тёмная', 'dark', dict(RUN, orph='known', dialog='orphan'), 640, 480),
 ('Z640-PCtx-Light', 'Окно 640×480: диалог участника недоступен · светлая', 'light', dict(RS, rs=GONE, pctx='lost', dialog='ctxlost'), 640, 480),
 ('Z640-RulesForm-Dark', 'Окно 640×480: форма правила · тёмная', 'dark', dict(scenario='denied', perm='none', dialog='rules', dstep='new'), 640, 480),
 ('E-DbErr-OtherSession-Light', 'Ошибка записи: другая сессия, статус сохранён · светлая', 'light', dict(RUN, sess='csv', dbw='err', dbv='stopped'), 1440, 900),
 ('E-DbErr-NewSession-Dark', 'Ошибка записи: новая сессия заблокирована · тёмная', 'dark', dict(RUN, view='new', dbw='err', dbv='stopped'), 1440, 900),
 ('E-DbErr-AddProject-Light', 'Ошибка записи: добавление проекта заблокировано · светлая', 'light', dict(RUN, view='addp', addp='ok', dbw='err', dbv='stopped'), 1440, 900),
 ('E-DbErr-Checks-Dark', 'Ошибка записи: команды проверок заблокированы · тёмная', 'dark', dict(scenario='done', dbw='err', dialog='checks'), 1440, 900),
 ('E-DbErr-Review-Light', 'Ошибка записи: замечания ревью заблокированы · светлая', 'light', dict(scenario='done', view='review', tab='changes', rvfile='2', dbw='err'), 1440, 900),
 ('E-DbRec-Commit-Light', 'Запись восстановлена: коммит ждёт сверки · светлая', 'light', dict(scenario='done', dbw='rec', dialog='commit'), 1440, 900),
 ('AR-InFlight-Light', 'Применение: запись продолжается при закрытом окне · светлая', 'light', dict(scenario='done', conflict='interrupted', recst='busy'), 1440, 900),
 ('Z640-DbErr-New-Dark', 'Окно 640×480: новая сессия при ошибке записи · тёмная', 'dark', dict(RUN, view='new', dbw='err', dbv='stopped'), 640, 480),
 ('Z640-DbErr-Other-Light', 'Окно 640×480: другая сессия при ошибке записи · светлая', 'light', dict(sess='csv', dbw='err', dbv='stopped'), 640, 480),
 ('Z500-DbErr-Light', 'Окно 500×360: ошибка записи состояния · светлая', 'light', dict(RUN, dbw='err', dbv='stopped', dialog='dberr'), 500, 360),
]
# Тестовые обёртки: в публикацию не входят; нужны только сценарным проверкам tests/suite5.mjs
TESTS = [
 ('T-Recon-Completed', 'dark', dict(scenario='done', conflict='interrupted', dialog='reconcile', rkind='apply', ar='completed')),
 ('T-Recon-Fail', 'dark', dict(scenario='done', conflict='interrupted', dialog='reconcile', rkind='apply', ar='completed', wr='fail')),
 ('T-Recon-NotStarted', 'dark', dict(scenario='done', conflict='interrupted', dialog='reconcile', rkind='apply', ar='notstarted')),
 ('T-Recon-Ambiguous', 'dark', dict(scenario='done', conflict='interrupted', dialog='reconcile', rkind='apply', ar='ambiguous')),
 ('T-Manual', 'dark', dict(scenario='done', conflict='ambiguous', dialog='manual')),
 ('T-DbErr-Live', 'dark', dict(scenario='running', dbw='err', dbv='mixed')),
 ('T-DbErr-Unsaved', 'dark', dict(scenario='done', conflict='unsaved', dbw='err', dbv='stopped')),
 ('T-Orphan-Live', 'dark', dict(scenario='running', orph='unknown')),
 ('T-PCtx-Live', 'dark', dict(scenario='running', stop='rs', restart='true', rs='impl:gone,tests:gone', pctx='lost')),
 ('T-Recon-Interrupted', 'dark', dict(scenario='done', conflict='interrupted', ar='ambiguous')),
 ('T-Conflict', 'light', dict(scenario='done', conflict='conflict', dialog='conflict')),
 ('T-Review-Light', 'light', dict(scenario='done', view='review')),
 ('T-Denied-User', 'dark', dict(scenario='denied', perm='user')),
 ('T-Denied-None', 'dark', dict(scenario='denied', perm='none')),
 ('T-Denied-Policy', 'dark', dict(scenario='denied', perm='policy')),
 # версия 15: блокировка при отказе записи состояния во всех входах (B-02) и ход записи результата (A-09)
 ('T-DbErr-Commit', 'dark', dict(scenario='done', dbw='err', dialog='commit')),
 ('T-DbErr-Apply', 'dark', dict(scenario='done', dbw='err', dialog='apply')),
 ('T-DbErr-Push', 'dark', dict(scenario='done', committed='true', dbw='err', dialog='push')),
 ('T-DbErr-Discard', 'dark', dict(scenario='done', dbw='err', dialog='discard')),
 ('T-DbErr-Undo', 'dark', dict(scenario='applied', dbw='err', dialog='undo')),
 ('T-DbErr-Conflict', 'dark', dict(scenario='done', conflict='conflict', dbw='err', dialog='conflict')),
 ('T-DbErr-Bypass', 'dark', dict(scenario='nochecks', dbw='err', dialog='bypass')),
 ('T-DbErr-Checks', 'dark', dict(scenario='done', dbw='err', dialog='checks')),
 ('T-DbErr-Stale', 'dark', dict(scenario='stale', dbw='err')),
 ('T-DbErr-Queued', 'dark', dict(scenario='queued', team='solo', dbw='err')),
 ('T-DbErr-Review', 'dark', dict(scenario='done', view='review', dbw='err')),
 ('T-DbErr-Denied', 'dark', dict(scenario='denied', perm='none', dbw='err')),
 ('T-DbErr-Rules', 'dark', dict(scenario='denied', perm='none', dbw='err', dialog='rules')),
 ('T-DbErr-Restart', 'dark', dict(RS, rs=GONE, dbw='err', dialog='restart')),
 ('T-DbErr-PCtx', 'dark', dict(RS, rs=GONE, pctx='lost', dbw='err', dialog='ctxlost')),
 ('T-DbErr-StopOk', 'dark', dict(scenario='running', stop='ok', dbw='err')),
 ('T-DbErr-ReconApply', 'dark', dict(scenario='done', conflict='interrupted', dialog='reconcile', rkind='apply', ar='completed', dbw='err')),
 ('T-DbErr-Manual', 'dark', dict(scenario='done', conflict='ambiguous', dialog='manual', dbw='err')),
 ('T-DbErr-AddP', 'dark', dict(scenario='running', view='addp', addp='ok', dbw='err')),
 ('T-DbErr-AddPick', 'dark', dict(scenario='running', view='addp', dbw='err')),
 ('T-DbErr-New', 'dark', dict(scenario='running', view='new', dbw='err')),
 ('T-DbRec-Stale', 'dark', dict(scenario='stale', dbw='rec')),
 ('T-DbRec-Commit', 'dark', dict(scenario='done', dbw='rec', dialog='commit')),
 ('T-DbOk-AddP', 'dark', dict(scenario='running', view='addp', addp='ok')),
 ('T-DbOk-Checks', 'dark', dict(scenario='done', dialog='checks')),
 ('T-DbOk-Queued', 'dark', dict(scenario='queued', team='solo')),
 ('T-DbOk-Review', 'dark', dict(scenario='done', view='review')),
 ('T-DbOk-Commit', 'dark', dict(scenario='done', dialog='commit')),
]
SHEET = '''<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>%(title)s</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<style>body{margin:0}</style>
</helmet>
<dc-import name="%(comp)s" theme="%(theme)s" h="%(h)d" hint-size="1440px,%(h)dpx"></dc-import>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":1440,"height":%(h)d}}'>
class Component extends DCLogic {
  renderVals() { return {}; }
}
</script>
</body>
</html>
'''
DOCS = [('T-H1', 'Handoff1', 'dark'), ('T-H2', 'Handoff2', 'dark'), ('T-H3', 'Handoff3', 'dark'), ('T-H4', 'Handoff4', 'dark'), ('T-Trace', 'Trace', 'dark'), ('T-Map', 'Map', 'dark'), ('T-Prop2', 'Prop2', 'dark')]
SIZES = [(640, 480), (640, 452), (500, 360)]
# Проверка клавиатурного обхода боковых панелей (B-01): боевые платформы в обеих темах и трёх ширинах
FOCUS = ['D-Solo-Running-Dark', 'R-Review-Light', 'N1-New-Dark', 'X-Restart-Banner-Light']
FOCUS_SIZES = [(1440, 900), (1000, 800), (640, 480)]
def write_focus(outdir):
    import re
    for src in FOCUS:
        text = open(os.path.join(outdir, src + '.dc.html'), encoding='utf-8').read()
        m = re.search(r'<dc-import name="App"([^>]*)></dc-import>', text)
        attrs = m.group(1)
        for theme in ('dark', 'light'):
            for w, h in FOCUS_SIZES:
                a = re.sub(r' theme="[^"]*"', ' theme="%s"' % theme, attrs)
                a = re.sub(r' w="\d+"', ' w="%d"' % w, a); a = re.sub(r' h="\d+"', ' h="%d"' % h, a); a = re.sub(r' hint-size="[^"]*"', ' hint-size="%dpx,%dpx"' % (w, h), a)
                name = 'T-Focus-%s-%s-%d' % (src.rsplit('-', 1)[0], theme, w)
                open(os.path.join(outdir, name + '.dc.html'), 'w', encoding='utf-8').write(TPL.replace('<dc-import name="App" theme="%(theme)s"%(attrs)s w="%(w)d" h="%(h)d" hint-size="%(w)dpx,%(h)dpx"></dc-import>', '<dc-import name="App"' + a + '></dc-import>') % dict(title=name, theme=theme, attrs='', w=w, h=h))
def write_tests(outdir):
    write_focus(outdir)
    for name, comp, theme in DOCS:
        open(os.path.join(outdir, name + '.dc.html'), 'w', encoding='utf-8').write(SHEET % dict(title=name, comp=comp, theme=theme, h=9000))
    for name, theme, d in TESTS:
        open(os.path.join(outdir, name + '.dc.html'), 'w', encoding='utf-8').write(TPL % dict(title=name, theme=theme, attrs=attrs_of(d), w=1440, h=900))
        if name in ('T-DbErr-Live', 'T-Orphan-Live', 'T-PCtx-Live', 'T-Denied-None'):
            for w, h in SIZES:
                open(os.path.join(outdir, '%s-%dx%d.dc.html' % (name, w, h)), 'w', encoding='utf-8').write(TPL % dict(title=name, theme=theme, attrs=attrs_of(d), w=w, h=h))
def attrs_of(d):
    out = ''
    for k, v in d.items():
        out += ' %s="%s"' % (k, str(v).replace('&', '&amp;').replace('"', '&quot;'))
    return out
def write_all(outdir):
    for name, title, theme, d, w, h in BOARDS:
        open(os.path.join(outdir, name + '.dc.html'), 'w', encoding='utf-8').write(TPL % dict(title=title, theme=theme, attrs=attrs_of(d), w=w, h=h))
if __name__ == '__main__':
    out = [a for a in sys.argv[1:] if not a.startswith('--')][0] if [a for a in sys.argv[1:] if not a.startswith('--')] else 'project'
    write_all(out)
    if '--tests' in sys.argv: write_tests(out)
    json.dump([dict(name=b[0], title=b[1], theme=b[2], params=b[3], w=b[4], h=b[5]) for b in BOARDS], open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'boards5.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(len(BOARDS), 'платформ')
