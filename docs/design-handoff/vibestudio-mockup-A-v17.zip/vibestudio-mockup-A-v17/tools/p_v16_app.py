# -*- coding: utf-8 -*-
# Правки App.dc.html версии 16 (написаны заново). Применяются к App.dc.html версии 15:
#   python3 -I tools/p_v16_app.py project/App.dc.html
# Находка проверки настоящего масштаба браузера 200% (tests/ui7/zoom200.mjs): подзаголовок в шапке форм «Новая сессия»
# и «Добавить проект» при узком окне сокращался многоточием, полный текст был недоступен. Теперь строка переносится.
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pt import Patch
P = Patch(sys.argv[1])
P.rep("ctxStyle: 'min-width:0;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis',",
      "ctxStyle: 'min-width:0;flex:1 1 auto;overflow-wrap:anywhere',")
# Находка проверки дерева доступности (tests/ui7/ax.mjs): общая живая область #live находилась внутри <main>, который
# становится inert при открытом окне или накладке, поэтому объявления хода и завершения записи при открытом окне
# не передавались вспомогательным технологиям. Живая область перенесена в корень приложения, вне inert-областей.
P.rep('''    <div id="live" class="sr" role="status" aria-live="polite">{{liveText}}</div>\n''', '')
P.rep('''  <!-- Центр -->\n''', '''  <!-- Живая область объявлений: вне main и боковых панелей, чтобы не попадать под inert при открытом окне -->\n  <div id="live" class="sr" role="status" aria-live="polite">{{liveText}}</div>\n\n  <!-- Центр -->\n''')
# Находка проверки нативных элементов (tests/ui7/native.mjs): в тёмной теме макета флажки, радиокнопки и полосы прокрутки
# рисовались светлыми, потому что тема макета переключается атрибутом data-theme, а color-scheme не задан. В приложении
# tokens.css объявляет color-scheme: light dark, и нативные элементы следуют теме. Макет приведён к этому поведению;
# новых токенов и цветов нет.
P.rep('''.app{\n  --color-bg:#151514;''', '''.app{\n  color-scheme:dark;\n  --color-bg:#151514;''')
P.rep('''.app[data-theme="light"]{\n''', '''.app[data-theme="light"]{\n  color-scheme:light;\n''')
P.save()
