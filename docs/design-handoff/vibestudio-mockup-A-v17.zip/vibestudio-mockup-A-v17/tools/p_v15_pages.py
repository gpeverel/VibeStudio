# -*- coding: utf-8 -*-
# Правки NewSession, AddProject, Review версии 15 (замечание B-02): при недоступной записи состояния операция не начинается.
# Применяется один раз к файлам версии 14:  python3 tools/p_v15_pages.py project
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from pt import Patch
D = sys.argv[1] if len(sys.argv) > 1 else 'project'
WHY_ERR = 'Запись состояния недоступна: действие заблокировано во всех сессиях и проектах. Читать данные можно.'
WHY_REC = 'Запись восстановлена, но сначала нужна сверка: действие остаётся заблокированным.'
BANNER = '''<div role="alert" id="%(id)s" style="padding:var(--space-3) var(--space-4);border:1px solid var(--color-danger);border-radius:var(--radius-md);display:flex;gap:var(--space-3);align-items:flex-start"><svg class="ic bad" viewBox="0 0 16 16" aria-hidden="true" style="margin-top:3px"><path d="M8 2.5a5.5 5.5 0 1 0 0 11a5.5 5.5 0 1 0 0-11z"/><path d="M6 6l4 4M10 6l-4 4"/></svg><div style="flex:1;min-width:0"><div class="semi">{{dbTitle}}</div><div class="sm muted">%(text)s</div></div></div>'''

# ---------- NewSession
N = Patch(os.path.join(D, 'NewSession.dc.html'))
N.rep('''  <div id="ns-scroll" style="flex:1;min-height:0;overflow:auto">
    <div style="{{colStyle}}">
''', '''  <div id="ns-scroll" style="flex:1;min-height:0;overflow:auto">
    <div style="{{colStyle}}">
      <sc-if value="{{dbBlocked}}">''' + BANNER % dict(id='ns-dbw', text='Форму можно заполнить и посмотреть, но создать сессию и пройти подготовку нельзя, пока запись не восстановлена: приложение не смогло бы записать намерение и исход. Это касается всех проектов.') + '''</sc-if>
''')
N.rep('''<sc-if value="{{canCreate}}"><span class="{{leadCls}} med">{{lead}}</span> <span class="muted">{{summary}}</span></sc-if><sc-if value="{{cantCreate}}">''',
      '''<sc-if value="{{dbBlocked}}"><span class="med bad">Создание заблокировано:</span> <span class="muted" id="ns-dbwhy">{{dbWhy}}</span></sc-if><sc-if value="{{canCreate}}"><span class="{{leadCls}} med">{{lead}}</span> <span class="muted">{{summary}}</span></sc-if><sc-if value="{{cantCreate}}">''')
N.rep('''<button class="btn btn-primary" id="ns-create" disabled="{{createOff}}" onClick="{{create}}">''', '''<button class="btn btn-primary" id="ns-create" disabled="{{createOff}}" aria-describedby="ns-dbwhy" onClick="{{create}}">''')
N.rep("      canCreate, cantCreate: !canCreate,", "      dbBlocked: !!p.blocked, dbTitle: p.blocked === 'err' ? 'Запись состояния недоступна: сессия не будет создана' : 'Запись восстановлена: сначала нужна сверка', dbWhy: p.blocked === 'err' ? '%s' : '%s',\n      canCreate: canCreate && !p.blocked, cantCreate: !canCreate && !p.blocked," % (WHY_ERR, WHY_REC))
N.rep("      createOff: !canCreate, create: () => this.begin(pm === 'fail' || pm === 'fail-safe' || pm === 'interrupted'),",
      "      createOff: !canCreate || !!p.blocked, create: () => { if (p.blocked) return; this.begin(pm === 'fail' || pm === 'fail-safe' || pm === 'interrupted'); },")
# повторы подготовки и новая копия — тоже начинают операцию
N.rep('''<button class="btn btn-primary" id="ns-retry" onClick="{{doRetry}}">''', '''<button class="btn btn-primary" id="ns-retry" disabled="{{dbBlocked}}" aria-describedby="ns-prepwhy" onClick="{{doRetry}}">''')
N.rep('''<button class="btn btn-primary" id="ns-new" onClick="{{doNew}}">''', '''<button class="btn btn-primary" id="ns-new" disabled="{{dbBlocked}}" aria-describedby="ns-prepwhy" onClick="{{doNew}}">''')
N.rep('''<button class="btn btn-primary" id="ns-recon" onClick="{{doRecon}}">Сверить состояние</button>''', '''<button class="btn btn-primary" id="ns-recon" disabled="{{dbBlocked}}" aria-describedby="ns-prepwhy" onClick="{{doRecon}}">Сверить состояние</button>''')
N.rep("      doRetry: () => { this.setState(", "      doRetry: () => { if (p.blocked) return; this.setState(")
N.rep("      doNew: () => { this.setState(", "      doNew: () => { if (p.blocked) return; this.setState(")
N.rep("      doRecon: () => { this.setState({ recon: 'done' }); },", "      doRecon: () => { if (p.blocked) return; this.setState({ recon: 'done' }); },")
N.rep("      showRecon: unknownState,", "      prepWhy: p.blocked ? '%s' : '',\n      showRecon: unknownState," % WHY_ERR.replace(' Читать данные можно.', ''))
N.rep('''<sc-if value="{{showRecon}}">''', '''<sc-if value="{{dbBlocked}}"><div id="ns-prepwhy" class="sm bad semi" style="flex-basis:100%">{{prepWhy}}</div></sc-if>
              <sc-if value="{{showRecon}}">''')
N.rep('"prep":{"editor":"text","default":""}', '"prep":{"editor":"text","default":""},"blocked":{"editor":"text","default":""}')
N.save()

# ---------- AddProject
A = Patch(os.path.join(D, 'AddProject.dc.html'))
# баннер стоит под заголовком: фокус на заголовке («ap-h») прокручивает страницу к нему, и баннер над ним оказывался за верхним краем
A.rep('''        <section style="display:flex;flex-direction:column;gap:var(--space-3)" aria-labelledby="ap-hl">''', '''        <sc-if value="{{dbBanner}}">''' + BANNER % dict(id='ap-dbw', text='Папку можно выбрать и проверить (это только чтение), но добавить проект нельзя, пока запись не восстановлена: список проектов хранится в базе. Это касается всех проектов.') + '''</sc-if>

        <section style="display:flex;flex-direction:column;gap:var(--space-3)" aria-labelledby="ap-hl">''')
A.rep('''<sc-if value="{{rCanAdd}}"><button class="btn btn-primary" id="ap-add" onClick="{{add}}">Добавить проект</button></sc-if>''',
      '''<sc-if value="{{rCanAdd}}"><button class="btn btn-primary" id="ap-add" disabled="{{dbBlocked}}" aria-describedby="ap-dbwhy" onClick="{{add}}">Добавить проект</button><sc-if value="{{dbBlocked}}"><span id="ap-dbwhy" class="muted sm" style="flex:1;min-width:160px">{{dbWhy}}</span></sc-if></sc-if>''')
A.rep("      rCanAdd: R.add, rCanRecheck: R.again, rNoAdd: R.noAdd,",
      "      dbBanner: !!p.blocked && !(phase === 'result' && !!C), dbBlocked: !!p.blocked, dbTitle: p.blocked === 'err' ? 'Запись состояния недоступна: проект не будет добавлен' : 'Запись восстановлена: сначала нужна сверка', dbWhy: p.blocked === 'err' ? '%s' : '%s',\n      rCanAdd: R.add, rCanRecheck: R.again, rNoAdd: R.noAdd," % (WHY_ERR, WHY_REC))
A.rep("      add: () => { if (p.onAdded)", "      add: () => { if (p.blocked) return; if (p.onAdded)")
A.rep('"existing":{"editor":"text"', '"blocked":{"editor":"text","default":""},"existing":{"editor":"text"')
A.save()

# ---------- Review
R = Patch(os.path.join(D, 'Review.dc.html'))
R.rep('''  <div style="flex:none;border-top:1px solid var(--color-border);background:var(--color-bg)">
    <sc-if value="{{sendOpen}}">''', '''  <div style="flex:none;border-top:1px solid var(--color-border);background:var(--color-bg)">
    <sc-if value="{{dbBlocked}}"><div id="rv-dbw" role="alert" class="sm" style="padding:var(--space-2) var(--pad);display:flex;gap:var(--space-2);align-items:flex-start;border-bottom:1px solid var(--color-border)"><svg class="ic bad" viewBox="0 0 16 16" aria-hidden="true" style="margin-top:2px"><path d="M8 2.5a5.5 5.5 0 1 0 0 11a5.5 5.5 0 1 0 0-11z"/><path d="M6 6l4 4M10 6l-4 4"/></svg><span style="flex:1;min-width:0"><span class="semi">{{dbTitle}}</span> <span class="muted">{{dbWhy}}</span></span></div></sc-if>
    <sc-if value="{{sendOpen}}">''')
R.rep('''<button class="btn btn-primary" id="rv-send" aria-expanded="{{sendOpen}}" disabled="{{sendOff}}" onClick="{{openSend}}">''',
      '''<button class="btn btn-primary" id="rv-send" aria-expanded="{{sendOpen}}" disabled="{{sendOff}}" aria-describedby="rv-dbw" onClick="{{openSend}}">''')
R.rep('''<button class="btn btn-primary" id="rv-send-go" onClick="{{doSend}}">''', '''<button class="btn btn-primary" id="rv-send-go" disabled="{{dbBlocked}}" onClick="{{doSend}}">''')
R.rep('''<button class="btn" onClick="{{i.toggle}}">{{i.toggleLabel}}</button>''', '''<button class="btn" disabled="{{dbBlocked}}" onClick="{{i.toggle}}">{{i.toggleLabel}}</button>''')
R.rep('''<button class="btn btn-primary" id="rv-add" disabled="{{draftOff}}" onClick="{{addComment}}">''', '''<button class="btn btn-primary" id="rv-add" disabled="{{draftOff}}" aria-describedby="rv-dbw" onClick="{{addComment}}">''')
R.rep("sendOff: openCount === 0, sendOpen:", "sendOff: openCount === 0 || !!p.blocked, dbBlocked: !!p.blocked, dbTitle: p.blocked === 'err' ? 'Запись состояния недоступна:' : 'Запись восстановлена, нужна сверка:', dbWhy: 'замечания нельзя сохранить, изменить и отправить на доработку. Читать diff и ветки замечаний можно.', sendOpen:")
R.rep("sendOff: openCount === 0 || !!p.blocked, dbBlocked", "sendOff: openCount === 0 || !!p.blocked, dbBlocked")
R.rep("      addComment: () => addNow(),", "      addComment: () => { if (p.blocked) return; addNow(); },")
R.rep("      doSend: () => {", "      doSend: () => { if (p.blocked) return;")
R.rep("    const setC = (next) => { if (p.onComments) p.onComments(next); };", "    const setC = (next) => { if (p.blocked) return; if (p.onComments) p.onComments(next); };")
R.rep("draftOff: draftText.trim().length === 0,", "draftOff: draftText.trim().length === 0 || !!p.blocked,")
R.rep('"compact":{"editor":"bool","default":false}', '"compact":{"editor":"bool","default":false},"blocked":{"editor":"text","default":""}')
R.save()
