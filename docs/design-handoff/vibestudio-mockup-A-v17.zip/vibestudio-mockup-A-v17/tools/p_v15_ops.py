# -*- coding: utf-8 -*-
# Правки Ops.dc.html версии 15 (замечания B-02 и A-09). Применяется один раз к файлу версии 14:
#   python3 tools/p_v15_ops.py project/Ops.dc.html
import sys
sys.path.insert(0, __import__('os').path.dirname(__file__))
from pt import Patch
P = Patch(sys.argv[1] if len(sys.argv) > 1 else 'project/Ops.dc.html')

# --- A-09: ход записи результата принадлежит приложению, а не окну ---------------------------------------------
P.rep('''  beginRec(src) {
    const p = this.props, fail = (this.state.dbsim ?? (p.wr === 'fail' ? 'down' : 'up')) === 'down';
    this.setState({ wp: 1, wfail: false, wtry: 0 });
    this.later(() => this.setState({ wp: 2 }), 700);
    this.later(() => { this.setState({ wp: 3, wfail: fail }); if (p.onDone) p.onDone({ kind: src, result: 'completed', saved: !fail }); }, 1700);
  }
  retryRec(src) {
    const p = this.props, up = (this.state.dbsim ?? 'down') === 'up', n = (this.state.wtry || 0) + 1;
    if (up) { this.setState({ wp: 4, wtry: n }); this.later(() => { this.setState({ wp: 3, wfail: false }); if (p.onDone) p.onDone({ kind: src, result: 'completed', saved: true, recovered: true }); }, 1100); }
    else { this.setState({ wp: 2, wtry: n }); this.later(() => this.setState({ wp: 3, wfail: true }), 800); }
  }''', '''  // Запись результата применения (шаги 1–4) выполняет приложение (App.recRun): окно только показывает ход и просит начать.
  // Закрытие окна ход не прерывает; повторное открытие показывает фактическое состояние (props.recw), а не начинает заново.
  beginRec(src) { if (this.props.onRec) this.props.onRec('begin', src, {}); }''')

P.rep('''      const wp = s.wp ?? (WPS[stt] || 1), wfail = s.wfail ?? /fail$/.test(stt), tries = s.wtry || 0;
      const fin = wp === 3, retry = wp === 4, saving = wp === 2 || retry, sha = 'c91d2e8';''',
'''      const R = (p.recw && p.recw.src === src) ? p.recw : null;
      const wp = R ? R.wp : (s.wp ?? (WPS[stt] || 1)), wfail = R ? R.fail : (s.wfail ?? /fail$/.test(stt)), tries = R ? R.tries : (s.wtry || 0);
      const simV = R ? R.sim : (s.dbsim ?? 'down'), seed = { wp, fail: wfail, tries, sim: simV };
      const fin = wp === 3, retry = wp === 4, saving = wp === 2 || retry, sha = 'c91d2e8';''')

P.rep('''value: s.dbsim ?? 'down', opts: [{ v: 'down', t: 'Запись по-прежнему недоступна' }, { v: 'up', t: 'Запись восстановлена' }], change: (e) => this.setState({ dbsim: e.currentTarget.value }) });
        blocks.push(P('Повторное применение не запускается.''',
'''value: simV, opts: [{ v: 'down', t: 'Запись по-прежнему недоступна' }, { v: 'up', t: 'Запись восстановлена' }], change: (e) => { if (p.onRec) p.onRec('sim', src, Object.assign({}, seed, { sim: e.currentTarget.value })); else this.setState({ dbsim: e.currentTarget.value }); } });
        blocks.push(P('Повторное применение не запускается.''')

P.rep('''B('dlg-retry-rec', 'Повторить сохранение', 'btn-primary', false, () => this.retryRec(src));''',
      '''B('dlg-retry-rec', 'Повторить сохранение', 'btn-primary', false, () => { if (p.onRec) p.onRec('retry', src, seed); });''')
P.rep('''else blocks.push(P('Окно можно закрыть: запись продолжится.', 'muted sm'));''',
      '''else blocks.push(P('Окно можно закрыть: запись продолжится и результат появится в сессии. Повторное открытие окна показывает актуальное состояние и вторую запись не начинает.', 'muted sm'));''')

# reconcile (apply): повторное открытие окна во время или после записи
P.rep('''const res = s.rres ?? (String(p.start || '').startsWith('rec') ? 'completed' : String(p.start || '') === 'ambig' ? 'ambiguous' : '');''',
      '''const res = s.rres ?? ((p.recw && p.recw.src === 'reconcile') || String(p.start || '').startsWith('rec') ? 'completed' : String(p.start || '') === 'ambig' ? 'ambiguous' : '');''')
P.rep('''const mres = s.mres ?? (start.startsWith('done') ? 'done' : start === 'revert' ? 'revert' : start === 'stay' ? 'none' : '');''',
      '''const mres = s.mres ?? ((p.recw && p.recw.src === 'manual') || start.startsWith('done') ? 'done' : start === 'revert' ? 'revert' : start === 'stay' ? 'none' : '');''')

# --- B-02: окно «Ошибка записи состояния» --------------------------------------------------------------------
P.rep('''const dsim = s.dbsim ?? 'down', solo = !!p.solo,''', '''const recBusy = !!(p.recw && p.recw.busy), dsim = s.dbsim ?? 'down', solo = !!p.solo,''')
P.rep('''поэтому новые изменяющие действия заблокированы, а активный запуск останавливается.', 'alert'));
        if (tries > 0)''', '''поэтому новые изменяющие действия заблокированы во всех сессиях и проектах, а не только в этой, а активный запуск останавливается.', 'alert'));
        if (recBusy) blocks.push(AL('info', 'Идёт повторное сохранение результата применения', 'Запись уже выполняется и не зависит от этого окна. Новую проверку записи можно запустить после её завершения.'));
        if (tries > 0)''')
P.rep('''blocks.push(LS('Что заблокировано', [['lock', 'Новые ходы и сообщения', 'Их нельзя записать'], ['lock', 'Коммит, push, применение и отбрасывание'], ['lock', 'Setup и запуск проверок']]));''',
      '''blocks.push(LS('Что заблокировано во всех сессиях и проектах', [['lock', 'Новые сессии, добавление проекта и подготовка (setup)', 'Начатая операция не получила бы записи о намерении'], ['lock', 'Новые ходы и сообщения', 'Их нельзя записать'], ['lock', 'Коммит, push, применение, отмена и отбрасывание'], ['lock', 'Запуск проверок, правила, разрешения и замечания ревью', 'Эти изменения тоже записываются в базу']]));''')
P.rep('''blocks.push(LS('Что доступно', [['ok', 'Читать сохранённую ленту и результаты', 'Данные могут быть неполными'], ['ok', 'Открыть расположение базы и скопировать диагностическую сводку']]));''',
      '''blocks.push(LS('Что доступно', [['ok', 'Читать сохранённую ленту, историю и результаты любой сессии', 'Данные могут быть неполными; статусы завершённых сессий остаются прежними'], ['ok', 'Открыть форму, но не завершить действие: кнопка объяснит причину'], ['ok', 'Открыть расположение базы и скопировать диагностическую сводку']]));''')
P.rep("""'заблокировано: ходы, коммит, push, применение, отбрасывание, setup, проверки'""",
      """'заблокировано во всех сессиях: новые сессии, добавление проекта, ходы, коммит, push, применение, отбрасывание, setup, проверки, правила, замечания'""")
P.rep('''B('dlg-run', 'Проверить запись снова', 'btn-primary', false, () => { this.go('working', 900, 'form');''',
      '''B('dlg-run', 'Проверить запись снова', 'btn-primary', recBusy, () => { this.go('working', 900, 'form');''')
P.rep('''B('dlg-recon', 'Выполнить сверку', 'btn-primary', false, () => { this.go('working', 1100, 'form');''',
      '''B('dlg-recon', 'Выполнить сверку', 'btn-primary', recBusy, () => { this.go('working', 1100, 'form');''')

# --- B-02: единая блокировка изменяющих операций в окнах -------------------------------------------------------
P.rep('''    const compact = !!p.compact;
    const wideKinds =''', '''    // Пока запись состояния недоступна (или не выполнена сверка после её восстановления), изменяющие операции не начинаются
    // независимо от сессии и проекта. Открыть форму можно, начать операцию нельзя; кнопка остаётся видимой и объясняет причину.
    const DBW = p.dbw || '';
    const GUARD = {
      commit: ['dlg-go'], push: ['dlg-go'], apply: ['dlg-go', 'dlg-go2', 'dlg-redo'], bypass: ['dlg-go'], discard: ['dlg-go'], undo: ['dlg-go', 'dlg-go2'],
      conflict: ['dlg-merge'], checks: ['dlg-go'], perm: ['dlg-go', 'dlg-next'], rule: ['dlg-go', 'dlg-next'], ctxlost: ['dlg-go'], rules: ['dlg-rsave', 'dlg-rdel'],
      reconcile: ['dlg-prep', 'dlg-resume'].concat(DBW === 'err' ? ['dlg-run'] : []), manual: ['dlg-prep'].concat(DBW === 'err' ? ['dlg-run'] : []), restart: ['rs-resume']
    };
    const gids = DBW ? (GUARD[kind] || []) : [];
    if (gids.length) {
      const why = DBW === 'err' ? 'Запись состояния недоступна: это действие заблокировано во всех сессиях и проектах.' : 'Запись восстановлена, но сначала нужна сверка: это действие остаётся заблокированным.';
      let hit = false;
      buttons.forEach((b) => { if (gids.includes(b.id)) { b.off = true; b.desc = 'dlg-foot'; hit = true; } });
      blocks.forEach((b) => {
        if (b.isActs) b.rows.forEach((r) => { if (gids.includes(r.id)) { r.off = true; r.why = why; hit = true; } });
        if (b.isRecon) b.rows.forEach((rw) => (rw.actions || []).forEach((a) => { if (gids.includes(a.id)) { a.off = true; a.why = why; hit = true; } }));
      });
      if (hit) {
        blocks.unshift(AL(DBW === 'err' ? 'err' : 'warn', DBW === 'err' ? 'Запись состояния недоступна: действие не будет выполнено' : 'Запись восстановлена: сначала нужна сверка', DBW === 'err'
          ? 'Форму можно открыть и посмотреть, но начать операцию нельзя ни в этой, ни в других сессиях: приложение не смогло бы записать намерение и исход. Читать историю и результаты можно.'
          : 'База снова принимает запись, но изменяющие действия остаются заблокированными, пока приложение не сверит записи с процессами и Git. Прерванное само не повторяется.', 'alert'));
        const bi = buttons.findIndex((b) => b.cls.includes('btn-primary') || b.cls.includes('btn-danger'));
        buttons.splice(bi < 0 ? buttons.length : bi, 0, { id: 'dlg-dbstate', label: DBW === 'err' ? 'Состояние записи…' : 'Выполнить сверку…', cls: '', off: false, desc: undefined, go: () => { if (p.onSwitch) p.onSwitch('dberr', ''); } });
        foot = why;
      }
    }

    const compact = !!p.compact;
    const wideKinds =''')
P.rep('''const B = (id, label, cls, off, go) => buttons.push({ id, label, cls: cls || '', off: !!off, go });''',
      '''const B = (id, label, cls, off, go) => buttons.push({ id, label, cls: cls || '', off: !!off, go, desc: undefined });''')
P.rep('''<span class="muted sm" style="flex:1;min-width:160px">{{footNote}}</span>
        <sc-for list="{{buttons}}" as="x">
          <button class="btn {{x.cls}}" id="{{x.id}}" disabled="{{x.off}}" onClick="{{x.go}}">{{x.label}}</button>''',
      '''<span class="muted sm" id="dlg-foot" style="flex:1;min-width:160px">{{footNote}}</span>
        <sc-for list="{{buttons}}" as="x">
          <button class="btn {{x.cls}}" id="{{x.id}}" disabled="{{x.off}}" aria-describedby="{{x.desc}}" onClick="{{x.go}}">{{x.label}}</button>''')
P.rep('''"rls":{"editor":"text","default":""}''', '''"rls":{"editor":"text","default":""},"recw":{"editor":"text","default":""}''')
P.save()
