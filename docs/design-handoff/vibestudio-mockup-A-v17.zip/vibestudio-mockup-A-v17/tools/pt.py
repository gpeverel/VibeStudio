# общий помощник: точная замена с проверкой количества вхождений
import sys, re
class Patch:
    def __init__(self, path):
        self.path = path; self.s = open(path, encoding='utf-8').read(); self.n = 0
    def rep(self, old, new, count=1):
        c = self.s.count(old)
        if c != count:
            raise SystemExit('FAIL %s: ожидалось %d вхождений, найдено %d для:\n%s' % (self.path, count, c, old[:200]))
        self.s = self.s.replace(old, new); self.n += 1
    def save(self):
        open(self.path, 'w', encoding='utf-8').write(self.s); print('ok', self.path, self.n, 'замен')
