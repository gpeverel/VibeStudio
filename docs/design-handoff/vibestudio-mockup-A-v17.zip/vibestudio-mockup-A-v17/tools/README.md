# tools/ — скрипты версий 14–17

## Происхождение
Исходная сборка версий 10–12 (каталог `src/`, `build.py` и др.) утрачена: рабочий каталог находился во временной папке сессии. Версия 12 восстановлена из опубликованных файлов, версия 14 получена правкой этих файлов, версия 15 — правкой опубликованной версии 14, версия 16 — правкой пакета версии 15 (`bundles/v15-final.json`, восстановлен с опубликованной страницы комплекта и сверен с его MANIFEST.json), версия 17 — правкой окончательного комплекта версии 16 (`bundles/v16-final.json`).

| Файл | Происхождение |
|---|---|
| `gen_handoff_v12.py` | Извлечён из журнала сессии без изменений: генератор листов пакета передачи версии 12 |
| `pt.py` | Извлечён из журнала: помощник точной замены текста с проверкой числа вхождений |
| `mkboards5.py`, `boards5.json` | Написаны заново для версии 14, дополнены в версии 15: платформы-обёртки (в 15 — девять новых), тестовые обёртки `T-*`, обёртки проверки обхода панелей `T-Focus-*` |
| `p_ops1.py` … `p_ops4.py`, `p_app1.py` | Написаны заново для версии 14: история правок `Ops.dc.html` и `App.dc.html` версии 12 → 13. **Не воспроизводят версию 14 целиком** |
| `p_docs5.py`, `p_prop5.py` | Написаны заново для версии 14: правки `Map`, `Trace`, `Prop2` версии 12 |
| `p_gen5.py`, `gen_handoff5.py`, `mkchecks5.py`, `checks5.json`, `update_canvas5.py`, `mkrv.py`, `mkkit5.py` | Версия 14 (оставлены как история). `mkrv.py` в версии 15 дополнен платформами `E-DbRec-*` |
| `p_v15_ops.py`, `p_v15_app.py`, `p_v15_pages.py`, `p_v15_docs.py` | **Написаны заново для версии 15.** Правки `Ops`, `App`, `NewSession`, `AddProject`, `Review`, `Proposals`, примененные к опубликованным файлам версии 14. **Воспроизведение проверено:** применение скриптов к файлам версии 14 даёт файлы версии 15 побайтно (команды ниже) |
| `remap_spec_lines.py`, `spec-linemap-68472d5-07776e2.json` | Версия 15: пересчёт номеров строк `docs/SPEC.md` в ссылках «стр. N» (SPEC изменился 15.10.2026 после версии 14); таблица построена `difflib` по `git show 68472d5:docs/SPEC.md` и текущему файлу |
| `p_checks6.py`, `p_checks6b.py` → `mkchecks6.py` | Версия 15: создают `mkchecks6.py` из `mkchecks5.py`; `mkchecks6.py` собирает матрицу проверок, сценарии, таблицу замечаний ревью и решения из результатов прогона (`checks6.json`) |
| `p_gen6.py` → `gen_handoff6.py` | Версия 15: создаёт `gen_handoff6.py` из `gen_handoff5.py`; генератор пишет `Handoff1–3.dc.html` |
| `check_docs15.py` | Версия 15: сверка чисел контраста и значений `--color-border-strong` на листах с результатами прогона (замечание B-03) |
| `mkkit6.py`, `mkbundle.py`, `verify_kit.py` | Версия 15: сборка комплекта и `MANIFEST.json` (все файлы, включая PNG, кроме самого манифеста), JSON-пакет для страницы комплекта, сверка распакованного комплекта с манифестом и README (замечание C-01) |
| `mkcompare.py` | Версия 15: список платформ для сравнения отрисовки двух версий (`tests/rvdiff.mjs`) |
| `basis.json` | Версия 16: основание листов — коммит и дата последнего изменения `docs/SPEC.md`, HEAD репозитория, что в коде готово и чего нет. Источник для `p_v16_docs.py`, `gen_handoff7.py` и `check_docs15.py` |
| `p_v16_app.py`, `p_v16_pages.py`, `p_v16_docs.py` | **Написаны заново для версии 16.** Правки `App` (перенос подзаголовка, живая область вне inert, color-scheme темы), `NewSession` (причина недоступности привязана к кнопке), листов `Trace`, `Map`, `Prop2`, `Proposals` (основание SPEC, состояние кода, охват автоскана, нативные элементы). Применяются к файлам версии 15 |
| `mkv16.py` → `checks7.json` | Версия 16: матрица проверок версии 15, дополненная результатами `tests/ui7`, замечаниями ревью Version 17, решениями к согласованию и границами этапа |
| `p_gen7.py` → `gen_handoff7.py` | Версия 16: создаёт `gen_handoff7.py` из `gen_handoff6.py`; генератор пишет `Handoff1–4.dc.html` (лист 4 — новый) |
| `mkproposals.py` | Версия 16: точные предлагаемые изменения `tokens.css` и `DESIGN.md` в виде патчей (`proposals/`), репозиторий только читается; каждый патч проверяется `git apply --check` на временной копии |
| `update_canvas7.py` | Версия 16: высоты листов, платформы листа 4 (`H4-Dark`, `H4-Light`, компонент `Handoff4`), заголовок версии 16 на холсте |
| `mkkit7.py` | Версия 16: сборка комплекта (добавлены `tests/ui7`, `proposals/`, доказательства версии 16) и `MANIFEST.json` |
| `check_docs15.py` | Расширен в версии 16: охват автоскана на всех листах (историческое число — только с пометкой), контраст нативных элементов, основание SPEC и состояние кода по `basis.json`, с `--repo` — сверка с репозиторием |
| `mkboards5.py`, `tests/heights.mjs` | В версии 16 добавлен лист 4 (`T-H4`) |
| `p_v17_app.py`, `p_v17_pages.py`, `p_v17_docs.py` | **Написаны заново для версии 17.** `App`: при ширине области меньше 400 CSS px раскладка не ниже 440 CSS px и окно прокручивается целиком, текстовое поле в фокусе докручивается в видимую область, затемнение — `--color-scrim`; `Review`: область diff не ниже 160 CSS px; листы `Proposals`, `Prop2`, `Map`, `Trace`, `Sheet2` — статусы после согласования 27.10.2026. Применяются к файлам версии 16 |
| `mkv17.py` → `checks8.json` | Версия 17: матрица версии 16 с результатами версии 17 (окно 640×480 при 200%), согласование 27.10.2026, ограничения площадки, список проверок приложения. Останавливается, если числа других наборов разошлись с версией 16 |
| `p_gen8.py` → `gen_handoff8.py` | Версия 17: создаёт `gen_handoff8.py` из `gen_handoff7.py`; листы 1–4 со статусами согласования, лист 4 — внесённый diff, ограничения площадки, проверки приложения |
| `update_canvas8.py`, `mkkit8.py` | Версия 17: высоты листов и заголовок версии 17 на холсте; сборка комплекта и `MANIFEST.json` |
| `basis.json`, `check_docs15.py` | В версии 17 — раздел `design` (согласование 27.10.2026, значения токенов, разделы и SHA-256 `DESIGN.md` и `tokens.css`); сверка токенов макета, статусов VoiceOver, ограничений площадки и проверок приложения, с `--repo` — `tokens.css` и `DESIGN.md` |
| `visual_list.json`, `serve.sh` | Список ключевых состояний для снимков; локальный сервер |

## Воспроизведение правок версии 15 (из каталога комплекта)

```sh
mkdir -p /tmp/replay/project && cp <версия 14>/project/{App,Ops,NewSession,AddProject,Review,Proposals,Map,Trace,Sheet2}.dc.html /tmp/replay/project/
cd /tmp/replay
python3 -I <комплект>/tools/p_v15_ops.py project/Ops.dc.html
python3 -I <комплект>/tools/p_v15_app.py project/App.dc.html
python3 -I <комплект>/tools/p_v15_pages.py project
python3 -I <комплект>/tools/remap_spec_lines.py project/Map.dc.html project/Trace.dc.html project/Sheet2.dc.html
python3 -I <комплект>/tools/p_v15_docs.py project/Proposals.dc.html <комплект>/tests/results
# результат совпадает с <комплект>/project/*.dc.html (cmp)
```

## Порядок сборки документов и комплекта (из каталога сборки)
1. `python3 tools/mkboards5.py project --tests` — обёртки платформ и тестовые; `python3 tools/mkrv.py` и `python3 tools/mkcompare.py` — списки для просмотра и сравнения.
2. `sh tests/run-all.sh` — полный прогон в отдельной распакованной копии комплекта.
3. `python3 tools/p_checks6.py && python3 tools/p_checks6b.py`, затем `RESULTS_DIR=<результаты> python3 tools/mkchecks6.py`, `python3 tools/p_gen6.py` (один раз), `python3 tools/gen_handoff6.py`.
4. `node tests/heights.mjs`, затем `python3 tools/update_canvas5.py` (положение и высоты досок в `canvas.json`).
5. `python3 tools/check_docs15.py <результаты>`, `python3 tools/mkkit6.py <каталог> --results … --evidence … --shots …`, `python3 tools/mkbundle.py <каталог> <пакет.json> <метка> --skip-png`, `python3 -I tools/verify_kit.py <каталог>`.

Шаги 3–4 меняют `project/Handoff*.dc.html` и `project/canvas.json`. Шаги 1–2 страницы приложения не меняют.

## Воспроизведение правок версии 16 (из каталога комплекта)

```sh
mkdir -p /tmp/replay16/project && cp <версия 15>/project/{App,NewSession,Trace,Map,Prop2,Proposals}.dc.html /tmp/replay16/project/
cd /tmp/replay16 && mkdir -p tools && cp <комплект>/tools/{pt.py,basis.json,p_v16_app.py,p_v16_pages.py,p_v16_docs.py} tools/
python3 -I tools/p_v16_app.py project/App.dc.html
python3 -I tools/p_v16_pages.py project
python3 -I tools/p_v16_docs.py project <комплект>/tests/results <комплект>/tests/results/ui7
# результат совпадает с <комплект>/project/*.dc.html (cmp)
```

## Порядок сборки версии 16 (из каталога сборки)
1. `p_v16_app.py`, `p_v16_pages.py` — страницы приложения; полный прогон `sh tests/run-all.sh` (вместе с `tests/ui7`) в отдельной распакованной копии.
2. `p_v16_docs.py project <результаты> <результаты>/ui7`; `RESULTS_DIR=<результаты> python3 tools/mkchecks6.py`; `RESULTS_DIR=… UI7_DIR=… UI7_BEFORE=… python3 tools/mkv16.py`; `python3 -I tools/mkproposals.py <репозиторий>`; `python3 -I tools/p_gen7.py`; `python3 tools/gen_handoff7.py`.
3. `node tests/ui7/heights.mjs`, затем `python3 -I tools/update_canvas7.py <heights.json>`.
4. `python3 tools/mkkit7.py <каталог> --results … --evidence … --shots …`, `python3 tools/mkbundle.py …`, `python3 -I tools/verify_kit.py <каталог>`.

## Воспроизведение правок версии 17 (из каталога комплекта)

```sh
mkdir -p /tmp/replay17/project && cp <версия 16>/project/{App,Review,Proposals,Prop2,Map,Trace,Sheet2}.dc.html /tmp/replay17/project/
cd /tmp/replay17 && mkdir -p tools && cp <комплект>/tools/{pt.py,basis.json,p_v17_app.py,p_v17_pages.py,p_v17_docs.py} tools/
python3 -I tools/p_v17_app.py project/App.dc.html
python3 -I tools/p_v17_pages.py project/Review.dc.html
python3 -I tools/p_v17_docs.py project
# результат совпадает с <комплект>/project/*.dc.html (cmp)
```

## Порядок сборки версии 17 (из каталога сборки)
1. `p_v17_app.py`, `p_v17_pages.py` — страницы приложения; `p_v17_docs.py project` — листы.
2. Предварительный прогон `sh tests/run-all.sh` в отдельной копии (числа для листов); `RESULTS_DIR=… PREV_DIR=<результаты версии 16> ZOOM_BEFORE=… python3 tools/mkv17.py`; `python3 -I tools/p_gen8.py`; `python3 tools/gen_handoff8.py`.
3. `node tests/ui7/heights.mjs`, затем `python3 -I tools/update_canvas8.py <heights.json>`.
4. Окончательный прогон `sh tests/run-all.sh` в чистой распакованной копии; `python3 tools/mkkit8.py <каталог> --results … --evidence … --shots …`, `python3 tools/mkbundle.py …`, `python3 -I tools/verify_kit.py <каталог>`.
