# -*- coding: utf-8 -*-
# Пересчитывает номера строк docs/SPEC.md в ссылках «стр. N» после изменения SPEC (коммит 07776e2, 15.10.2026 17:31: +4 строки выше 124-й).
# Таблица соответствия — tools/spec-linemap-68472d5-07776e2.json (построена difflib по git show 68472d5:docs/SPEC.md и текущему файлу).
# python3 tools/remap_spec_lines.py файл...   (идемпотентность не гарантируется: применять один раз к файлам версии 14)
import json, re, sys, os
M = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'spec-linemap-68472d5-07776e2.json')))
def fix(m):
    # перечисления «124, 142–144» и диапазоны «185–187»: пересчитывается каждое число, разделители сохраняются
    return m.group(1) + re.sub(r'\d+', lambda k: str(M.get(k.group(0), k.group(0))), m.group(2))
for f in sys.argv[1:]:
    s = open(f, encoding='utf-8').read()
    t = re.sub(r'(стр\. )(\d+(?:[–-]\d+)?(?:, ?\d+(?:[–-]\d+)?)*)', fix, s)
    if t != s: open(f, 'w', encoding='utf-8').write(t); print('пересчитано', f)
    else: print('без изменений', f)
