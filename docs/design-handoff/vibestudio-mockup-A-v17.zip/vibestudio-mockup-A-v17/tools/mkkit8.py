# -*- coding: utf-8 -*-
# Собирает каталог комплекта версии 17 и MANIFEST.json (создан из mkkit7.py версии 16: тексты README и PROVENANCE версии 17,
# visual-review-v17.json; proposals/ — патчи версии 16 и фактически внесённый diff).
#   python3 tools/mkkit8.py <каталог_назначения> --results <каталог_результатов> --evidence <каталог_доказательств> --shots <каталог_снимков>
# MANIFEST.json перечисляет ВСЕ файлы комплекта, включая PNG, с размером и SHA-256. Единственное исключение — сам MANIFEST.json (самоссылка).
import os, re, shutil, json, sys, hashlib

def arg(name, default=None):
    return sys.argv[sys.argv.index('--' + name) + 1] if ('--' + name) in sys.argv else default
dest = [a for a in sys.argv[1:] if not a.startswith('--')][0]
RES, EVI, SHOTS = arg('results', 'tests/results'), arg('evidence', 'tests/evidence'), arg('shots', 'tests/shots/rv')
if os.path.exists(dest): shutil.rmtree(dest)
def mk(*d): os.makedirs(os.path.join(dest, *d), exist_ok=True)
def cp(src, dst):
    mk(os.path.dirname(dst)); shutil.copy(src, os.path.join(dest, dst))

# project: страницы приложения и документов, холст, рантайм (обёртки T-* и RV-* создаются сценариями и в комплект не входят)
for f in sorted(os.listdir('project')):
    if re.match(r'^(T-|RV-)', f): continue
    if f.endswith('.dc.html') or f in ('canvas.json', 'support.js'): cp('project/' + f, 'project/' + f)
# tools
for f in sorted(os.listdir('tools')):
    p = os.path.join('tools', f)
    if os.path.isfile(p) and not f.endswith('.pyc'): cp(p, 'tools/' + f)
# tests: сценарии, обвязка, самопроверка
for f in ('cdp.mjs', 'tlib.mjs', 'suite5.mjs', 'suite6.mjs', 'selftest.mjs', 'scan5.mjs', 'shots.mjs', 'rvshots.mjs', 'rvdiff.mjs', 'tokens5.mjs', 'heights.mjs', 'montage.mjs', 'verify-run.mjs', 'run-all.sh', 'steps.txt', 'expected.json', 'README.md', 'tokens5.json', 'visual-review.json', 'visual-review-v16.json', 'visual-review-v17.json', 'play-check.json'):
    if os.path.exists('tests/' + f): cp('tests/' + f, 'tests/' + f)
for f in sorted(os.listdir('tests/selftest')): cp('tests/selftest/' + f, 'tests/selftest/' + f)
for f in sorted(os.listdir('tests/ui7')):
    if f.endswith('.mjs'): cp('tests/ui7/' + f, 'tests/ui7/' + f)
# изменения tokens.css и DESIGN.md: патчи версии 16 и фактически внесённый 27.10.2026 diff (applied-2026-10-27.patch)
for f in sorted(os.listdir('proposals')): cp('proposals/' + f, 'proposals/' + f)
for f in ('t7.mjs', 't8.mjs', 't9.mjs', 't10.mjs', 't11.mjs', 't12.mjs', 'tlib.mjs', 'cdp.mjs', 'CHANGES.md'): cp('tests/legacy/' + f, 'tests/legacy/' + f)
# результаты прогона на распакованной копии (получены ПОСЛЕ сборки: добавляются в комплект как данные) и доказательства «до»
for root, _, files in os.walk(RES):
    for f in files:
        rel = os.path.relpath(os.path.join(root, f), RES)
        cp(os.path.join(root, f), 'tests/results/' + rel)
if os.path.isdir(EVI):
    for root, _, files in os.walk(EVI):
        for f in files:
            rel = os.path.relpath(os.path.join(root, f), EVI)
            cp(os.path.join(root, f), 'tests/evidence/' + rel)
if os.path.exists('review/rv.json'): cp('review/rv.json', 'review/rv.json')
# visual: ключевые состояния версии 15, обе темы, 1:1
VIS = json.load(open('tools/visual_list.json', encoding='utf-8'))
idx = []
for name, title in VIS:
    have = True
    for t in ('dark', 'light'):
        src = os.path.join(SHOTS, 'RV-%s-%s.png' % (name, t))
        if not os.path.exists(src): have = False; print('нет снимка', src)
    if not have: continue
    for t in ('dark', 'light'): cp(os.path.join(SHOTS, 'RV-%s-%s.png' % (name, t)), 'visual/%s-%s.png' % (name, t))
    idx.append({'name': name, 'title': title})
mk('visual'); json.dump(idx, open(os.path.join(dest, 'visual/index.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# --- состав и числа для README
def allfiles():
    out = []
    for root, _, files in os.walk(dest):
        for f in files: out.append(os.path.relpath(os.path.join(root, f), dest).replace(os.sep, '/'))
    return sorted(out)
pre = [p for p in allfiles()]
n_png_pre = sum(1 for p in pre if p.endswith('.png'))
def count(prefix): return sum(1 for p in pre if p.startswith(prefix))
n_total = len(pre) + 2   # + README.md и PROVENANCE.md, создаваемые ниже (MANIFEST.json не считается)
n_png = n_png_pre
README = """# VibeStudio · макет A «Три панели» · версия 17

Редактируемый комплект дизайн-макета: страницы, раскладка холста, платформенный рантайм, скрипты сборки и проверок, результаты прогона, доказательства «до», снимки ключевых состояний и изменения контракта. Макет — не реализация приложения: UI сессий в коде нет (лист 4 пакета передачи, раздел «Состояние реализации»).

Версия 17 выпущена по решениям пользователя от 27.10.2026: десять решений листа 4 приняты в рекомендованном варианте и вместе с текстами решений 15 и 18 внесены в `docs/DESIGN.md` и `src/renderer/styles/tokens.css` рабочей копии репозитория VibeStudio **без коммита** (diff — `proposals/applied-2026-10-27.patch`); минимальное окно 640×480 проверено при настоящем масштабе 200%%; VoiceOver перенесён на приёмку приложения. Версии 16, 15 и 14 сохранены неизменными пакетами на странице комплекта (`bundles/v16-final.json`, `bundles/v15-final.json`, `bundles/v14-final.json`).

**Нумерация.** «Версия 17» — номер ревизии макета и этого комплекта; номер публикации на платформе (Version N) указан на странице комплекта и в сверке опубликованных файлов (`verify/v17-published-compare.json`, вне архива).

## Состав

| Каталог | Файлов | Содержимое |
|---|---|---|
| `project/` | %(project)d | Страницы `.dc.html`: приложение (`App`, `Ops`, `NewSession`, `AddProject`, `Review`), документы (`Map`, `Trace`, `Prop2`, `Proposals`, `Handoff1–4`), платформы-обёртки, `canvas.json`, `support.js` (платформенный рантайм) |
| `tools/` | %(tools)d | Скрипты сборки, правок и проверки комплекта; происхождение — в `tools/README.md` |
| `tests/` | %(tests)d | Сценарии, самопроверка обвязки, автоскан, набор `tests/ui7`, результаты прогона в `tests/results/`, доказательства в `tests/evidence/`; описание — `tests/README.md` |
| `proposals/` | %(proposals)d | Патчи версии 16 (`d0`, `d1`, `d2`, `d9`, `all.patch`) и фактически внесённый diff `applied-2026-10-27.patch` |
| `visual/` | %(visual)d | Снимки ключевых состояний при 1:1 в обеих темах (PNG) и `index.json` |
| `review/` | %(review)d | Список платформ просмотра |
| корень | 2 | `README.md`, `PROVENANCE.md` |

Всего файлов в комплекте, не считая `MANIFEST.json`: **%(total)d**, в том числе PNG: **%(png)d**.

## Манифест

`MANIFEST.json` — список `{path, size, sha256}` для каждого файла комплекта, включая PNG и этот README. **Исключён только сам `MANIFEST.json`** (он не может содержать собственную сумму). Сверка:

```sh
python3 -I tools/verify_kit.py .      # из каталога распакованного комплекта; код возврата 0 — всё совпало
```

## Как запустить проверки

Распакуйте комплект в отдельный каталог. Нужны Node 22+, Python 3, Google Chrome и пакет `playwright` (каталог пакета — в `PLAYWRIGHT_DIR`).

```sh
PLAYWRIGHT_DIR=<каталог playwright> sh tests/run-all.sh      # VIBESTUDIO_REPO=<репозиторий> — сверка листов с кодом, tokens.css и DESIGN.md
```

Код возврата 0 — только при полном успешном прогоне. Порты: `MOCKUP_PORT` и `CDP_PORT` из окружения; если их нет, скрипт выбирает свободные (так и было в итоговом прогоне — с разрешения пользователя, порты окружением не выделялись). Набор `tests/ui7` портов не использует.

## Что здесь не так, как кажется

- Исходная сборка версий 10–12 утрачена; версия 17 получена правкой файлов версии 16. Источник правды — `project/`. Скрипты `tools/p_v17_*.py` описывают правки версии 17 и проверены на воспроизведение (`tools/README.md`).
- Скрипты `tests/legacy/` извлечены из журнала рабочей сессии и изменены; это не восстановленный прежний набор тестов.
- `support.js` — копия платформенного `artifact-type/dc-runtime.js`; `canvas.json` платформа может переписывать. Совпадение с опубликованной версией проверено на дату публикации.
- Шаг `docs` с `VIBESTUDIO_REPO` сверяет `tokens.css` и `DESIGN.md` с `tools/basis.json` по SHA-256: после коммита или правки этих файлов в репозитории основание нужно обновить.
- Основание листов — SPEC на `07776e2` и код на `749f040`. После окончательного прогона репозиторий ушёл вперёд (`9c08008`: изменён SPEC, добавлен RPC-адаптер Codex, P3), поэтому шаг `docs` с текущим репозиторием не проходит (2 из 68) — описано в `tests/evidence/v17/repo-drift/`. Номера «стр. N» после строки 121 и «Codex в коде нет» относятся к основанию, не к текущему репозиторию.
- VoiceOver не проверялся: перенесён на приёмку приложения. Дерево доступности Chrome его не заменяет. Проверка браузерного макета на macOS — не приёмка нативного поведения Electron-приложения.
"""
PROV = """# Происхождение файлов, версия 17

## project/
- Страницы приложения и документов: пакет версии 16 (`bundles/v16-final.json`; опубликован как Version 18, `1793032088-f7c8`) плюс правки версии 17 (`tools/p_v17_app.py`, `tools/p_v17_pages.py`, `tools/p_v17_docs.py`, генератор листов `tools/gen_handoff8.py`, холст `tools/update_canvas8.py`). Версия 16 — правка пакета версии 15 (Version 17, `1792286621-25ae`), та — правка опубликованной версии 14 (`1792072575-8814`), та — правка опубликованной версии 12 (`1791973368-bfe9`). Исходная сборка версий 10–12 (каталог `src/`, `build.py` и др.) находилась во временной папке сессии, была очищена и **не восстановлена**.
- Платформы-обёртки создаёт `tools/mkboards5.py`; обёртки `T-*` и `RV-*` в комплект не входят. `support.js` — копия `artifact-type/dc-runtime.js` опубликованной версии.
- Основание документов (`tools/basis.json`): `docs/SPEC.md` на коммите 07776e2 (15.10.2026), состояние кода — репозиторий на 749f040 (19.10.2026), дизайн-контракт — согласование 27.10.2026, `docs/DESIGN.md` и `src/renderer/styles/tokens.css` в рабочей копии без коммита (SHA-256 в `basis.json`).

## proposals/
- `d0`–`d9`, `all.patch`, `index.json` — патчи версии 16 (`tools/mkproposals.py`) на основе файлов коммита `bc6a5c9`.
- `applied-2026-10-27.patch` — `git diff` рабочей копии после внесения: `all.patch` и абзац о масштабе 200% в разделе «Размер окна» `DESIGN.md`.

## tools/ и tests/
Таблица происхождения — в `tools/README.md` и `tests/README.md`. Коротко:
- извлечены из журнала сессии без изменений: `tools/gen_handoff_v12.py`, `tools/pt.py`;
- извлечены из журнала и изменены: `tests/legacy/t7–t12.mjs` (`tests/legacy/CHANGES.md`);
- написаны заново при подготовке версий 14–17: остальные файлы; в версии 17 — `tools/p_v17_*.py`, `tools/mkv17.py`, `tools/p_gen8.py`, `tools/update_canvas8.py`, `tools/mkkit8.py`; изменены `tests/ui7/zoom200.mjs`, `tests/tokens5.mjs`, `tools/check_docs15.py`, `tools/basis.json`, `tests/expected.json`.

## tests/evidence/
- `v14-before/`, `v14-baseline-new-harness/`, `v15-after/`, `v15-before/`, `v14-control/`, `v16/` — как в версии 16.
- `v17/` — проверка `zoom200` версии 17 на файлах версии 16 («до»), прежняя проверка на окне 640×480, предварительный прогон, Play-проверка Version 18.

## visual/
Снимки сделаны `tests/ui7/rvshots.mjs` (Playwright, Chrome) на страницах версии 17, 1440×900 и 640×480.
"""
mk('.')
open(os.path.join(dest, 'README.md'), 'w', encoding='utf-8').write(README % dict(project=count('project/'), tools=count('tools/'), tests=count('tests/'), visual=count('visual/'), review=count('review/'), proposals=count('proposals/'), total=n_total, png=n_png))
open(os.path.join(dest, 'PROVENANCE.md'), 'w', encoding='utf-8').write(PROV)

# --- манифест: все файлы, кроме самого MANIFEST.json
files = [p for p in allfiles() if p != 'MANIFEST.json']
assert len(files) == n_total, (len(files), n_total)
man = []
for p in files:
    b = open(os.path.join(dest, p), 'rb').read()
    man.append({'path': p, 'size': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
json.dump(man, open(os.path.join(dest, 'MANIFEST.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('комплект:', dest, '· файлов', len(man), '· PNG', sum(1 for m in man if m['path'].endswith('.png')), '· состояний', len(idx))
