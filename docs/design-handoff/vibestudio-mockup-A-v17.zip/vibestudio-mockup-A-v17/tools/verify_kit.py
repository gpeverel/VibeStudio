# -*- coding: utf-8 -*-
# Сверка распакованного комплекта с MANIFEST.json и README (замечание C-01).
#   python3 -I tools/verify_kit.py <каталог_комплекта> [--json файл_результата]
# Код возврата 0 — только если: каждый файл на диске (кроме MANIFEST.json) есть в манифесте, каждая запись манифеста есть на диске,
# размеры и SHA-256 совпадают, PNG входят в манифест, числа в README («Всего файлов…», «в том числе PNG») равны фактическим.
import hashlib, json, os, re, sys
args = [a for a in sys.argv[1:] if not a.startswith('--')]
root = args[0] if args else '.'
outp = sys.argv[sys.argv.index('--json') + 1] if '--json' in sys.argv else None
rep = {'script': 'verify_kit.py', 'root': os.path.abspath(root), 'problems': []}
bad = rep['problems']
try: man = json.load(open(os.path.join(root, 'MANIFEST.json'), encoding='utf-8'))
except Exception as e: man = []; bad.append('MANIFEST.json не читается: %s' % e)
disk = {}
for d, _, fs in os.walk(root):
    for f in fs:
        p = os.path.relpath(os.path.join(d, f), root).replace(os.sep, '/')
        if p != 'MANIFEST.json': disk[p] = os.path.join(d, f)
inman = {m['path']: m for m in man}
if len(inman) != len(man): bad.append('в манифесте есть повторяющиеся пути')
for p in sorted(set(disk) - set(inman)): bad.append('файл не внесён в манифест: ' + p)
for p in sorted(set(inman) - set(disk)): bad.append('файл из манифеста отсутствует: ' + p)
for p in sorted(set(disk) & set(inman)):
    b = open(disk[p], 'rb').read(); m = inman[p]
    if len(b) != m['size']: bad.append('размер не совпал: %s (%d, в манифесте %d)' % (p, len(b), m['size']))
    elif hashlib.sha256(b).hexdigest() != m['sha256']: bad.append('SHA-256 не совпал: ' + p)
png_disk = [p for p in disk if p.lower().endswith('.png')]; png_man = [p for p in inman if p.lower().endswith('.png')]
if sorted(png_disk) != sorted(png_man): bad.append('PNG: на диске %d, в манифесте %d' % (len(png_disk), len(png_man)))
rd = open(os.path.join(root, 'README.md'), encoding='utf-8').read() if os.path.exists(os.path.join(root, 'README.md')) else ''
m = re.search(r'Всего файлов в комплекте, не считая `MANIFEST.json`: \*\*(\d+)\*\*, в том числе PNG: \*\*(\d+)\*\*', rd)
if not m: bad.append('README: нет строки с числом файлов')
else:
    if int(m.group(1)) != len(disk): bad.append('README: файлов %s, фактически %d' % (m.group(1), len(disk)))
    if int(m.group(2)) != len(png_disk): bad.append('README: PNG %s, фактически %d' % (m.group(2), len(png_disk)))
for dname, cnt in re.findall(r'\| `([a-z]+/)` \| (\d+) \|', rd):
    n = sum(1 for p in disk if p.startswith(dname))
    if int(cnt) != n: bad.append('README: каталог %s — %s, фактически %d' % (dname, cnt, n))
rep.update({'files': len(disk), 'png': len(png_disk), 'manifest_entries': len(man), 'excluded_from_manifest': ['MANIFEST.json'], 'status': 'passed' if not bad else 'failed'})
if outp: json.dump(rep, open(outp, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('Комплект %s: файлов %d (PNG %d), записей в манифесте %d, замечаний %d' % (root, len(disk), len(png_disk), len(man), len(bad)))
for b in bad[:30]: print('  НЕТ', b)
sys.exit(1 if bad else 0)
