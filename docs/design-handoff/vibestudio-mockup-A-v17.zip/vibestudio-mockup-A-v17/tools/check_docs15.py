# -*- coding: utf-8 -*-
# Сверка листов-документов с фактическим прогоном (замечание B-03): числа контраста и значения --color-border-strong.
# Версия 16 (независимое ревью Version 17): охват автоскана на всех листах (историческое число допускается только с пометкой),
# контраст нативных флажков и радиокнопок, основание SPEC и состояние кода по tools/basis.json, при --repo — сверка с репозиторием.
# Версия 17 (согласование 27.10.2026): токены макета = согласованным (basis.json → design); статусы VoiceOver, ограничений
# площадки и проверок приложения на листах; числа zoom200 и нативного контраста; при --repo — tokens.css и DESIGN.md.
# python3 tools/check_docs15.py [каталог_результатов] [--ui7 каталог_результатов_ui7] [--repo путь_к_репозиторию_VibeStudio]
#   → <каталог_результатов>/docs-check.json; код 0 только если всё совпало.
import json, os, re, subprocess, sys
def opt(k):
    return sys.argv[sys.argv.index(k) + 1] if k in sys.argv else None
_pos = [a for i, a in enumerate(sys.argv[1:], 1) if not a.startswith('--') and sys.argv[i - 1] not in ('--ui7', '--repo')]
rd = _pos[0] if _pos else 'tests/results'
sc = json.load(open(os.path.join(rd, 'scan5.json'), encoding='utf-8'))
f = lambda v: ('%.2f' % v).replace('.', ',')
T = {k: f(sc['minText'][k]) for k in ('light', 'dark')}; I = {k: f(sc['minIcon'][k]) for k in ('light', 'dark')}; Bo = {k: f(sc['minBorder'][k]) for k in ('light', 'dark')}
src = {n: open('project/%s.dc.html' % n, encoding='utf-8').read() for n in ('Proposals', 'Prop2', 'Handoff2', 'Handoff3')}
checks = []
def need(doc, text, what):
    checks.append({'doc': doc, 'what': what, 'ok': text in src[doc], 'text': text})
need('Proposals', 'текст — минимум %s:1 в светлой и %s:1 в тёмной теме' % (T['light'], T['dark']), 'минимум контраста текста в прогоне')
need('Proposals', 'значки (порог 3:1) — %s:1 и %s:1' % (I['light'], I['dark']), 'минимум контраста значков в прогоне')
need('Proposals', 'границы полей (порог 3:1) — %s:1 и %s:1' % (Bo['light'], Bo['dark']), 'минимум контраста границ в прогоне')
need('Proposals', 'на %d платформах приложения' % sc['scanned'], 'охват: число платформ')
need('Prop2', 'минимум %s в тёмной и %s в светлой' % (Bo['dark'], Bo['light']), 'Prop2: минимум границ полей')
need('Handoff3', 'минимум %s : 1 в светлой и %s : 1 в тёмной теме при пороге 4,5' % (T['light'], T['dark']), 'Handoff3: текст')
need('Handoff3', 'минимум %s : 1 в светлой и %s : 1 в тёмной теме' % (I['light'], I['dark']), 'Handoff3: значки')
need('Handoff3', 'минимум %s : 1 в светлой и %s : 1 в тёмной теме' % (Bo['light'], Bo['dark']), 'Handoff3: границы')
for doc in ('Proposals', 'Prop2', 'Handoff2'):
    need(doc, '#6f6f69', doc + ': тёмная #6f6f69'); need(doc, '#858580', doc + ': светлая #858580')
# прежние кандидаты допустимы только в Proposals и только с пометкой «исторически»
for doc, s in src.items():
    for old in ('#696965', '#8c8c88'):
        if old in s:
            ctx = s[max(0, s.index(old) - 220): s.index(old) + 60]
            checks.append({'doc': doc, 'what': 'прежнее значение %s помечено историческим' % old, 'ok': doc == 'Proposals' and 'исторически' in ctx, 'text': old})
# --- версия 16: охват автоскана на всех листах-документах
DOCS = [n[:-8] for n in sorted(os.listdir('project')) if n.endswith('.dc.html') and re.match(r'^(Proposals|Prop2|Handoff\d|Map|Trace|Sheet2?)\.dc\.html$', n)]
HIST = re.compile(r'верси[ияюей] 1[0-4]|историческ|Прежнее|прежнее|прежней редакции')
cov = []
for n in DOCS:
    t = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', open('project/%s.dc.html' % n, encoding='utf-8').read()))
    for m in re.finditer(r'(?:[Аа]втоскан\w*|DOM|[Рр]асч[её]т\w*)[^.;]{0,90}?\b(\d{2,3}) платформ', t):
        k = int(m.group(1)); ctx = t[max(0, m.start() - 160): m.end() + 120]
        okv = k == sc['scanned'] or bool(HIST.search(ctx))
        cov.append({'doc': n, 'n': k, 'ok': okv})
        checks.append({'doc': n, 'what': 'охват автоскана %d платформ = фактическому %d или помечен историческим' % (k, sc['scanned']), 'ok': okv, 'text': ctx[:200]})
    for m in re.finditer(r'\b(\d{2,3}) платформ\w* (?:в обеих темах|приложения)', t):
        k = int(m.group(1)); ctx = t[max(0, m.start() - 160): m.end() + 120]
        if any(c['doc'] == n and c['n'] == k for c in cov): continue
        okv = k == sc['scanned'] or bool(HIST.search(ctx))
        checks.append({'doc': n, 'what': 'охват %d платформ = фактическому %d или помечен историческим' % (k, sc['scanned']), 'ok': okv, 'text': ctx[:200]})
# --- версия 16: контраст нативных элементов (если есть результаты tests/ui7)
ui7 = opt('--ui7')
if ui7:
    nat = json.load(open(os.path.join(ui7, 'native.mjs.json'), encoding='utf-8'))
    mn = nat['nativeContrast']['min']; N = {t: f(min(v for k, v in mn.items() if k.endswith('/' + t) and v is not None)) for t in ('dark', 'light')}
    checks.append({'doc': 'ui7', 'what': 'нативные элементы: прогон native.mjs пройден', 'ok': nat.get('status') == 'passed', 'text': nat.get('status')})
    need('Prop2', 'минимум %s в тёмной и %s в светлой теме' % (N['dark'], N['light']), 'Prop2: контраст нативных элементов из native.mjs')
    need('Proposals', 'минимум %s в тёмной и %s в светлой' % (N['dark'], N['light']), 'Proposals: контраст нативных элементов из native.mjs')
# --- версия 16: основание SPEC и состояние кода
B = json.load(open('tools/basis.json', encoding='utf-8'))
for n in ('Trace', 'Handoff1'):
    src[n] = open('project/%s.dc.html' % n, encoding='utf-8').read()
    need(n, 'коммите %s (%s)' % (B['spec']['commit'], B['spec']['date_ru']), n + ': основание SPEC — коммит и дата из basis.json')
for n in ('Trace', 'Map', 'Handoff1'):
    src[n] = open('project/%s.dc.html' % n, encoding='utf-8').read()
    need(n, B['repo']['head'], n + ': состояние кода указано по репозиторию на ' + B['repo']['head'])
STALE = ['на 2026-10-14', 'последнее изменение файла в Git — 11.10.2026', 'P1 (strict / practical) не выполнен', 'раздельный результат нет', 'по SPEC §0 UI сессий в коде ещё нет', 'По SPEC §0 UI сессий в коде ещё нет',
         # версия 17: статусы до согласования 27.10.2026 и неверные числа версии 16
         'контраст не измерялся', 'Масштаб 200% и VoiceOver', 'Ни одно решение не утверждено', 'Ни одно не утверждено', 'Предложение (не утверждено)', 'предложение (не утверждено)',
         'остаются предложениями', 'Ожидает согласования', 'ПРЕДЛАГАЕМЫЙ', 'Предложения не внесены в репозиторий', 'Контракт в репозитории не менялся', 'tokens.css и DESIGN.md не менялись',
         'после окончательного утверждения', '720×450 и 500×360 CSS px', '(320×240 CSS)', 'считать окно 1280×960', 'Окно 640×480 при 200% (320×240 CSS) не проверялось', 'перенос в репозиторий не утверждён', 'на утверждении']
for n in DOCS:
    t = open('project/%s.dc.html' % n, encoding='utf-8').read()
    for st in STALE:
        if st in t: checks.append({'doc': n, 'what': 'устаревшее утверждение', 'ok': False, 'text': st})
# --- версия 17: согласованный контракт, VoiceOver, ограничения площадки, проверки приложения
D = B['design']
def plain(n):
    import html as _h
    return re.sub(r'\s+', ' ', _h.unescape(re.sub(r'<[^>]+>', ' ', open('project/%s.dc.html' % n, encoding='utf-8').read())))
def blk(css, sel):
    m = re.search(re.escape(sel) + r'\s*\{([^}]*)\}', css); return m.group(1) if m else ''
def tokv(body, name):
    m = re.search(re.escape(name) + r':\s*([^;]+);', body); return re.sub(r'\s+', ' ', m.group(1).strip()) if m else None
app = open('project/App.dc.html', encoding='utf-8').read()
for name, vals in D['tokens'].items():
    got = {'dark': tokv(blk(app, '.app'), name), 'light': tokv(blk(app, '.app[data-theme="light"]'), name)}
    checks.append({'doc': 'App', 'what': 'макет: %s = согласованному значению (basis.json)' % name, 'ok': got == vals, 'text': got})
checks.append({'doc': 'App', 'what': 'макет: затемнение под окнами берёт --color-scrim', 'ok': '.scrim{position:absolute;inset:0;z-index:39;background:var(--color-scrim)}' in app, 'text': '.scrim'})
P3, P4, P1 = plain('Handoff3'), plain('Handoff4'), plain('Handoff1')
for n, t, what in (('Handoff1', P1, 'VoiceOver: перенесено на приёмку приложения'), ('Handoff3', P3, 'VoiceOver: перенесено на приёмку приложения'), ('Handoff4', P4, 'VoiceOver: перенесено на приёмку приложения')):
    checks.append({'doc': n, 'what': what, 'ok': 'перенесено на приёмку приложения' in t, 'text': 'перенесено на приёмку приложения'})
for txt in ('События мыши внутри Play', 'Подтверждение «Save file» при скачивании ZIP'):
    i = P3.find(txt); checks.append({'doc': 'Handoff3', 'what': 'ограничение площадки отдельной строкой со статусом «Не проверено»: ' + txt, 'ok': i >= 0 and 'Не проверено' in P3[i:i + 120], 'text': P3[i:i + 120] if i >= 0 else txt})
checks.append({'doc': 'Handoff4', 'what': 'отдельный список проверок приложения', 'ok': 'Проверки приложения' in P4 and 'VoiceOver: ручной сценарий (лист 3)' in P4, 'text': 'Проверки приложения'})
checks.append({'doc': 'Handoff4', 'what': 'решения: десять со статусом «Согласовано %s»' % D['agreed_ru'], 'ok': P4.count('Согласовано %s' % D['agreed_ru']) >= 10, 'text': P4.count('Согласовано %s' % D['agreed_ru'])})
for n, t in (('Handoff3', P3), ('Handoff4', P4)):
    for m in re.finditer(r'1280×960', t):
        ctx = t[max(0, m.start() - 160): m.end() + 160]
        checks.append({'doc': n, 'what': '1280×960 при 200% названо рекомендацией, не минимумом', 'ok': 'рекомендаци' in ctx and 'считать окно' not in ctx, 'text': ctx[:200]})
if ui7:
    z = json.load(open(os.path.join(ui7, 'zoom200.mjs.json'), encoding='utf-8'))
    zc = '%d из %d' % (z['pass'], z['pass'] + z['fail']); z6 = [c for c in z['checks'] if c['group'].endswith('окно 640×480')]
    z6c = '%d из %d' % (sum(c['ok'] for c in z6), len(z6))
    checks.append({'doc': 'ui7', 'what': 'zoom200: прогон пройден, окно 640×480 проверено', 'ok': z.get('status') == 'passed' and len(z6) > 0, 'text': [z.get('status'), z6c]})
    checks.append({'doc': 'Handoff3', 'what': 'zoom200: число проверок и окно 640×480 из прогона', 'ok': ('zoom200.mjs , %s; окно 640×480 — %s' % (zc, z6c)) in P3, 'text': 'zoom200.mjs , %s; окно 640×480 — %s' % (zc, z6c)})
    for n in ('Handoff1', 'Handoff2'):
        src[n] = open('project/%s.dc.html' % n, encoding='utf-8').read()
        need(n, 'не ниже %s в тёмной и %s в светлой теме' % (N['dark'], N['light']), n + ': контраст нативных элементов из native.mjs')
repo = opt('--repo'); repo_info = None
if repo:
    git = lambda *a: subprocess.run(['git', '-C', repo] + list(a), capture_output=True, text=True).stdout.strip()
    spec_last = git('log', '-1', '--format=%h', '--abbrev=7', '--', 'docs/SPEC.md'); head = git('rev-parse', '--short=7', 'HEAD')
    repo_info = {'spec_last': spec_last, 'head': head, 'basis_head': B['repo']['head']}
    checks.append({'doc': 'repo', 'what': 'последнее изменение docs/SPEC.md = basis.json', 'ok': spec_last == B['spec']['commit'], 'text': spec_last})
    rf = lambda p: open(os.path.join(repo, p), encoding='utf-8').read() if os.path.exists(os.path.join(repo, p)) else ''
    checks.append({'doc': 'repo', 'what': 'UI сессий нет: окно приложения — заглушка', 'ok': 'Пока нет активных сессий' in rf('src/renderer/App.tsx'), 'text': 'src/renderer/App.tsx'})
    checks.append({'doc': 'repo', 'what': 'контрактный срез P1: практический профиль доступа есть', 'ok': 'PracticalLocalReadProfile' in rf('src/core/ports/agent.ts'), 'text': 'src/core/ports/agent.ts'})
    checks.append({'doc': 'repo', 'what': 'P2a: итог завершения в порте ProcessRunner', 'ok': 'completion' in rf('src/core/ports/process-runner.ts'), 'text': 'src/core/ports/process-runner.ts'})
    srcs = subprocess.run(['git', '-C', repo, 'grep', '-il', '-e', 'codex', '-e', 'swarm', '-e', 'better-sqlite3', '--', 'src'], capture_output=True, text=True).stdout.split()
    checks.append({'doc': 'repo', 'what': 'Codex, Swarm и SQLite в src отсутствуют', 'ok': not srcs, 'text': srcs})
    tok = rf('src/renderer/styles/tokens.css'); des = rf('docs/DESIGN.md')
    root = blk(tok, ':root'); dm = re.search(r'@media \(prefers-color-scheme: dark\)\s*\{\s*:root\s*\{([^}]*)\}', tok); dark = dm.group(1) if dm else ''
    for name, vals in D['tokens'].items():
        got = {'dark': tokv(dark, name), 'light': tokv(root, name)}
        checks.append({'doc': 'repo', 'what': 'tokens.css: %s = согласованному значению и макету' % name, 'ok': got == vals, 'text': got})
    for sct in D['sections']:
        checks.append({'doc': 'repo', 'what': 'DESIGN.md: раздел «%s»' % sct[3:], 'ok': ('\n' + sct + '\n') in des, 'text': sct})
    w = re.search(r'## Размер окна\n(.*?)(\n## |\Z)', des, re.S); wt = w.group(1) if w else ''
    checks.append({'doc': 'repo', 'what': 'DESIGN.md: минимум 640×480, окно 1280×960 при 200% — рекомендация, а не минимум', 'ok': 'minWidth: 640' in wt and 'minHeight: 480' in wt and '1280×960' in wt and 'рекомендация, а не минимум' in wt, 'text': wt[:160]})
    checks.append({'doc': 'repo', 'what': 'DESIGN.md: Return / Shift+Return с учётом IME', 'ok': 'Shift+Return' in des and 'IME' in des, 'text': 'Ввод сообщений'})
    import hashlib
    for fp, sha in D['files'].items():
        got = hashlib.sha256(open(os.path.join(repo, fp), 'rb').read()).hexdigest() if os.path.exists(os.path.join(repo, fp)) else ''
        checks.append({'doc': 'repo', 'what': '%s совпадает с basis.json (SHA-256)' % fp, 'ok': got == sha, 'text': got[:16]})
    repo_info['design_status'] = git('status', '--short', '--', 'docs/DESIGN.md', 'src/renderer/styles/tokens.css')
    if head != B['repo']['head']: repo_info['warning'] = 'репозиторий ушёл вперёд от basis.json (%s → %s): утверждения о коде проверены по текущему HEAD' % (B['repo']['head'], head)
bad = [c for c in checks if not c['ok']]
out = {'script': 'check_docs15.py', 'status': 'passed' if not bad else 'failed', 'checks': len(checks), 'failed': bad, 'scan': {'text': T, 'icon': I, 'border': Bo, 'platforms': sc['scanned']}, 'basis': B, 'repo': repo_info, 'runId': os.environ.get('RUN_ID', '')}
os.makedirs(rd, exist_ok=True); json.dump(out, open(os.path.join(rd, 'docs-check.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('Сверка листов с прогоном: %d проверок, не совпало %d' % (len(checks), len(bad)))
for c in bad: print('  НЕТ', c['doc'], c['what'], '→', c['text'])
sys.exit(1 if bad else 0)
