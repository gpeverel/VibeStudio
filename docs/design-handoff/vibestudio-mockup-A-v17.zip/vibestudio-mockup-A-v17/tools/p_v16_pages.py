# -*- coding: utf-8 -*-
# Правки страниц форм версии 16 (написаны заново). Применяются к файлам версии 15:
#   python3 -I tools/p_v16_pages.py project
# Находка проверки дерева доступности (tests/ui7/ax.mjs): у недоступной кнопки «Создать сессию» доступное описание
# ссылалось только на причину «запись недоступна»; причина «Чтобы создать сессию: …» (нет входа CLI, не дано согласие и т. п.)
# к кнопке не была привязана. Теперь обе причины связаны с кнопкой через aria-describedby.
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pt import Patch
d = sys.argv[1]
P = Patch(os.path.join(d, 'NewSession.dc.html'))
P.rep('<span class="med">Чтобы создать сессию:</span> <span class="muted">{{missing}}</span>', '<span class="med">Чтобы создать сессию:</span> <span class="muted" id="ns-why">{{missing}}</span>')
P.rep('id="ns-create" disabled="{{createOff}}" aria-describedby="ns-dbwhy"', 'id="ns-create" disabled="{{createOff}}" aria-describedby="ns-dbwhy ns-why"')
P.save()
