import sys, re
sys.path.insert(0, '..')
from pt import Patch
o = Patch('project/Ops.dc.html')

# шаблоны: подсказка поля с классом, вторая кнопка у правила
o.rep('''<div class="muted sm">{{b.hint}}</div></div>
          </sc-if>

          <sc-if value="{{b.isSelect}}">''', '''<div class="sm {{b.hcls}}" aria-live="polite">{{b.hint}}</div></div>
          </sc-if>

          <sc-if value="{{b.isSelect}}">''')
o.rep('''<sc-if value="{{r.hasAct}}"><div><button class="btn" id="{{r.actId}}" onClick="{{r.act}}">{{r.actLabel}}</button></div></sc-if>''',
      '''<sc-if value="{{r.hasAct}}"><div style="display:flex;gap:var(--space-2);flex-wrap:wrap"><button class="btn" id="{{r.actId}}" onClick="{{r.act}}">{{r.actLabel}}</button><sc-if value="{{r.hasAct2}}"><button class="btn" id="{{r.actId2}}" onClick="{{r.act2}}">{{r.actLabel2}}</button></sc-if></div></sc-if>''')
# существующие isArea без hcls: класс muted по умолчанию
o.s = o.s.replace("blocks.push({ isArea: true,", "blocks.push({ isArea: true, hcls: 'muted',")

NEW_RULES = r'''    if (kind === 'rules') {
      const pm = p.perm || 'none', stt = String(p.start || '');
      const RL0 = (p.rls && typeof p.rls === 'object') ? p.rls : {};
      const RL = { user: RL0.user !== undefined ? RL0.user : pm === 'user', denyPat: RL0.denyPat || 'npm run build', added: RL0.added || [] };
      const CALL = { tool: 'Bash', pat: 'npm run build' };
      const TERM = { turn: ['Эта сессия, участник «Тесты»', 'До конца следующего хода'], session: ['Эта сессия', 'До конца сессии'], project: ['Весь проект', 'Постоянное, пока вы его не измените'] };
      const eff = (R) => {
        if (pm === 'policy') return { v: 'deny', t: 'внешняя политика, deny Bash(npm run build)' };
        if (R.user && R.denyPat === CALL.pat) return { v: 'deny', t: 'ваш запрет проекта, deny Bash(' + R.denyPat + ')' };
        const d = R.added.find(x => x.type === 'deny' && x.tool === CALL.tool && x.pat === CALL.pat);
        if (d) return { v: 'deny', t: 'ваш запрет (' + TERM[d.term][1].toLowerCase() + '), deny Bash(' + d.pat + ')' };
        const a = R.added.find(x => x.type === 'allow' && x.tool === CALL.tool && x.pat === CALL.pat);
        if (a) return { v: 'allow', t: 'allow Bash(' + a.pat + '), ' + TERM[a.term][1].toLowerCase() };
        return { v: 'none', t: '' };
      };
      const effTxt = (e) => e.v === 'allow' ? 'Вызов разрешён: ' + e.t + '.' : e.v === 'none' ? 'Вызов не разрешён: разрешающего правила нет, запрещающего тоже.' : 'Вызов запрещён: ' + e.t + '.';
      const mode = s.rlm ?? ({ new: 'form', newdeny: 'form', shadow: 'form', edit: 'form', del: 'del', changed: 'res', changedallow: 'res' }[stt] || 'list');
      const f = s.rf ?? (stt === 'edit' ? { type: 'deny', tool: 'Bash', pat: RL.denyPat, term: 'project', edit: 'user' } : stt === 'newdeny' ? { type: 'deny', tool: 'Bash', pat: 'npm run build', term: 'project' } : { type: 'allow', tool: 'Bash', pat: 'npm run build', term: 'turn' });
      const setF = (patch) => this.setState({ rf: Object.assign({}, f, patch) });
      const tgt = s.rtgt ?? (stt === 'del' ? 'user' : '');
      const mkRL = () => {
        if (f.edit === 'user') return Object.assign({}, RL, { denyPat: f.pat.trim() });
        if (f.edit) return Object.assign({}, RL, { added: RL.added.map(x => x.id === f.edit ? Object.assign({}, x, { tool: f.tool, pat: f.pat.trim(), term: f.term }) : x) });
        return Object.assign({}, RL, { added: RL.added.concat([{ id: 'r' + (RL.added.length + 1), type: f.type, tool: f.tool, pat: f.pat.trim(), term: f.term }]) });
      };
      const delRL = (id) => id === 'user' ? Object.assign({}, RL, { user: false }) : Object.assign({}, RL, { added: RL.added.filter(x => x.id !== id) });
      const commit = (next, what) => { const before = eff(RL), after = eff(next); this.setState({ rchg: { before, after, what }, rlm: 'res', rf: undefined, rtgt: undefined, rack: false }); if (p.onRules) p.onRules(next, after.v); };
      const chg = s.rchg ?? (stt === 'changed' ? { before: eff(Object.assign({}, RL, { user: true })), after: eff(RL), what: 'Запрет удалён' } : stt === 'changedallow' ? { before: eff(Object.assign({}, RL, { added: RL.added.filter(x => x.id !== 'r1') })), after: eff(RL), what: 'Разрешение сохранено' } : null);
      const cols = (a, b) => ({ isCols: true, grid: p.compact ? '1fr' : '1fr 1fr', cols: [{ h: 'Было', text: effTxt(a) }, { h: 'Стало', text: b ? effTxt(b) : 'Появится после исправления шаблона.' }] });
      const termRad = (type) => [
        { v: 'turn', label: 'На следующий ход', sub: (type === 'allow' ? 'По умолчанию. ' : '') + 'Область: эта сессия, участник «Тесты». Действует до конца следующего хода.' },
        { v: 'session', label: 'На эту сессию', sub: 'Область: эта сессия. Действует до её конца.' },
        { v: 'project', label: 'Правило проекта', sub: 'Область: весь проект. Записывается в `.vibestudio/permissions.json` и действует во всех будущих сессиях.' }];

      if (mode === 'form') {
        const editing = !!f.edit, trimmed = f.pat.trim();
        title = editing ? 'Изменить собственное правило' : f.type === 'deny' ? 'Новый запрет' : 'Новое разрешение';
        sub = editing ? 'Правило задано вами: изменение вступает в силу после сохранения.' : 'Правило создаёте вы. Запрет приоритетнее разрешения; внешняя политика не меняется.';
        let err = '';
        if (!trimmed) err = 'Укажите шаблон вызова.';
        else if (SHELL.test(trimmed)) err = 'Шаблон описывает один вызов без shell: уберите `&&`, `|`, `;`, подстановки и перенаправления.';
        else if (f.type === 'allow' && (trimmed === '*' || trimmed === '**')) err = 'Слишком широкое разрешение. Укажите конкретную команду или путь.';
        const next = err ? null : mkRL();
        if (!editing) blocks.push({ isRadio: true, name: 'rtype', title: 'Тип правила', opts: [
          { label: 'Разрешение (allow)', sub: 'Разрешает вызов. Запрет приоритетнее и разрешением не снимается.', on: f.type === 'allow', pick: () => setF({ type: 'allow', term: 'turn', ack: false }) },
          { label: 'Запрет (deny)', sub: 'Запрещает вызов. Действует первым; снимается только явным изменением этого правила.', on: f.type === 'deny', pick: () => setF({ type: 'deny', term: 'project', ack: false }) }] });
        blocks.push({ isSelect: true, id: 'dlg-rtool', label: 'Инструмент', value: f.tool, opts: ['Bash', 'Read', 'Edit', 'Write'].map(v => ({ v, t: v })), change: (e) => setF({ tool: e.currentTarget.value }) });
        blocks.push({ isArea: true, id: 'dlg-rpat', hcls: err ? 'bad' : 'muted', label: 'Шаблон вызова', ph: 'npm run build', value: f.pat, rows: 1, hint: err ? 'Ошибка: ' + err : 'Один вызов без shell. Пример: npm run build.', input: (e) => setF({ pat: e.currentTarget.value }) });
        blocks.push({ isRadio: true, name: 'rterm', title: 'Срок и область', opts: termRad(f.type).map(x => ({ label: x.label, sub: x.sub, on: f.term === x.v, pick: () => setF({ term: x.v, ack: false }) })) });
        if (f.term === 'project') blocks.push(CK('dlg-rack', 'Подтверждаю постоянное правило проекта', 'Оно действует во всех будущих сессиях, пока вы его не измените.', !!f.ack, (e) => setF({ ack: e.currentTarget.checked })));
        const cur = eff(RL), aft = next ? eff(next) : null;
        blocks.push(cols(cur, aft));
        if (aft && aft.v === 'deny' && f.type === 'allow' && !editing) blocks.push(AL('warn', 'Разрешение не вступит в силу', 'Запрет приоритетнее: пока он действует, это разрешение не применяется. Чтобы разрешить вызов, сначала измените или удалите запрет.'));
        blocks.push(P('Новое правило не повторяет уже выполненные действия и не запускает отказавший вызов заново. Продолжение — новый ход, который запускаете вы.', 'muted sm'));
        B('dlg-rcancel', 'Отмена', '', false, () => this.setState({ rlm: 'list', rf: undefined }));
        B('dlg-rsave', editing ? 'Сохранить изменение' : f.type === 'deny' ? 'Сохранить запрет' : 'Сохранить разрешение', 'btn-primary', !!err || (f.term === 'project' && !f.ack), () => commit(next, editing ? 'Запрет изменён' : f.type === 'deny' ? 'Запрет создан' : 'Разрешение сохранено'));
        foot = err ? 'Исправьте шаблон вызова.' : f.term === 'project' && !f.ack ? 'Подтвердите постоянное правило проекта.' : 'Внешнюю политику это правило не меняет.';
      } else if (mode === 'del') {
        const id = tgt || 'user', x = id === 'user' ? { type: 'deny', tool: 'Bash', pat: RL.denyPat, term: 'project' } : (RL.added.find(a => a.id === id) || { type: 'allow', tool: 'Bash', pat: CALL.pat, term: 'turn' });
        const next = delRL(id), ack = !!s.rack;
        title = x.type === 'deny' ? 'Удалить собственный запрет' : 'Удалить разрешение'; sub = x.type === 'deny' ? 'Запрет задан вами: он удаляется только явно.' : 'Разрешение перестанет действовать сразу после удаления.';
        blocks.push(KV([['Правило', '`' + x.type + ' ' + x.tool + '(' + x.pat + ')`'], ['Область', TERM[x.term][0]], ['Срок', TERM[x.term][1]]]));
        blocks.push(cols(eff(RL), eff(next)));
        blocks.push(CK('dlg-rack', x.type === 'deny' ? 'Понимаю: запрет перестанет действовать, а ранее выполненные действия не повторяются' : 'Понимаю: разрешение перестанет действовать', '', ack, (e) => this.setState({ rack: e.currentTarget.checked })));
        blocks.push(P('Удаление не запускает отказавший вызов заново. Продолжение — новый ход, который запускаете вы.', 'muted sm'));
        B('dlg-rcancel', 'Отмена', '', false, () => this.setState({ rlm: 'list', rtgt: undefined, rack: false }));
        B('dlg-rdel', x.type === 'deny' ? 'Удалить запрет' : 'Удалить разрешение', 'btn-danger', !ack, () => commit(next, x.type === 'deny' ? 'Запрет удалён' : 'Разрешение удалено'));
        foot = ack ? 'Внешнюю политику это не затрагивает.' : 'Подтвердите удаление.';
      } else if (mode === 'res' && chg) {
        title = chg.what; sub = 'Правило сохранено. Ниже показано, как изменилось действующее правило для вызова `Bash(npm run build)`.';
        blocks.push(AL('ok', chg.what, 'Изменение записано. Ранее выполненные действия не повторялись, отказавший вызов заново не запускался.'));
        blocks.push(cols(chg.before, chg.after));
        if (chg.after.v === 'deny' && chg.what.startsWith('Разрешение')) blocks.push(AL('warn', 'Разрешение не вступило в силу', 'Запрет приоритетнее: вызов по-прежнему запрещён. Разрешение записано, но применяться будет только после снятия запрета.'));
        if (chg.after.v === 'allow') blocks.push(P('Следующий ход сможет вызвать `Bash(npm run build)`. Участник сам не продолжит: ход запускаете вы.', 'muted sm'));
        B('dlg-close', 'Вернуться к сессии', '', false, closeIt);
        B('dlg-rall', 'Ко всем правилам', 'btn-primary', false, () => this.setState({ rlm: 'list' }));
        foot = 'Внешняя политика остаётся только для просмотра.';
      } else {
        title = 'Правила проекта'; sub = 'Действующие правила для вызовов инструментов. Запрет приоритетнее разрешения: добавление allow его не снимает.';
        const R = (id, rule, verdict, src, scope, term, extra) => Object.assign({ id, rule, verdict, vcls: verdict === 'Запрет' ? 'warn' : 'ok', vic: verdict === 'Запрет' ? 'ic-lock' : 'ic-ok', src, scope, term, border: 'var(--color-border)', cause: false, note: '', hasAct: false, hasAct2: false }, extra || {});
        const cur = eff(RL), userHit = RL.user && RL.denyPat === CALL.pat && pm !== 'policy';
        const own = (idDel, idEdit, openEdit, openDel) => ({ hasAct: true, actId: idEdit, actLabel: 'Изменить…', act: openEdit, hasAct2: true, actId2: idDel, actLabel2: 'Удалить…', act2: openDel });
        const deny = [];
        if (RL.user) deny.push(R('rl-user', 'deny Bash(' + RL.denyPat + ')', 'Запрет', 'Правило проекта · .vibestudio/permissions.json · строка 4 · ваше', TERM.project[0], TERM.project[1], Object.assign({ cause: userHit, border: userHit ? 'var(--color-danger)' : 'var(--color-border)' }, own('rl-del', 'rl-edit', () => this.setState({ rlm: 'form', rf: { type: 'deny', tool: 'Bash', pat: RL.denyPat, term: 'project', edit: 'user' } }), () => this.setState({ rlm: 'del', rtgt: 'user', rack: false })))));
        RL.added.filter(x => x.type === 'deny').forEach(x => deny.push(R('rl-' + x.id, 'deny ' + x.tool + '(' + x.pat + ')', 'Запрет', x.term === 'project' ? 'Правило проекта · .vibestudio/permissions.json · ваше' : 'Запрет сессии · ваш', TERM[x.term][0], TERM[x.term][1], Object.assign({ cause: eff(RL).v === 'deny' && x.pat === CALL.pat && !userHit && pm !== 'policy' }, own('rl-del-' + x.id, 'rl-edit-' + x.id, () => this.setState({ rlm: 'form', rf: { type: 'deny', tool: x.tool, pat: x.pat, term: x.term, edit: x.id, ack: false } }), () => this.setState({ rlm: 'del', rtgt: x.id, rack: false }))))));
        if (pm === 'policy') deny.push(R('rl-policy-hit', 'deny Bash(npm run build)', 'Запрет', 'Внешняя политика · managed-настройка организации', 'Все проекты на этом компьютере', 'Задаётся администратором', { cause: true, border: 'var(--color-danger)', note: 'Только просмотр: приложение не меняет и не обходит внешнюю политику.' }));
        deny.push(R('rl-policy', 'deny Bash(rm -rf *)', 'Запрет', 'Внешняя политика · managed-настройка организации', 'Все проекты на этом компьютере', 'Задаётся администратором', { note: 'Только просмотр: приложение не меняет и не обходит внешнюю политику.' }));
        const shadow = (x) => cur.v === 'deny' && x.pat === CALL.pat ? 'Перекрыто запретом: пока он действует, это разрешение не применяется.' : '';
        const addRow = (x) => R('rl-' + x.id, 'allow ' + x.tool + '(' + x.pat + ')', 'Разрешение', x.term === 'project' ? 'Правило проекта · .vibestudio/permissions.json · ваше' : 'Разрешение сессии · ваше', TERM[x.term][0], TERM[x.term][1], Object.assign({ note: shadow(x) }, own('rl-del-' + x.id, 'rl-edit-' + x.id, () => this.setState({ rlm: 'form', rf: { type: 'allow', tool: x.tool, pat: x.pat, term: x.term, edit: x.id, ack: false } }), () => this.setState({ rlm: 'del', rtgt: x.id, rack: false }))));
        const allow = [
          R('rl-a1', 'allow Bash(npm test)', 'Разрешение', 'Правило проекта · .vibestudio/permissions.json · строка 2 · ваше', 'Весь проект', 'Постоянное'),
          R('rl-a2', 'allow Read(**)', 'Разрешение', 'Профиль режима «Агент» · задаётся приложением', 'Рабочая копия сессии', 'Пока выбран этот режим'),
          R('rl-a3', 'allow Edit(src/**, tests/**, docs/**)', 'Разрешение', 'Профиль режима «Агент» · задаётся приложением', 'Рабочая копия сессии', 'Пока выбран этот режим')].concat(RL.added.filter(x => x.type === 'allow' && x.term === 'project').map(addRow));
        const once = RL.added.filter(x => x.type === 'allow' && x.term !== 'project').map(addRow);
        blocks.push(policyHit ? 0 : 0);
        blocks.pop();
        blocks.push(pm === 'policy' ? AL('err', 'Отказ вызван внешней политикой', 'Вызов `Bash(npm run build)` запрещён политикой организации, она выделена ниже. Приложение её не обходит и не обещает обойти.')
          : cur.v === 'deny' ? AL('warn', userHit ? 'Вызов запрещён вашим правилом' : 'Вызов запрещён вашим запретом', 'Вызов `Bash(npm run build)` запрещён правилом, оно выделено ниже. Запрет приоритетнее любого разрешения; его можно изменить или удалить явно.')
          : cur.v === 'allow' ? AL('ok', 'Вызов сейчас разрешён', 'Для `Bash(npm run build)` действует ' + cur.t + '. Отказавший ранее вызов заново не запускается: продолжение — новый ход.')
          : AL('info', 'Отказ вызван отсутствием разрешения', 'Ни одно действующее правило не разрешает `Bash(npm run build)`, и запрещающего правила тоже нет.'));
        blocks.push({ isRules: true, groups: [
          { title: 'Запреты (deny) · действуют первыми', rows: deny, empty: false, emptyText: '' },
          { title: 'Разрешения (allow)', rows: allow, empty: false, emptyText: '' },
          { title: 'Разрешения на ход и на сессию', rows: once, empty: once.length === 0, emptyText: 'Разовых расширений сейчас нет. По умолчанию разрешение действует на следующий ход.' }] });
        blocks.push(P('После изменения прав участник не повторяет только отказавший вызов: продолжение — новый ход, который запускаете вы. Уже выполненные действия не повторяются.', 'muted sm'));
        const quick = cur.v === 'none' && pm === 'none';
        B('dlg-close', 'Вернуться к сессии', '', false, closeIt);
        B('rl-new', 'Новое правило…', quick ? '' : 'btn-primary', false, () => this.setState({ rlm: 'form', rf: { type: 'allow', tool: 'Bash', pat: 'npm run build', term: 'turn' } }));
        if (quick) B('dlg-allow', 'Разрешить…', 'btn-primary', false, () => { if (p.onSwitch) p.onSwitch('perm', ''); });
        foot = cur.v === 'deny' && pm !== 'policy' ? 'Собственный запрет меняется только явным редактированием или удалением.' : pm === 'policy' ? 'Внешняя политика только просматривается.' : 'Новое разрешение по умолчанию действует на следующий ход.';
      }
    }
'''

s = o.s
a = s.index("    if (kind === 'rules') {")
b = s.index("\n    const compact = !!p.compact;\n    const wideKinds")
o.s = s[:a] + NEW_RULES + s[b:]
o.rep("const wideKinds = ['bypass', 'commit', 'reconcile', 'checks', 'conflict', 'restart', 'manual', 'rules'];", "const wideKinds = ['bypass', 'commit', 'reconcile', 'checks', 'conflict', 'restart', 'manual', 'rules', 'dberr', 'orphan'];")
o.rep("((kind === 'reconcile' || kind === 'restart' || kind === 'manual') ? 760 : 680)", "((kind === 'reconcile' || kind === 'restart' || kind === 'manual' || kind === 'dberr' || kind === 'orphan') ? 760 : 680)")
o.save()
