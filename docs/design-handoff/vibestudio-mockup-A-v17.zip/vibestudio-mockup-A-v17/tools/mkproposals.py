# -*- coding: utf-8 -*-
# Версия 16 (написан заново). Точные предлагаемые изменения docs/DESIGN.md и src/renderer/styles/tokens.css — для просмотра.
# Репозиторий только читается; патчи пишутся в proposals/ комплекта. Каждый патч проверяется на временной копии файлов
# (git apply): накладывается на текущие файлы отдельно; all.patch — все предложения вместе.
#   python3 -I tools/mkproposals.py <путь к репозиторию VibeStudio> [каталог_вывода=proposals]
import difflib, json, os, shutil, subprocess, sys, tempfile
repo = sys.argv[1]; out = sys.argv[2] if len(sys.argv) > 2 else 'proposals'
TOK, DES = 'src/renderer/styles/tokens.css', 'docs/DESIGN.md'
orig = {p: open(os.path.join(repo, p), encoding='utf-8').read() for p in (TOK, DES)}

def rep(s, a, b):
    if s.count(a) != 1: raise SystemExit('фрагмент не найден однозначно: ' + a)
    return s.replace(a, b)
def append(s, text): return s.rstrip('\n') + '\n' + text

PRINC_END = '- Видимый фокус клавиатуры: контур `--color-focus-ring`; основные действия доступны без мыши.\n'

def t0(d):  # тексты ранее принятых решений 15 и 18
    d = dict(d)
    d[DES] = append(d[DES], '''
## Ввод сообщений

Return отправляет сообщение, Shift+Return переносит строку; во время ввода через IME Return не отправляет. Подсказка видна рядом с полем. Высота поля растёт по содержимому до предела, затем появляется прокрутка внутри поля.

## Размер окна

Минимальный размер окна задан в `src/main/index.ts`: `minWidth: 640`, `minHeight: 480`. Это размер окна целиком, а не области содержимого: у стандартной рамки macOS область содержимого ниже на высоту заголовка (около 28 px, зависит от системы). Ширина меньше 800 px: панели открываются поверх, по одной.
''')
    return d

def t1(d):  # решение 1
    d = dict(d)
    d[TOK] = rep(d[TOK], '  --color-border: #e2e2de;\n', '  --color-border: #e2e2de;\n  --color-border-strong: #858580; /* граница полей ввода; не для текста, значков и заливок */\n')
    d[TOK] = rep(d[TOK], '    --color-border: #33332f;\n', '    --color-border: #33332f;\n    --color-border-strong: #6f6f69;\n')
    d[DES] = rep(d[DES], PRINC_END, PRINC_END + '''- Неподтверждённое не выглядит успехом: «неизвестно», «не подтверждено», «устарело», «не проверено» показываются нейтральным или предупреждающим значком с подписью, не зелёным.
- Размер текста: пояснения, причины недоступности действий и сообщения об ошибках не меньше `--font-size-sm` (12 px). `--font-size-xs` (11 px) только для коротких метаданных: время, счётчики, номера строк, ветка рядом с проектом. Важный текст переносится, а не уменьшается.
- Недоступное действие не исчезает молча: рядом текстом указана причина, граница кнопки пунктирная.

## Поля ввода

Границы input, select, textarea, поля сообщения и сегментного переключателя используют `--color-border-strong`: контраст не ниже 3:1 с `--color-bg`, `--color-surface` и `--color-surface-sunken` в обеих темах. Остальные разделители, карточки и кнопки сохраняют `--color-border`. Фокус — контур `--color-focus-ring` со смещением 2 px, граница не меняется. Недоступное поле — пунктир `--color-border`. Токен не используется как цвет текста, значка, заливки или фокуса. Нативные флажки и переключатели рисует система (`accent-color`, `color-scheme`).
''')
    d[DES] = rep(d[DES], '`--color-border`, `--color-text`', '`--color-border`, `--color-border-strong`, `--color-text`')
    return d

def t2(d):  # решение 2
    d = dict(d)
    d[TOK] = rep(d[TOK], '  --color-focus-ring: #2f5fd0;\n', '  --color-focus-ring: #2f5fd0;\n  --color-scrim: rgba(250, 250, 249, 0.72); /* затемнение за модальным окном: --color-bg при прозрачности 0,72 */\n')
    d[TOK] = rep(d[TOK], '    --color-focus-ring: #7ca0f2;\n', '    --color-focus-ring: #7ca0f2;\n    --color-scrim: rgba(21, 21, 20, 0.72);\n')
    d[DES] = rep(d[DES], '`--color-focus-ring`, `--color-success`', '`--color-focus-ring`, `--color-scrim`, `--color-success`')
    d[DES] = rep(d[DES], '- Статус всегда передаётся текстом', '- Изменения в diff передаются полосой слева (`--color-success` / `--color-danger`) и знаком «+» / «−»; фон изменённой строки — `--color-surface-sunken`, отдельных цветов фона нет.\n- Статус всегда передаётся текстом')
    return d

def t9(d):  # решение 9
    d = dict(d)
    d[DES] = append(d[DES], '''
## Окна и панели поверх

Модальное окно и панель, открытая поверх, имеют `role="dialog"`, `aria-modal="true"` и заголовок через `aria-labelledby`. Фон за ними недоступен (`inert`); объявления для экранного диктора делаются из области вне `inert`. Tab не покидает окно, Escape закрывает его, если не выполняется операция, фокус возвращается на элемент, который его открыл. Явная кнопка «Закрыть» обязательна: нельзя полагаться только на Escape. Если фокусируемый элемент внутри окна исчезает или блокируется, фокус остаётся внутри окна.

## Опасные действия

«Отбросить» и «Применить без проверок» оформляются контуром и текстом `--color-danger`, подтверждаются отдельным шагом и показывают последствия до подтверждения. Акцентная основная кнопка для разрушающих действий не используется.

## Значки состояния

Статус всегда состоит из значка и подписи. Значки берутся из одного спрайта, цвет — `--color-success`, `--color-warning`, `--color-danger`, `--color-accent` или `--color-text-muted`; контраст значка не ниже 3:1. Неподтверждённый или устаревший результат — пунктирный круг, а не зелёная отметка.
''')
    return d

T = [('d0-accepted-texts', 'Тексты ранее принятых решений 15 и 18 (Return / Shift+Return, размер окна)', t0),
     ('d1-border-strong', 'Решение 1: граница полей ввода и размер вторичного текста', t1),
     ('d2-scrim', 'Решение 2: затемнение под окнами и фон строк diff', t2),
     ('d9-design-sections', 'Решение 9: окна, опасные действия и значки состояния в DESIGN.md', t9)]

def udiff(a, b, p): return ''.join(difflib.unified_diff(a.splitlines(True), b.splitlines(True), 'a/' + p, 'b/' + p))
def check(pf):
    tmp = tempfile.mkdtemp(prefix='vs-prop-')
    try:
        for p in (TOK, DES):
            os.makedirs(os.path.dirname(os.path.join(tmp, p)), exist_ok=True)
            open(os.path.join(tmp, p), 'w', encoding='utf-8').write(orig[p])
        subprocess.run(['git', 'init', '-q'], cwd=tmp, check=True)
        r = subprocess.run(['git', 'apply', '--check', os.path.abspath(pf)], cwd=tmp, capture_output=True, text=True)
        return r.stderr.strip() if r.returncode else ''
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

os.makedirs(out, exist_ok=True)
index, acc = [], dict(orig)
for key, title, fn in T:
    d = fn(orig); acc = fn(acc)
    pf = os.path.join(out, key + '.patch')
    open(pf, 'w', encoding='utf-8').write(''.join(udiff(orig[p], d[p], p) for p in (TOK, DES) if d[p] != orig[p]))
    err = check(pf)
    index.append({'patch': key + '.patch', 'title': title, 'files': [p for p in (TOK, DES) if d[p] != orig[p]], 'applies': not err, 'error': err})
allp = os.path.join(out, 'all.patch')
open(allp, 'w', encoding='utf-8').write(''.join(udiff(orig[p], acc[p], p) for p in (TOK, DES)))
err = check(allp)
index.append({'patch': 'all.patch', 'title': 'Все предложения вместе (d0, d1, d2, d9)', 'files': [TOK, DES], 'applies': not err, 'error': err})
base = {p: subprocess.run(['git', '-C', repo, 'log', '-1', '--format=%h', '--', p], capture_output=True, text=True).stdout.strip() for p in (TOK, DES)}
json.dump({'about': 'Предложения для просмотра; в репозиторий не внесены. Каждый патч накладывается на файлы репозитория на коммитах base (git apply --check на временной копии).', 'base': base, 'patches': index},
          open(os.path.join(out, 'index.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
bad = [i for i in index if not i['applies']]
print('патчей', len(index), 'не накладывается', len(bad), 'основа', base)
for i in bad: print('  НЕТ', i['patch'], i['error'])
sys.exit(1 if bad else 0)
