# -*- coding: utf-8 -*-
# Версия 16 (написан заново): создаёт tools/gen_handoff7.py из tools/gen_handoff6.py.
#   python3 -I tools/p_gen7.py   (из каталога сборки)
# Изменения: основание SPEC и состояние кода на листе 1 — из tools/basis.json; лист 3 — матрица и данные tools/checks7.json
# (результаты tests/ui7, замечания ревью Version 17, изменения версии 16); новый лист 4 «Решения и границы этапа».
import os, sys, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pt import Patch
shutil.copy('tools/gen_handoff6.py', 'tools/gen_handoff7.py')
P = Patch('tools/gen_handoff7.py')
P.rep("# Версия 15 (создан p_gen6.py из gen_handoff5.py версии 14; номера строк SPEC пересчитаны по коммиту 07776e2).",
      "# Версия 16 (создан p_gen7.py из gen_handoff6.py): основание и состояние кода — tools/basis.json; лист 3 — tools/checks7.json; новый лист 4 (решения и границы этапа).\n# Версия 15 (создан p_gen6.py из gen_handoff5.py версии 14; номера строк SPEC пересчитаны по коммиту 07776e2).")
P.rep("import json, re, html\n", "import json, re, html\nBASIS = json.load(open('tools/basis.json', encoding='utf-8'))\nCODE_STATE = 'UI сессий в коде нет (репозиторий на %s, %s): готовы %s' % (BASIS['repo']['head'], BASIS['repo']['date_ru'], BASIS['code']['ready_contract'])\n")
# лист 1: основание и состояние кода
P.rep("на коммите 07776e2 (15.10.2026): после версии 14 файл изменился, ссылки пересчитаны.",
      "на коммите ' + BASIS['spec']['commit'] + ' (' + BASIS['spec']['date_ru'] + '), последнем изменении файла в Git на дату сверки: после версии 14 файл изменился, ссылки пересчитаны.")
P.rep("По SPEC §0 UI сессий в коде ещё нет, поэтому ни одна функция не считается готовой.",
      "' + e(CODE_STATE) + '. Поэтому ни одна функция макета не считается готовой.")
P.rep("Макет показывает их, приложение пока нет (SPEC §0). «Отражено» не значит «реализовано».",
      "Макет показывает их, приложение пока нет: UI сессий в коде нет (состояние кода — лист «Основания в SPEC»). «Отражено» не значит «реализовано».")
P.rep(" ('Меню macOS', 'Не нарисовано', 'Стандартные пункты (копировать, вставить, закрыть окно, свернуть, выйти) работают штатно. Перечень пунктов SPEC не задаёт: §8 говорит о клавиатуре и меню без перечня', 'Не проверено в артефакте: меню нет'),",
      " ('Меню macOS', 'Не нарисовано', 'Стандартные меню macOS; пункты повторяют действия окна и недоступны тогда же, когда кнопки. Перечень пунктов SPEC не задаёт: §8 говорит о клавиатуре и меню без перечня. Ожидаемое поведение и критерий приёмки — лист 4', 'Не проверено в артефакте: меню нет'),")
P.rep(" ('Уведомления и настройки приложения', 'Не нарисованы', 'Решается при интеграции; SPEC их не описывает', 'Не проверено: нет в макете'),",
      " ('Уведомления и настройки приложения', 'Не нарисованы', 'Отложены в задачи приложения; ожидаемое поведение и критерий приёмки — лист 4. Системные уведомления SPEC не требует', 'Не проверено: нет в макете'),")
# лист 3
P.rep("CHECKS = json.load(open('tools/checks6.json', encoding='utf-8'))", "CHECKS = json.load(open('tools/checks7.json', encoding='utf-8'))")
P.rep(" sec('Замечания независимого ревью версии 14 и их закрытие', review_html(),",
      " sec('Замечания независимого ревью Version 17 и их закрытие', review17_html(), 'Версия 16 исправляет документацию и закрывает оставшиеся проверки интерфейса; Version 17 сохранена как опубликованная история артефакта, версия 15 — неизменным пакетом в комплекте.'),\n sec('Изменения версии 16', bullets(CHECKS['changes16'])),\n sec('Замечания независимого ревью версии 14 и их закрытие', review_html(),")
P.rep("def kit_html():", '''def review17_html():
    h = '<thead><tr><th scope="col" style="width:200px">Замечание</th><th scope="col" style="width:360px">Что исправлено</th><th scope="col" style="width:300px">Как проверено</th><th scope="col" style="width:240px">Доказательство</th><th scope="col">Остаточные ограничения</th></tr></thead>'
    b = ''.join('<tr><td class="med">%s</td><td>%s</td><td>%s</td><td class="muted">%s</td><td class="muted">%s</td></tr>' % tuple(md(c) for c in r) for r in CHECKS['review17'])
    return '<table style="width:100%%;border-collapse:collapse;margin-top:var(--space-2)" class="sm"><caption class="sr">Замечания ревью Version 17</caption>%s<tbody>%s</tbody></table>' % (h, b)
def kit_html():''')
P.rep(" sec('Решения для окончательной приёмки (предложения)', olist(CHECKS['decisions']), 'Десять решений остаются предложениями: заданием версии 15 они не утверждаются. Обязательные требования SPEC отделены от предлагаемых способов их показа (лист 1, раздел «Требования, решения интерфейса, имитация и непроверенное»). Готовность макета не означает готовность реализации приложения.'),",
      " sec('Решения для окончательной приёмки (предложения)', bullets(CHECKS['decisions']), 'Ни одно решение не утверждено. Обязательные требования SPEC отделены от предлагаемых способов их показа. Готовность макета не означает готовность реализации приложения.'),")
P.rep("'Пакет передачи 3: визуальные материалы, проверки и решения (версия 15)'", "'Пакет передачи 3: визуальные материалы, проверки и решения (версия 16)'")
# лист 4
P.rep("def build():", '''# =========================================================== HANDOFF 4
def decisions_html():
    h = '<thead><tr><th scope="col" style="width:40px">№</th><th scope="col" style="width:300px">Что предлагается</th><th scope="col" style="width:300px">Рекомендация и основание</th><th scope="col" style="width:280px">Альтернатива и последствия</th><th scope="col" style="width:240px">Обязательно по SPEC</th><th scope="col">Выбор интерфейса · изменения</th></tr></thead>'
    b = ''
    for d in CHECKS['decisions16']:
        b += '<tr><td class="med">%d</td><td><div class="med">%s</div><div style="margin-top:var(--space-1)">%s</div><div style="margin-top:var(--space-1)"><span class="tag warn">Ожидает согласования</span></div></td><td>%s</td><td>%s</td><td class="muted">%s</td><td>%s%s</td></tr>' % (
            d['n'], e(d['title']), md(d['proposal']), md(d['recommendation']), md(d['alternative']), md(d['spec']), md(d['ui']),
            ('<div class="muted" style="margin-top:var(--space-1)">Изменения: <span class="mono">%s</span></div>' % e(d['patch'])) if d['patch'] else '<div class="muted" style="margin-top:var(--space-1)">Изменений tokens.css и DESIGN.md не требует</div>')
    return '<table style="width:100%%;border-collapse:collapse;margin-top:var(--space-2)" class="sm"><caption class="sr">Решения к согласованию</caption>%s<tbody>%s</tbody></table>' % (h, b)
def extra_html():
    return ''.join('<div style="margin-top:var(--space-3)"><div class="med">%s</div><div class="sm" style="max-width:1100px">%s</div></div>' % (e(x['title']), md(x['text'])) for x in CHECKS['decisions16_extra'])
import os as _os
PROPS = json.load(open('proposals/index.json', encoding='utf-8')) if _os.path.exists('proposals/index.json') else None
def udiffcode(s):
    # перевод строки — внутри элемента каждой строки: пробельные узлы между элементами среда листа отбрасывает
    out = []
    for ln in s.rstrip('\\n').split('\\n'):
        cls = 'ok' if ln.startswith('+') and not ln.startswith('+++') else 'bad' if ln.startswith('-') and not ln.startswith('---') else ''
        out.append('<span%s>%s\\n</span>' % (' class="%s"' % cls if cls else '', e(ln)))
    return '<pre class="codeb">%s</pre>' % ''.join(out)
def proposals_html():
    if not PROPS: return '<div class="sm muted">Патчи не собраны (tools/mkproposals.py).</div>'
    out = '<div class="sm muted" style="max-width:1100px">Основа: <span class="mono">src/renderer/styles/tokens.css</span> и <span class="mono">docs/DESIGN.md</span> на коммите <span class="mono">%s</span>. Каждый патч накладывается на текущие файлы отдельно (проверено <span class="mono">git apply --check</span> на временной копии); <span class="mono">proposals/all.patch</span> — все вместе. В репозиторий ничего не внесено.</div>' % e(PROPS['base'].get('docs/DESIGN.md', ''))
    for p in PROPS['patches']:
        if p['patch'] == 'all.patch': continue
        txt = open('proposals/' + p['patch'], encoding='utf-8').read()
        out += '<div style="margin-top:var(--space-4)"><div class="med">%s <span class="muted mono sm">proposals/%s</span> %s</div>%s</div>' % (e(p['title']), e(p['patch']), '<span class="tag ok">накладывается</span>' if p['applies'] else '<span class="tag bad">не накладывается</span>', udiffcode(txt))
    return out
def boundaries_html():
    h = '<thead><tr><th scope="col" style="width:180px">Пробел</th><th scope="col" style="width:250px">Сейчас в макете</th><th scope="col" style="width:240px">Где решается</th><th scope="col" style="width:360px">Ожидаемое поведение</th><th scope="col">Критерий приёмки</th></tr></thead>'
    b = ''.join('<tr><td class="med">%s</td><td>%s</td><td>%s</td><td>%s</td><td class="muted">%s</td></tr>' % (md(x['gap']), md(x['now']), md(x['where']), md(x['expect']), md(x['accept'])) for x in CHECKS['boundaries'])
    return '<table style="width:100%%;border-collapse:collapse;margin-top:var(--space-2)" class="sm"><caption class="sr">Границы этапа дизайна</caption>%s<tbody>%s</tbody></table>' % (h, b)
def impl_html():
    I = CHECKS['impl']
    rows = [('Основание SPEC', '`docs/SPEC.md`, коммит %s (%s) — последнее изменение файла на %s' % (I['spec']['commit'], I['spec']['date_ru'], I['checked'])),
            ('Репозиторий', 'HEAD %s (%s); план — коммит %s' % (I['repo']['head'], I['repo']['date_ru'], I['repo']['plan_commit'])),
            ('Готово', I['code']['ready_contract']), ('Нет', I['code']['absent']), ('Источники', I['code']['evidence'])]
    return table('Состояние реализации', ['Что', 'Значение'], rows, ['220px', ''])
SEC4 = [
 sec('Решения, ожидающие согласования', decisions_html(), 'Десять решений из пакета передачи. Ни одно не утверждено: рекомендация — мнение исполнителя, решение за приёмкой. Колонка «Обязательно по SPEC» — что требует спецификация независимо от решения; «Выбор интерфейса» — что согласуется.'),
 sec('Дополнительно к решениям', extra_html()),
 sec('Точные предлагаемые изменения tokens.css и DESIGN.md', proposals_html(), 'Для просмотра. Переносятся в репозиторий только после согласования соответствующего решения.'),
 sec('Границы этапа дизайна', boundaries_html(), 'Признанные пробелы: что остаётся в этапе макета и что относится к будущим задачам приложения. Проверка браузерного макета на macOS не является приёмкой нативного поведения Electron-приложения.'),
 sec('Состояние реализации, на которое опираются листы', impl_html(), 'Готовность макета и готовность приложения оцениваются отдельно: этот лист не объявляет функции приложения готовыми.'),
]

def build():''')
P.rep("    open('project/Handoff3.dc.html', 'w', encoding='utf-8').write(page('ho3',",
      "    open('project/Handoff4.dc.html', 'w', encoding='utf-8').write(page('ho4', 'Пакет передачи 4: решения к согласованию и границы этапа (версия 16)', 'Десять решений с рекомендацией и альтернативой, точные предлагаемые изменения контракта и что остаётся будущим задачам приложения.', SEC4, 6000))\n    open('project/Handoff3.dc.html', 'w', encoding='utf-8').write(page('ho3',")
P.save()
