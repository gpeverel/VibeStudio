# -*- coding: utf-8 -*-
# Версия 17 (написан заново): создаёт tools/gen_handoff8.py из tools/gen_handoff7.py.
#   python3 -I tools/p_gen8.py   (из каталога сборки)
# Изменения: согласование 27.10.2026 (tools/basis.json → design): статусы решений и предложений на листах 1–4 заменены
# фактическими; лист 2 — что внесено в tokens.css и DESIGN.md вместо текстов предложений; лист 3 — tools/checks8.json,
# согласование и изменения версии 17, ручной сценарий VoiceOver «перенесено на приёмку приложения»; лист 4 — внесённый
# diff, ограничения опубликованной площадки и отдельный список проверок приложения. Устаревшие строки версии 16
# («Масштаб 200% и VoiceOver — не проверены», «контраст нативных флажков не измерялся») исправлены.
import os, sys, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pt import Patch
shutil.copy('tools/gen_handoff7.py', 'tools/gen_handoff8.py')
P = Patch('tools/gen_handoff8.py')
def between(start, end, new):
    i = P.s.index(start); j = P.s.index(end, i)
    if P.s.count(start) != 1: raise SystemExit('FAIL: начало не единственное: ' + start[:60])
    P.s = P.s[:i] + new + P.s[j:]; P.n += 1
P.rep("# Версия 16 (создан p_gen7.py из gen_handoff6.py)",
      "# Версия 17 (создан p_gen8.py из gen_handoff7.py): согласование 27.10.2026 — статусы решений, внесённый diff, лист 3 — tools/checks8.json, лист 4 — проверки приложения.\n# Версия 16 (создан p_gen7.py из gen_handoff6.py)")
P.rep("CODE_STATE = 'UI сессий в коде нет", "AG = BASIS['design']['agreed_ru']\nCODE_STATE = 'UI сессий в коде нет")
# --- лист 1
P.rep("но не способа показа. Предложение (не утверждено): индикатор в шапке", "но не способа показа. Согласовано ' + AG + ' (решение 8): индикатор в шапке")
P.rep("Необходимость сверки следует из SPEC; предложение (не утверждено) — окно", "Необходимость сверки следует из SPEC; форма согласована ' + AG + ' (решение 5) — окно")
P.rep("  ('Предложения для переноса в DESIGN.md и tokens.css', '`--color-border-strong`, правило 12 px, `--color-scrim`, фон строк diff: остаются предложениями'),",
      "  ('Дополнения к DESIGN.md и tokens.css', '`--color-border-strong`, правило 12 px, `--color-scrim`, правило фона строк diff, разделы об окнах, опасных действиях, значках, вводе сообщений и размере окна: согласованы ' + AG + ' и внесены в рабочую копию репозитория (без коммита)'),")
P.rep("  ('Масштаб 200% и VoiceOver', 'Не проверены; ручные сценарии ниже'),\n  ('Нативные флажки и переключатели', 'Различимость проверена, контраст не измерялся; рисует браузер'),",
      "  ('Масштаб 200%', 'Проверен настоящим масштабом браузера в Chrome: окна 1440×900, 1000×720 и минимальное 640×480, обе темы (лист 3)'),\n"
      "  ('VoiceOver', 'Не проверено; перенесено на приёмку приложения (согласовано ' + AG + '): первые проверки — при появлении экранов, окончательная — P8. Ручной сценарий — лист 3'),\n"
      "  ('Нативные флажки и переключатели', 'Контраст измерен по пикселям — не ниже 4,53 в тёмной и 4,35 в светлой теме, клавиатура проверена; рисует браузер, в Electron не проверялись'),\n"
      "  ('Ограничения опубликованной площадки', 'События мыши внутри Play и подтверждение «Save file» не проверены (ограничение инструмента); передачу дизайна не блокируют — лист 3'),")
# --- лист 2: вместо текстов предложений — что внесено; точный diff на листе 4
between(" sec('Предлагаемое дополнение к tokens.css',", " sec('Затемнение под окнами и фон строк diff: точные значения',",
 """ sec('Дополнения к tokens.css и DESIGN.md: согласованы и внесены', table('Внесено', ['Файл', 'Что внесено'], [
   ('`src/renderer/styles/tokens.css`', '`--color-border-strong` (светлая `#858580`, тёмная `#6f6f69`) — только границы полей ввода; `--color-scrim` (`rgba(250, 250, 249, 0.72)` и `rgba(21, 21, 20, 0.72)`) — затемнение за модальным окном. Остальные токены не менялись.'),
   ('`docs/DESIGN.md`', 'Принципы: diff передаётся полосой и знаком без цветных фонов; неподтверждённое не выглядит успехом; размер текста не меньше 12 px для пояснений и ошибок; причина у недоступного действия. Разделы «Поля ввода», «Ввод сообщений», «Размер окна» (минимум 640×480, правило масштаба 200%, рекомендация 1280×960), «Окна и панели поверх», «Опасные действия», «Значки состояния». Таблица токенов: два новых токена.'),
   ], ['300px', '']) + '<div class="sm muted" style="margin-top:var(--space-2)">Согласовано ' + e(AG) + ', внесено в рабочую копию репозитория без коммита. Точный diff — лист 4. Контраст <span class="mono">--color-border-strong</span>: тёмная 3,61 на <span class="mono">--color-bg</span>, 3,30 на <span class="mono">--color-surface</span>, 3,71 на <span class="mono">--color-surface-sunken</span>; светлая 3,55, 3,71 и 3,31. Нативные флажки и переключатели рисует браузер: их контраст измерен по пикселям — не ниже 4,53 в тёмной и 4,35 в светлой теме (лист 3).</div>'),
""")
P.rep("('`--color-scrim` (предложение)',", "('`--color-scrim` (согласовано, tokens.css)',")
P.rep("Значения измерены по отрисованной странице версии 15 (<code>tests/tokens5.mjs</code>, расчёт WCAG 2.x по компонентам цвета). Новые цвета не вводятся. Если приёмка захочет тонированные фоны строк diff, их значения нужно подобрать и проверить отдельно: этот лист их не предлагает.",
      "Значения измерены по отрисованной странице версии 17 (<code>tests/tokens5.mjs</code>, расчёт WCAG 2.x по компонентам цвета). Новые цвета не вводятся: отказ от тонированных фонов строк diff согласован ' + AG + ' (решение 2).")
P.rep("<div class=\"med\">Затемнение под окнами (предложение 12)</div>", "<div class=\"med\">Затемнение под окнами (предложение 12, согласовано)</div>")
P.rep("<div class=\"med\" style=\"margin-top:var(--space-4)\">Фон строк diff (предложение 11)</div>", "<div class=\"med\" style=\"margin-top:var(--space-4)\">Фон строк diff (предложение 11, согласовано)</div>")
between("OPEN_ITEMS = [", "def code(s):", """OPEN_ITEMS = [
 ('11. Фон добавленных и удалённых строк diff', 'Согласовано ' + AG + ' (решение 2): новых цветов нет; правило внесено в DESIGN.md. Значения — в разделе выше.'),
 ('12. Затемнение под модальным окном', 'Согласовано ' + AG + ' (решение 2): `--color-scrim` внесён в tokens.css, макет его использует. Значения — в разделе выше.'),
 ('13–14. Опасная кнопка, окна и панели поверх', 'Согласовано ' + AG + ' (решение 9): разделы «Опасные действия» и «Окна и панели поверх» внесены в DESIGN.md.'),
 ('15. Return / Shift+Return', 'Принято 13.10.2026; текст (с учётом IME) внесён в DESIGN.md («Ввод сообщений») ' + AG + '.'),
 ('17. Значки как спрайт', 'Согласовано ' + AG + ' (решение 9): раздел «Значки состояния» в DESIGN.md — значки из одного спрайта, `<use href="#ic-…">`.'),
 ('18. Минимальный размер окна 640×480', 'Размер задан в `src/main/index.ts`; текст внесён в DESIGN.md («Размер окна») ' + AG + '. Минимум действует и при масштабе 200% (проверено, лист 3); окно от 1280×960 при 200% — рекомендация, не минимум.'),
]
""")
P.rep(" sec('Остальные предложения, ожидающие решения', table('Предложения', ['Предложение', 'Статус'], OPEN_ITEMS, ['300px', ''])),",
      " sec('Статус предложений 11–18', table('Предложения', ['Предложение', 'Статус'], OPEN_ITEMS, ['300px', ''])),")
# --- лист 3
P.rep("CHECKS = json.load(open('tools/checks7.json', encoding='utf-8'))", "CHECKS = json.load(open('tools/checks8.json', encoding='utf-8'))")
P.rep(" sec('Ручные сценарии для непроверенного', '<div style=\"display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:var(--space-6)\"><div><div class=\"med\" style=\"margin-bottom:var(--space-2)\">Масштаб 200%</div>' + olist(CHECKS['manual_zoom']) + '</div><div><div class=\"med\" style=\"margin-bottom:var(--space-2)\">VoiceOver</div>'",
      " sec('Ручные сценарии: масштаб 200% и VoiceOver', '<div style=\"display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:var(--space-6)\"><div><div class=\"med\" style=\"margin-bottom:var(--space-2)\">Масштаб 200%</div>' + olist(CHECKS['manual_zoom']) + '</div><div><div class=\"med\" style=\"margin-bottom:var(--space-2)\">VoiceOver: не проверено, перенесено на приёмку приложения</div>'")
P.rep(" sec('Замечания независимого ревью Version 17 и их закрытие', review17_html(),",
      " sec('Согласование ' + AG + ' и его выполнение', agreed17_html(), 'Решения пользователя по листу 4, ограничения площадки и перенос VoiceOver; что сделано и чем подтверждено.'),\n sec('Изменения версии 17', bullets(CHECKS['changes17'])),\n sec('Замечания независимого ревью Version 17 и их закрытие', review17_html(),")
P.rep("def kit_html():", '''def agreed17_html():
    h = '<thead><tr><th scope="col" style="width:200px">Решение</th><th scope="col" style="width:360px">Что сделано</th><th scope="col" style="width:300px">Как проверено</th><th scope="col" style="width:240px">Доказательство</th><th scope="col">Остаточные ограничения</th></tr></thead>'
    b = ''.join('<tr><td class="med">%s</td><td>%s</td><td>%s</td><td class="muted">%s</td><td class="muted">%s</td></tr>' % tuple(md(c) for c in r) for r in CHECKS['agreed17'])
    return '<table style="width:100%%;border-collapse:collapse;margin-top:var(--space-2)" class="sm"><caption class="sr">Согласование и его выполнение</caption>%s<tbody>%s</tbody></table>' % (h, b)
def kit_html():''')
P.rep(" sec('Решения для окончательной приёмки (предложения)', bullets(CHECKS['decisions']), 'Ни одно решение не утверждено. Обязательные требования SPEC отделены от предлагаемых способов их показа. Готовность макета не означает готовность реализации приложения.'),",
      " sec('Решения (согласованы ' + AG + ')', bullets(CHECKS['decisions']), 'Обязательные требования SPEC отделены от выбора интерфейса. Готовность макета не означает готовность реализации приложения.'),")
# --- лист 4
between("def decisions_html():", "def extra_html():", '''def decisions_html():
    h = '<thead><tr><th scope="col" style="width:40px">№</th><th scope="col" style="width:300px">Что предлагалось</th><th scope="col" style="width:300px">Рекомендация и основание</th><th scope="col" style="width:280px">Альтернатива и последствия</th><th scope="col" style="width:260px">Обязательно по SPEC</th><th scope="col">Выбор интерфейса и что внесено</th></tr></thead>'
    b = ''
    for d in CHECKS['decisions16']:
        b += '<tr><td class="med">%d</td><td><div class="med">%s</div><div style="margin-top:var(--space-1)">%s</div><div style="margin-top:var(--space-1)"><span class="tag ok">%s</span></div></td><td>%s</td><td>%s</td><td class="muted">%s</td><td>%s<div class="muted" style="margin-top:var(--space-1)">%s</div></td></tr>' % (
            d['n'], e(d['title']), md(d['proposal']), e(d['status']), md(d['recommendation']), md(d['alternative']), md(d['spec']), md(d['ui']), md(d['done']))
    return '<table style="width:100%%;border-collapse:collapse;margin-top:var(--space-2)" class="sm"><caption class="sr">Решения</caption>%s<tbody>%s</tbody></table>' % (h, b)
''')
between("def proposals_html():", "def boundaries_html():", '''def proposals_html():
    D = BASIS['design']
    txt = open(D['patch'], encoding='utf-8').read()
    out = '<div class="sm muted" style="max-width:1100px">Согласовано %s, внесено в рабочую копию репозитория без коммита. Основа — файлы на коммите <span class="mono">bc6a5c9</span> (до HEAD <span class="mono">%s</span> не менялись); посторонних правок в них не было. Внесено: патчи версии 16 <span class="mono">d0</span>, <span class="mono">d1</span>, <span class="mono">d2</span>, <span class="mono">d9</span> (<span class="mono">proposals/all.patch</span>) и абзац о масштабе 200%% в разделе «Размер окна». SHA-256 после изменения: DESIGN.md <span class="mono">%s…</span>, tokens.css <span class="mono">%s…</span>.</div>' % (
        e(D['agreed_ru']), e(BASIS['repo']['head']), D['files']['docs/DESIGN.md'][:12], D['files']['src/renderer/styles/tokens.css'][:12])
    out += '<div style="margin-top:var(--space-4)"><div class="med">Внесённый diff <span class="muted mono sm">%s</span></div>%s</div>' % (e(D['patch']), udiffcode(txt))
    return out
def platform_html():
    h = '<thead><tr><th scope="col" style="width:260px">Действие</th><th scope="col" style="width:150px">Статус</th><th scope="col" style="width:420px">Почему</th><th scope="col">Чем подтверждено вместо него</th></tr></thead>'
    b = ''.join('<tr><td class="med">%s</td><td>%s</td><td>%s</td><td class="muted">%s</td></tr>' % (md(x['what']), status_tag('no'), md(x['why']), md(x['instead'])) for x in CHECKS['platform'])
    return '<table style="width:100%%;border-collapse:collapse;margin-top:var(--space-2)" class="sm"><caption class="sr">Ограничения опубликованной площадки</caption>%s<tbody>%s</tbody></table>' % (h, b)
def app_checks_html():
    h = '<thead><tr><th scope="col" style="width:340px">Проверка приложения</th><th scope="col" style="width:300px">Когда</th><th scope="col">Критерий приёмки</th></tr></thead>'
    b = ''.join('<tr><td class="med">%s</td><td>%s</td><td class="muted">%s</td></tr>' % (md(x['what']), md(x['when']), md(x['accept'])) for x in CHECKS['app_checks'])
    return '<table style="width:100%%;border-collapse:collapse;margin-top:var(--space-2)" class="sm"><caption class="sr">Проверки приложения</caption>%s<tbody>%s</tbody></table>' % (h, b)
''')
P.rep("            ('Готово', I['code']['ready_contract']), ('Нет', I['code']['absent']), ('Источники', I['code']['evidence'])]",
      "            ('Готово', I['code']['ready_contract']), ('Нет', I['code']['absent']), ('Источники', I['code']['evidence']),\n"
      "            ('Дизайн-контракт', 'Согласовано %s: %s Изменения: %s.' % (I['design']['agreed_ru'], I['design']['what'], I['design']['applied']))]")
P.rep(" sec('Решения, ожидающие согласования', decisions_html(), 'Десять решений из пакета передачи. Ни одно не утверждено: рекомендация — мнение исполнителя, решение за приёмкой. Колонка «Обязательно по SPEC» — что требует спецификация независимо от решения; «Выбор интерфейса» — что согласуется.'),",
      " sec('Решения (согласованы ' + AG + ')', decisions_html(), 'Десять решений из пакета передачи приняты в рекомендованном варианте. Колонка «Обязательно по SPEC» — что требует спецификация независимо от решения; «Выбор интерфейса» — что было согласовано.'),")
P.rep(" sec('Точные предлагаемые изменения tokens.css и DESIGN.md', proposals_html(), 'Для просмотра. Переносятся в репозиторий только после согласования соответствующего решения.'),",
      " sec('Внесённые изменения tokens.css и DESIGN.md', proposals_html()),")
P.rep(" sec('Состояние реализации, на которое опираются листы', impl_html(),",
      " sec('Ограничения опубликованной площадки', platform_html(), 'Не отмечаются проверенными; передачу дизайна не блокируют (согласовано ' + AG + ').'),\n"
      " sec('Проверки приложения', app_checks_html(), 'Отдельный список: что проверяется в собранном Electron-приложении. В этап дизайна не входит и не выполнялось; без этих проверок приложение не принимается.'),\n"
      " sec('Состояние реализации, на которое опираются листы', impl_html(),")
P.rep("page('ho2', 'Пакет передачи 2: компоненты и дополнения к контракту', 'Из чего собран макет и что предлагается добавить в DESIGN.md и tokens.css. Предложения не внесены в репозиторий.',",
      "page('ho2', 'Пакет передачи 2: компоненты и дополнения к контракту', 'Из чего собран макет и что добавлено в DESIGN.md и tokens.css: согласовано ' + AG + ', рабочая копия репозитория без коммита.',")
P.rep("page('ho4', 'Пакет передачи 4: решения к согласованию и границы этапа (версия 16)', 'Десять решений с рекомендацией и альтернативой, точные предлагаемые изменения контракта и что остаётся будущим задачам приложения.',",
      "page('ho4', 'Пакет передачи 4: решения, границы этапа и проверки приложения (версия 17)', 'Десять согласованных решений, внесённые изменения контракта, ограничения площадки и отдельный список проверок приложения.',")
P.rep("page('ho3', 'Пакет передачи 3: визуальные материалы, проверки и решения (версия 16)',", "page('ho3', 'Пакет передачи 3: визуальные материалы, проверки и решения (версия 17)',")
P.save()
