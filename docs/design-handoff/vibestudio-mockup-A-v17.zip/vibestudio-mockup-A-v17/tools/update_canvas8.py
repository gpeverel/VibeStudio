# -*- coding: utf-8 -*-
# Версия 17 (создан из update_canvas7.py версии 16): обновляет project/canvas.json версии 16 → 17 и обёртки листов.
#   python3 -I tools/update_canvas8.py <файл heights.json>   (из каталога сборки, после gen_handoff8.py и tests/ui7/heights.mjs)
# Что делает: высоты и положение листов (Map, Trace, Prop2, Handoff1–4) на холсте; высота в обёртках листов; название листа 4
# («решения, границы этапа и проверки приложения»); заголовок версии 17 над заголовком версии 16 (тот сохраняется).
# Остальные платформы и их положение не меняются.
import json, re, sys
H = json.load(open(sys.argv[1], encoding='utf-8'))
C = json.load(open('project/canvas.json', encoding='utf-8'))
B, O, N = C['boards'], C['order'], C['notes']
def put(name, x, y, w, h, title):
    d = B.get(name, {}); d.update({'x': x, 'y': y, 'w': w, 'h': h, 'title': title}); B[name] = d
    if name not in O: O.append(name)
DX = 17460
put('M-Map.dc.html', DX, 0, 1440, H['Map'], B['M-Map.dc.html']['title'])
put('M-Trace.dc.html', DX, H['Map'] + 120, 1440, H['Trace'], B['M-Trace.dc.html']['title'])
put('M-Prop2.dc.html', DX, H['Map'] + H['Trace'] + 240, 1440, H['Prop2'], B['M-Prop2.dc.html']['title'])
TITLES = {'Handoff1': 'Пакет передачи 1: карта экранов и состояния', 'Handoff2': 'Пакет передачи 2: компоненты и дополнения к контракту',
          'Handoff3': 'Пакет передачи 3: визуальные материалы, проверки и решения', 'Handoff4': 'Пакет передачи 4: решения, границы этапа и проверки приложения'}
y = 0
for k, ttl in TITLES.items():
    n = k.replace('Handoff', 'H')
    put('%s-Dark.dc.html' % n, 19020, y, 1440, H[k], ttl + ' · тёмная')
    put('%s-Light.dc.html' % n, 20580, y, 1440, H[k], ttl + ' · светлая')
    y += H[k] + 120
# компонентные доски листов
base_y = 26340
put('Map.dc.html', 1560, base_y, B['Map.dc.html']['w'], H['Map'], B['Map.dc.html']['title'])
put('Trace.dc.html', 1560, base_y + H['Map'] + 120, B['Trace.dc.html']['w'], H['Trace'], B['Trace.dc.html']['title'])
put('Prop2.dc.html', 1560, base_y + H['Map'] + H['Trace'] + 240, B['Prop2.dc.html']['w'], H['Prop2'], B['Prop2.dc.html']['title'])
y2 = base_y + H['Map'] + H['Trace'] + H['Prop2'] + 360
put('AddProject.dc.html', 1560, y2, B['AddProject.dc.html']['w'], B['AddProject.dc.html']['h'], B['AddProject.dc.html']['title']); y2 += 820
for k in TITLES:
    put(k + '.dc.html', 1560, y2, 1440, H[k], 'Компонент: пакет передачи %s' % k[-1]); y2 += H[k] + 120
N['t7'] = {'x': 22140, 'y': -600, 'text': 'Версия 17 (согласование 27.10.2026): десять решений приняты и внесены в DESIGN.md и tokens.css (рабочая копия, без коммита); минимальное окно 640×480 проверено при настоящем масштабе 200%; VoiceOver перенесён на приёмку приложения. Решения, ограничения площадки и проверки приложения — пакет передачи 4 (x 19020)', 'kind': 'title1', 'maxW': 4800}
def rewrap(fn, h):
    p = 'project/' + fn; t = open(p, encoding='utf-8').read()
    t2 = re.sub(r'(<dc-import name="[A-Za-z0-9]+" theme="(?:dark|light)") h="\d+" hint-size="1440px,\d+px"', r'\1 h="%d" hint-size="1440px,%dpx"' % (h, h), t)
    t2 = re.sub(r'\{"\$preview":\{"width":1440,"height":\d+\}\}', '{"$preview":{"width":1440,"height":%d}}' % h, t2)
    if t2 == t and ('h="%d"' % h) not in t: raise SystemExit('не найдена высота в ' + fn)
    open(p, 'w', encoding='utf-8').write(t2)
for k in TITLES:
    for th in ('Dark', 'Light'): rewrap('%s-%s.dc.html' % (k.replace('Handoff', 'H'), th), H[k])
for nm, k in (('M-Map', 'Map'), ('M-Trace', 'Trace'), ('M-Prop2', 'Prop2')): rewrap(nm + '.dc.html', H[k])
json.dump(C, open('project/canvas.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('boards', len(B), 'order', len(O), 'notes', len(N))
