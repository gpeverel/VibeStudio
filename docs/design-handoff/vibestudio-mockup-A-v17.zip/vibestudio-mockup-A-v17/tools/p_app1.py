import sys
sys.path.insert(0, '..')
from pt import Patch
a = Patch('project/App.dc.html')

# ---------- шаблон
a.rep('''      <div style="flex:none;padding:var(--space-3)">
        <button class="btn btn-quiet" id="btn-new"''', '''      <sc-if value="{{hasOrph}}"><div style="flex:none;padding:0 var(--space-3)"><button class="btn" id="btn-orph" style="width:100%;justify-content:flex-start;height:auto;min-height:28px;padding:var(--space-1) var(--space-3);white-space:normal;text-align:left" onClick="{{openOrph}}"><svg class="ic {{orphIc.cls}}" viewBox="0 0 16 16" aria-hidden="true" style="{{orphIc.st}}"><use href="#{{orphIc.id}}"/></svg>Найдена рабочая копия без сессии</button></div></sc-if>
      <div style="flex:none;padding:var(--space-3)">
        <button class="btn btn-quiet" id="btn-new"''')
a.rep('''      <div style="{{inBodyStyle}}">

        <div role="tabpanel" id="tp-team"''', '''      <div style="{{inBodyStyle}}">
        <sc-if value="{{dbNote}}"><div id="db-note" role="note" class="sm" style="display:flex;gap:var(--space-2);align-items:flex-start;padding:var(--space-2) var(--space-3);border:1px solid var(--color-warning);border-radius:var(--radius-md)"><svg class="ic {{dbNoteIc.cls}}" viewBox="0 0 16 16" aria-hidden="true" style="margin-top:2px"><use href="#{{dbNoteIc.id}}"/></svg><span style="flex:1;min-width:0">{{dbNote}}</span></div></sc-if>

        <div role="tabpanel" id="tp-team"''')
a.rep('onRs="{{onRs}}"></dc-import>', 'onRs="{{onRs}}" wr="{{wrV}}" dbw="{{dbw}}" dbv="{{dbv}}" solo="{{solo}}" act="{{canStop}}" ap="{{apV}}" ctxp="{{ctxpName}}" orph="{{orphV}}" rls="{{rlsObj}}" onRules="{{onRules}}"></dc-import>')

# ---------- свойства
a.rep('"rkind":{"editor":"text","default":"stop"},"$preview"', '"rkind":{"editor":"text","default":"stop"},"dbw":{"editor":"text","default":""},"dbv":{"editor":"text","default":"stopped"},"pctx":{"editor":"text","default":""},"orph":{"editor":"text","default":""},"wr":{"editor":"text","default":"ok"},"rls":{"editor":"text","default":""},"$preview"')
a.rep('"rules","restart","ctxlost","manual"]', '"rules","restart","ctxlost","manual","dberr","orphan"]')
a.rep("'permV', 'consent', 'authOk', 'rs', 'rcli',", "'permV', 'consent', 'authOk', 'rs', 'rcli', 'pctx',")

# ---------- состояние
a.rep("    this._rsv = rsv;\n", '''    this._rsv = rsv;
    const dbw = s.dbw ?? p.dbw ?? '', dbv = p.dbv || 'stopped';
    const pctx = s.pctx ?? (own ? (p.pctx || '') : '');
    const orphV = s.orphV ?? p.orph ?? '';
    let rlsObj = null; try { rlsObj = s.rls ?? (p.rls ? JSON.parse(p.rls) : null); } catch (e) { rlsObj = null; }
    if (!rlsObj) rlsObj = { user: (own ? p.perm : '') === 'user', denyPat: 'npm run build', added: [] };
''')

# ---------- наложение безопасной остановки при ошибке записи + недоступный диалог участника
a.rep('''    const teamBad = roster.some(x => x.kind === 'err' || x.kind === 'stoperr' || x.kind === 'stopwarn' || x.kind === 'lock');''', '''    if (dbw && canStop && !stopPh) {
      const dbMap = (i, r) => {
        if (r.kind === 'done' || r.kind === 'lock') return null;
        const act = r.kind === 'read' || r.kind === 'write' || r.kind === 'wait';
        if (!act) return { kind: 'cancelled', label: 'Очередь отменена', activity: 'Не будет запущен: запуск нельзя записать', det: 'Был в очереди; ход не начинался.' };
        if (dbv === 'active') return { kind: 'stopreq', label: 'Безопасная остановка: запрос отправлен', activity: 'Запись состояния недоступна, выход ещё не подтверждён', det: 'Результат пока неизвестен.' };
        if (dbv === 'mixed' && (solo || i === 2)) return { kind: 'stoperr', label: 'Остановка не подтверждена', activity: 'Принадлежность запуска не установлена', det: 'Автоматически не завершаем; слот записи не освобождён. Исход не записан.' };
        return { kind: 'stopok', label: 'Остановка подтверждена', activity: 'Процесс вышел, потоки закрыты', det: 'Исход в базу не записан: восстановится сверкой.' };
      };
      roster = roster.map((r, i) => { const m = dbMap(i, r); if (!m) return r; return Object.assign({}, r, { kind: m.kind, ic: ico(m.kind), label: m.label, activity: m.activity, labelClass: m.kind === 'stoperr' ? 'semi' : '', details: [{ k: 'Остановка', v: m.det }].concat(r.details.filter(x => x.k === 'Расход' || x.k === 'Владение')) }); });
    }
    if (!solo && pctx && roster[2]) {
      const m = pctx === 'lost' ? { kind: 'stopwarn', label: 'Диалог CLI недоступен', activity: 'Завершение подтверждено, прежний контекст продолжить нельзя', det: 'Новый диалог начинается только явно, с предупреждением о потере контекста. Диалоги остальных участников не затронуты.' } : { kind: 'idle', label: 'Новый диалог создан, ход не начат', activity: 'Ждёт вашего сообщения', det: 'Диалог начат без прежнего контекста. Ход автоматически не запускался.' };
      roster = roster.map((r, i) => i !== 2 ? r : Object.assign({}, r, { kind: m.kind, ic: ico(m.kind), label: m.label, activity: m.activity, labelClass: m.kind === 'stopwarn' ? 'semi' : '', details: [{ k: 'Диалог', v: m.det }].concat(r.details.filter(x => x.k === 'Расход' || x.k === 'Владение')) }));
    }
    const teamBad = roster.some(x => x.kind === 'err' || x.kind === 'stoperr' || x.kind === 'stopwarn' || x.kind === 'lock');''')

# ---------- права: «разрешено»
a.rep("        policy: { reason: 'Запрещено внешней политикой: managed-настройка организации.'", "        granted: { reason: 'Разрешено вашим правилом allow Bash(npm run build). Вызов уже отклонён и сам не повторится.', scope: 'См. «Посмотреть действующие правила»', src: 'Ваше правило: срок и область указаны в списке правил', note: 'Разрешение не гарантирует повтор: продолжение — новый ход, который запускаете вы. Уже выполненные действия не повторяются.', icon: 'lock' },\n        policy: { reason: 'Запрещено внешней политикой: managed-настройка организации.'")
a.rep("        : [{ id: 'perm-rules', label: 'Посмотреть правило', cls: '', off: false, go: () => this.openDlg('rules') }, { id: 'perm-write', label: 'Написать участнику', cls: '', off: false, go: () => this.writeTo(2, 'Эту команду запретила внешняя политика. Продолжи без неё.') }];",
      "        : permV === 'granted' ? [{ id: 'perm-rules', label: 'Посмотреть действующие правила', cls: '', off: false, go: () => this.openDlg('rules') }, { id: 'perm-write', label: 'Написать участнику', cls: '', off: false, go: () => this.writeTo(2, 'Разрешение добавлено. Повтори сборку новым ходом.') }]\n        : [{ id: 'perm-rules', label: 'Посмотреть правило', cls: '', off: false, go: () => this.openDlg('rules') }, { id: 'perm-write', label: 'Написать участнику', cls: '', off: false, go: () => this.writeTo(2, 'Эту команду запретила внешняя политика. Продолжи без неё.') }];")
a.rep("who: permV === 'none' ? 'Отсутствие разрешения' : permV === 'user' ? 'Собственный запрет пользователя' : 'Внешняя политика', whoCls: permV === 'policy' ? 'bad' : 'warn' });",
      "who: permV === 'none' ? 'Отсутствие разрешения' : permV === 'user' ? 'Собственный запрет пользователя' : permV === 'granted' ? 'Разрешение добавлено' : 'Внешняя политика', whoCls: permV === 'policy' ? 'bad' : 'warn' });")

# ---------- баннеры
a.rep("    // Сообщения, отправленные из композера", '''    if (!solo && pctx === 'lost') tl.push({ isAlert: true, title: 'Тесты: диалог CLI недоступен', text: 'Claude не нашёл сохранённый диалог участника «Тесты». Диалоги остальных участников и история команды сохранены. Новый диалог начинается только явно: участник не будет помнить прежний разговор.', action: 'Новый диалог для «Тесты»…', onAction: () => this.openDlg('ctxlost'), actionOff: false, hasAction2: false, actionWhy: 'Ход автоматически не запускается и общим успешным статусом не заменяется.' });
    if (!solo && pctx === 'new') tl.push({ isNote: true, text: 'Новый диалог участника «Тесты» создан · 14:49. Ход не начат: участник ждёт сообщения. Диалоги остальных не менялись.' });
    if (dbw === 'err') tl.push({ isAlert: true, title: 'Состояние не сохраняется', text: 'Приложение не может записать данные в базу, поэтому новые изменяющие действия заблокированы, а активный запуск останавливается. Лента показывает последнее сохранённое состояние (14:21), а не текущее.' + (apState === 'unsaved' ? ' Применение уже завершено в Git (main на c91d2e8), но результат не записан.' : ''), action: 'Что произошло и что делать…', onAction: () => this.openDlg('dberr'), actionOff: false, hasAction2: false, actionWhy: 'После восстановления записи сначала сверка; операции автоматически не повторяются.' });
    if (dbw === 'rec') tl.push({ isAlert: true, title: 'Запись восстановлена: нужна сверка', text: 'База снова принимает запись. Изменяющие действия остаются заблокированными, пока приложение не сверит записи с процессами и Git.', action: 'Выполнить сверку…', onAction: () => this.openDlg('dberr'), actionOff: false, hasAction2: false, actionWhy: 'Сверка только читает данные. Прерванные операции не повторяются.' });
    // Сообщения, отправленные из композера''')

# ---------- статус
a.rep("    if (scen === 'problem' && solo) stRow = authOk(s)", '''    if (apState === 'unsaved') stRow = ['Применено в Git · запись не сохранена', 'bad'];
    if (pctx === 'lost' && !solo) stRow = ['Диалог «Тесты» недоступен', 'stopwarn'];
    if (dbw === 'err') stRow = ['Состояние не сохраняется', 'stoperr'];
    if (dbw === 'rec') stRow = ['Запись восстановлена: нужна сверка', 'stopwarn'];
    if (scen === 'problem' && solo) stRow = authOk(s)''')
a.rep("    const stopOff = !(canStop && !stopPh);", "    const stopOff = !(canStop && !stopPh) || !!dbw;")

# ---------- действия
a.rep("    // ---------- Панели и стили\n", '''    if (apState === 'unsaved') { const ur = actions.find(x => x.id === 'act-apply'); if (ur) ur.why = 'Применение уже выполнено в Git; повтор не нужен. Результат ещё не записан.'; }
    if (dbw) {
      actions.forEach((x) => { x.off = true; x.why = dbw === 'err' ? 'Запись состояния недоступна: изменяющие действия заблокированы.' : 'Запись восстановлена, но сначала нужна сверка.'; });
      actions.unshift({ id: 'act-dberr', label: dbw === 'err' ? 'Состояние записи…' : 'Выполнить сверку…', cls: 'btn-primary', off: false, why: dbw === 'err' ? 'Что произошло с запуском и что заблокировано.' : 'Только читает данные. Операции не повторяются.', go: open('dberr'), style: 'min-width:132px' });
    }

    // ---------- Панели и стили
''')

# ---------- композер
a.rep("composeOff: scen === 'applied', composePh: scen === 'applied' ? 'Сессия применена: для следующего изменения создайте новую' : 'Сообщение', hintText: scen === 'applied' ? '' :",
      "composeOff: scen === 'applied' || !!dbw, composePh: dbw ? 'Состояние не сохраняется: сообщения пока не принимаются' : scen === 'applied' ? 'Сессия применена: для следующего изменения создайте новую' : 'Сообщение', hintText: dbw ? 'Сообщения и ходы заблокированы до восстановления записи и сверки' : scen === 'applied' ? '' :")
a.rep("sendOff: !(s.draftOn ?? (p.draft === 'long')) || scen === 'applied',", "sendOff: !(s.draftOn ?? (p.draft === 'long')) || scen === 'applied' || !!dbw,")
a.rep("rcptOff: solo || scen === 'applied',", "rcptOff: solo || scen === 'applied' || !!dbw,")

# ---------- значения для шаблона и Ops
a.rep("      rsvar: p.rsvar || 'resolve', mvar: p.mvar || 'none',", '''      rsvar: p.rsvar || 'resolve', mvar: p.mvar || 'none',
      wrV: p.wr || 'ok', dbw, dbv, solo, canStop, apV: apState, ctxpName: (!solo && pctx === 'lost') ? 'Тесты' : '', orphV, rlsObj,
      onRules: (next, v) => this.setState({ rls: next, permV: permV === 'policy' ? 'policy' : v === 'deny' ? 'user' : v === 'allow' ? 'granted' : 'none' }),
      hasOrph: !!orphV, orphIc: ico('stopwarn'), openOrph: () => this.openDlg('orphan'),
      dbNote: dbw === 'err' ? 'Показано последнее сохранённое состояние (14:21). Позже записей нет, поэтому статусы и результаты могут быть неактуальны.' : dbw === 'rec' ? 'Запись восстановлена, сверка ещё не выполнена: данные могут быть неактуальны.' : '', dbNoteIc: ico('stopwarn'),''')
a.rep("      opsRs: { impl: rsv.impl, tests: rsv.tests, n: rsv.n || 0,", "      opsRs: { pctx, impl: rsv.impl, tests: rsv.tests, n: rsv.n || 0,")

# ---------- завершение диалогов
a.rep("        if (r.flag) this.setState({ apState: r.flag });", '''        if (r.kind === 'perm' && r.ok) this.setState(Object.assign({ rls: Object.assign({}, rlsObj, { added: rlsObj.added.concat([{ id: 'r' + (rlsObj.added.length + 1), type: 'allow', tool: 'Bash', pat: 'npm run build', term: r.scope || 'turn' }]) }) }, r.go ? {} : { permV: 'granted' }));
        if (r.kind === 'rule' && r.ok) this.setState({ rls: Object.assign({}, rlsObj, { user: false }) });
        if (r.flag) this.setState({ apState: r.flag });''')
a.rep("        else if ((r.kind === 'reconcile' || r.kind === 'manual') && r.result === 'completed') this.setState({ apState: '', scen: 'applied', applied: { sha: 'c91d2e8', bypass: false }, undone: '' });",
      '''        else if ((r.kind === 'reconcile' || r.kind === 'manual') && r.result === 'completed') {
          if (r.saved) this.setState(Object.assign({ apState: '', scen: 'applied', applied: { sha: 'c91d2e8', bypass: false }, undone: '', liveMsg: 'Результат применения сохранён.' }, r.recovered ? { dbw: '' } : {}));
          else this.setState({ apState: 'unsaved', dbw: 'err', liveMsg: 'Git-результат подтверждён, но результат не сохранён: база не принимает запись.' });
        }
        else if ((r.kind === 'reconcile' || r.kind === 'manual') && r.view === 'result') this.setState({ tab: 'changes' });
        else if (r.kind === 'dberr' && r.state === 'rec') this.setState({ dbw: 'rec', liveMsg: 'Запись восстановлена. Нужна сверка.' });
        else if (r.kind === 'dberr' && r.ok) this.setState(Object.assign({ dbw: '', liveMsg: 'Сверка выполнена. Работа разблокирована.' }, apState === 'unsaved' ? { apState: '', scen: 'applied', applied: { sha: 'c91d2e8', bypass: false }, undone: '' } : {}));
        else if (r.kind === 'ctxlost' && r.ok && r.who) this.setState({ pctx: 'new', liveMsg: 'Новый диалог участника «' + r.who + '» создан. Ход не начат.' });''')
a.rep("    else if (a === 'csv-ctx') {", "    else if (a === 'pctx') { this.openDlg('ctxlost'); }\n    else if (a === 'csv-ctx') {")
a.save()
