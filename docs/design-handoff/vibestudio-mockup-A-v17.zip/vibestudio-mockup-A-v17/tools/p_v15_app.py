# -*- coding: utf-8 -*-
# Правки App.dc.html версии 15 (замечания B-01, B-02, A-09). Применяется один раз к файлу версии 14:
#   python3 tools/p_v15_app.py project/App.dc.html
import sys
sys.path.insert(0, __import__('os').path.dirname(__file__))
from pt import Patch
P = Patch(sys.argv[1] if len(sys.argv) > 1 else 'project/App.dc.html')

# --- B-01: закреплённая боковая панель (≥1280) не удерживает фокус, модальная (<1280) удерживает --------------
P.rep("sbPanelKey: trap('sb-panel', () => setPanel('sb', false)),",
      "sbPanelKey: sbOver ? trap('sb-panel', () => setPanel('sb', false)) : undefined,")

# --- Общая блокировка записи (B-02) ------------------------------------------------------------------------------
# Начальное состояние статических платформ «запись результата не удалась»: Git-результат подтверждён, запись не сохранена.
P.rep("    const apState = s.apState ?? pv('conflict') ?? '';",
      "    const recFailInit = own && /^(rec|done)fail$/.test(p.dstep || '');\n    const apState = s.apState ?? (recFailInit ? 'unsaved' : pv('conflict')) ?? '';")
P.rep("    const dbw = s.dbw ?? p.dbw ?? '', dbv = p.dbv || 'stopped';",
      "    const dbw = s.dbw ?? p.dbw ?? (recFailInit ? 'err' : ''), dbv = p.dbv || 'stopped';\n"
      "    // Запись состояния недоступна (err) или ещё не сверена после восстановления (rec): побочные эффекты блокируются во ВСЕХ сессиях и проектах.\n"
      "    const dbWhyShort = dbw === 'err' ? 'Запись состояния недоступна: изменяющие действия заблокированы во всех сессиях и проектах.' : 'Запись восстановлена, но сначала нужна сверка: изменяющие действия остаются заблокированными.';\n"
      "    const recHere = (s.rec && s.rec.sid === sid) ? s.rec : null;")

# Статус завершённой/неактивной сессии не затирается общим состоянием записи: общее состояние показывает отдельный индикатор.
P.rep("    if (dbw === 'err') stRow = ['Состояние не сохраняется', 'stoperr'];\n    if (dbw === 'rec') stRow = ['Запись восстановлена: нужна сверка', 'stopwarn'];",
      "    const dbOwn = canStop;   // статус заменяется только у сессии с активным запуском: его исход зависит от записи\n"
      "    if (dbw === 'err' && dbOwn) stRow = ['Состояние не сохраняется', 'stoperr'];\n    if (dbw === 'rec' && dbOwn) stRow = ['Запись восстановлена: нужна сверка', 'stopwarn'];")

# Текст предупреждения в ленте зависит от сессии
P.rep("    if (dbw === 'err') tl.push({ isAlert: true, title: 'Состояние не сохраняется', text: 'Приложение не может записать данные в базу, поэтому новые изменяющие действия заблокированы, а активный запуск останавливается. Лента показывает последнее сохранённое состояние (14:21), а не текущее.' + (apState === 'unsaved' ? ' Применение уже завершено в Git (main на c91d2e8), но результат не записан.' : ''), action: 'Что произошло и что делать…', onAction: () => this.openDlg('dberr'), actionOff: false, hasAction2: false, actionWhy: 'После восстановления записи сначала сверка; операции автоматически не повторяются.' });",
      "    if (recHere && recHere.busy) tl.push({ isRecOp: true, title: 'Результат применения сохраняется', text: 'Сверка подтвердила: main на c91d2e8. Запись продолжается и после закрытия окна; результат появится в сессии. Повторное применение не запускается и вторая запись не начинается.', action: 'Показать ход записи…', onAction: () => this.openDlg('reconcile', 'apply') });\n"
      "    if (dbw === 'err') tl.push({ isAlert: true, title: 'Состояние не сохраняется', text: (canStop ? 'Приложение не может записать данные в базу, поэтому новые изменяющие действия заблокированы во всех сессиях и проектах, а активный запуск останавливается.' : 'Приложение не может записать данные в базу, поэтому новые изменяющие действия заблокированы во всех сессиях и проектах, а не только в этой. Активного запуска здесь нет, статус сессии не менялся.') + ' Лента показывает последнее сохранённое состояние (14:21), а не текущее.' + (apState === 'unsaved' ? ' Применение уже завершено в Git (main на c91d2e8), но результат не записан.' : ''), action: 'Что произошло и что делать…', onAction: () => this.openDlg('dberr'), actionOff: false, hasAction2: !!(recHere && !recHere.busy && recHere.fail), action2: 'Показать результат записи…', onAction2: () => this.openDlg('reconcile', 'apply'), actionWhy: 'После восстановления записи сначала сверка; операции автоматически не повторяются.' });")
P.rep("    if (apState === 'interrupted') tl.push({ isAlert: true, title: 'Применение прервано',",
      "    if (apState === 'interrupted' && !(recHere && recHere.busy)) tl.push({ isAlert: true, title: 'Применение прервано',")

# Отмена ожидания очереди — изменяющее действие
P.rep("cancel: () => this.setState({ scen: 'empty', sent: [], cancelled: true }) });",
      "cancel: () => { if (this.guardW('ожидание не отменено')) return; this.setState({ scen: 'empty', sent: [], cancelled: true }); }, cancelOff: !!dbw, cancelWhy: dbw ? dbWhyShort : '' });")
P.rep('''<button class="btn" id="cancel-wait" style="margin-top:var(--space-2)" onClick="{{b.cancel}}">Отменить ожидание</button>''',
      '''<button class="btn" id="cancel-wait" style="margin-top:var(--space-2)" disabled="{{b.cancelOff}}" aria-describedby="cancel-why" onClick="{{b.cancel}}">Отменить ожидание</button>
                  <div id="cancel-why" class="sm muted" style="margin-top:var(--space-1)">{{b.cancelWhy}}</div>''')

# Шаблон: ход записи результата в ленте
P.rep('''            <sc-if value="{{b.isAlert}}">
              <section role="alert"''', '''            <sc-if value="{{b.isRecOp}}">
              <section id="recop" aria-label="Запись результата применения" class="card" style="padding:var(--space-3) var(--space-4);display:flex;gap:var(--space-3);align-items:flex-start">
                <svg class="ic acc" viewBox="0 0 16 16" aria-hidden="true" style="margin-top:3px"><path d="M8 4.5a3.5 3.5 0 1 0 0 7a3.5 3.5 0 1 0 0-7z"/></svg>
                <div style="flex:1;min-width:0">
                  <div class="semi">{{b.title}}</div>
                  <div class="sm muted">{{b.text}}</div>
                  <button class="btn" id="recop-show" style="margin-top:var(--space-2)" onClick="{{b.onAction}}">{{b.action}}</button>
                </div>
              </section>
            </sc-if>

            <sc-if value="{{b.isAlert}}">
              <section role="alert"''')

# Ограничение статуса и общий индикатор в заголовке
P.rep('''            <sc-if value="{{hasCtxLine}}"><span class="muted sm" style="{{ctxStyle}}">{{ctx}}</span></sc-if>''',
      '''            <sc-if value="{{hasDbChip}}"><span class="sm med" id="db-chip" style="display:inline-flex;align-items:center;gap:var(--space-1);flex:none"><svg class="ic {{dbChipIc.cls}}" viewBox="0 0 16 16" aria-hidden="true" style="{{dbChipIc.st}}"><use href="#{{dbChipIc.id}}"/></svg>{{dbChipLabel}}</span></sc-if>
            <sc-if value="{{hasCtxLine}}"><span class="muted sm" style="{{ctxStyle}}">{{ctx}}</span></sc-if>''')
P.rep("      line2Style: 'display:flex;align-items:center;gap:var(--space-3);min-width:0;margin-top:2px',",
      "      line2Style: 'display:flex;align-items:center;gap:var(--space-1) var(--space-3);min-width:0;margin-top:2px' + (dbw && !dbOwn ? ';flex-wrap:wrap' : ''),\n"
      "      hasDbChip: !!dbw && !(dbOwn && hasSession), dbChipLabel: dbw === 'err' ? 'Запись состояния недоступна' : 'Запись восстановлена: нужна сверка', dbChipIc: ico(dbw === 'err' ? 'stoperr' : 'stopwarn'),")

# Боковая панель: общее состояние рядом с «Новая сессия» и «Добавить проект»
P.rep('''      <div style="flex:none;padding:var(--space-3)">
        <button class="btn btn-quiet" id="btn-new"''', '''      <sc-if value="{{dbwNote}}"><div id="sb-dbnote" role="note" class="sm" style="flex:none;margin:0 var(--space-3);display:flex;gap:var(--space-2);align-items:flex-start;padding:var(--space-2) var(--space-3);border:1px solid var(--color-warning);border-radius:var(--radius-md)"><svg class="ic {{dbNoteIc.cls}}" viewBox="0 0 16 16" aria-hidden="true" style="margin-top:2px"><use href="#{{dbNoteIc.id}}"/></svg><span style="flex:1;min-width:0">{{dbwNote}}</span></div></sc-if>
      <div style="flex:none;padding:var(--space-3)">
        <button class="btn btn-quiet" id="btn-new"''')
P.rep("      dbNote: dbw === 'err' ?", "      dbwNote: dbw === 'err' ? 'Запись состояния недоступна: новые сессии и проекты не создаются.' : dbw === 'rec' ? 'Нужна сверка: новые сессии и проекты пока не создаются.' : '',\n      dbNote: dbw === 'err' ?")

# Дочерние страницы получают причину блокировки
P.rep('compact="{{compact}}" onCancel="{{backToDialog}}" onCreated="{{nsCreated}}"></dc-import>',
      'compact="{{compact}}" blocked="{{dbw}}" onCancel="{{backToDialog}}" onCreated="{{nsCreated}}"></dc-import>')
P.rep('compact="{{compact}}" onCancel="{{backToDialog}}" onAdded="{{apAdded}}" onNewSession="{{apNew}}"></dc-import>',
      'compact="{{compact}}" blocked="{{dbw}}" onCancel="{{backToDialog}}" onAdded="{{apAdded}}" onNewSession="{{apNew}}"></dc-import>')
P.rep('compact="{{compact}}" onBack="{{rvBack}}" onShowAll="{{rvAll}}"', 'compact="{{compact}}" blocked="{{dbw}}" onBack="{{rvBack}}" onShowAll="{{rvAll}}"')
P.rep('''wr="{{wrV}}" dbw="{{dbw}}" dbv="{{dbv}}"''', '''wr="{{wrV}}" dbw="{{dbw}}" recw="{{recw}}" onRec="{{onRec}}" dbv="{{dbv}}"''')

# --- Обработчики --------------------------------------------------------------------------------------------------------
P.rep("      const el = document.getElementById('msg'); if (!el || el.disabled) return;\n      const text = el.value.replace(/\\s+$/, ''); if (!text.trim()) return;",
      "      if (this.guardW('сообщение не отправлено')) return;\n      const el = document.getElementById('msg'); if (!el || el.disabled) return;\n      const text = el.value.replace(/\\s+$/, ''); if (!text.trim()) return;")
P.rep("canRerun: scen === 'stale' || scen === 'notrun', rerunOff: rerun === 'run',",
      "canRerun: scen === 'stale' || scen === 'notrun', rerunWhy: dbw ? dbWhyShort : '', rerunOff: rerun === 'run' || !!dbw,")
P.rep("doRerun: () => { this.setState({ rerun: 'run' });", "doRerun: () => { if (this.guardW('проверки не запущены')) return; this.setState({ rerun: 'run' });")
P.rep('''<sc-if value="{{canRerun}}"><div style="padding:0 var(--space-3)"><button class="btn" id="rerun" disabled="{{rerunOff}}" onClick="{{doRerun}}">{{rerunLabel}}</button></div></sc-if>''',
      '''<sc-if value="{{canRerun}}"><div style="padding:0 var(--space-3);display:flex;flex-direction:column;gap:var(--space-1)"><button class="btn" id="rerun" disabled="{{rerunOff}}" aria-describedby="rerun-why" onClick="{{doRerun}}" style="align-self:flex-start">{{rerunLabel}}</button><span id="rerun-why" class="muted sm">{{rerunWhy}}</span></div></sc-if>''')
P.rep("      nsCreated: (c) => { const ex = s.extra || [];", "      nsCreated: (c) => { if (this.guardW('сессия не создана')) return; const ex = s.extra || [];")
P.rep("      apAdded: () => this.setState({ added: true }),", "      apAdded: () => { if (this.guardW('проект не добавлен')) return; this.setState({ added: true }); },")
P.rep("      onRules: (next, v) => this.setState({", "      onRules: (next, v) => { if (this.guardW('правила не изменены')) return; this.setState({")
P.rep("permV === 'policy' ? 'policy' : v === 'deny' ? 'user' : v === 'allow' ? 'granted' : 'none' }),",
      "permV === 'policy' ? 'policy' : v === 'deny' ? 'user' : v === 'allow' ? 'granted' : 'none' }); },")
P.rep("      rvSend: (info) => {\n        this.setState({", "      rvSend: (info) => {\n        if (this.guardW('замечания не отправлены')) return;\n        this.setState({")
P.rep("      dlgDone: (r) => {\n", "      dlgDone: (r) => {\n        if (this.blockedNow() && MUT_KINDS.includes(r.kind)) { this.guardW('операция не выполнена'); return; }\n")
P.rep("    else if (a === 'resume') { this.setState({ stopPh: '',", "    else if (a === 'resume') { if (this.guardW('работа не возобновлена')) return; this.setState({ stopPh: '',")
P.rep("const SK = [", "const MUT_KINDS = ['perm', 'rule', 'commit', 'push', 'apply', 'bypass', 'undo', 'discard', 'checks', 'conflict', 'ctxlost'];\nconst SK = [")

# Завершение записи результата теперь выполняет приложение (recRun), а не окно
P.rep('''        else if ((r.kind === 'reconcile' || r.kind === 'manual') && r.result === 'completed') {
          if (r.saved) this.setState(Object.assign({ apState: '', scen: 'applied', applied: { sha: 'c91d2e8', bypass: false }, undone: '', liveMsg: 'Результат применения сохранён.' }, r.recovered ? { dbw: '' } : {}));
          else this.setState({ apState: 'unsaved', dbw: 'err', liveMsg: 'Git-результат подтверждён, но результат не сохранён: база не принимает запись.' });
        }
''', '')
P.rep("      onRs: (a) => this.rsAct(a),", "      onRs: (a) => this.rsAct(a),\n      recw: recHere, onRec: (op, src, seed) => this.recRun(op, src, seed),")

# --- Методы класса: охрана и ход записи (A-09) ------------------------------------------------------------------
P.rep("  curSid() { return this.state.sid ?? this.props.sess ?? 'cur'; }",
'''  curSid() { return this.state.sid ?? this.props.sess ?? 'cur'; }
  // Текущая блокировка записи (читается из состояния, а не из замыкания рендера: обработчик мог быть создан до сбоя).
  blockedNow() { const st = this.state, p = this.props; return st.dbw ?? p.dbw ?? (/^(rec|done)fail$/.test(p.dstep || '') && (st.sid ?? p.sess ?? 'cur') === 'cur' ? 'err' : ''); }
  guardW(what) {
    const d = this.blockedNow(); if (!d) return false;
    this.setState({ liveMsg: 'Действие заблокировано: ' + what + '. ' + (d === 'err' ? 'Запись состояния недоступна.' : 'Запись восстановлена, нужна сверка.') });
    return true;
  }
  // Изменение полей одной сессии (SK): если сессия открыта — setState, иначе правка её снимка в snaps.
  patchSession(sid, patch, rowFn) {
    if (sid === this.curSid()) { this.setState(patch); return; }
    const snaps = Object.assign({}, this.state.snaps), snap = Object.assign({}, snaps[sid] || {}, patch);
    if (rowFn && snap.row) snap.row = Object.assign({}, snap.row, rowFn(snap.row));
    snaps[sid] = snap; this.setState({ snaps });
  }
  // Ход записи подтверждённого применения принадлежит приложению: окно его только показывает.
  // begin — сверка подтвердила завершение, начинается запись; retry — повтор записи; sim — выбор исхода записи (только в макете).
  recRun(op, src, seed) {
    const st = this.state, p = this.props, cur = st.rec, sid = this.curSid();
    if (cur && cur.busy && op !== 'sim') return;   // вторая операция не начинается, пока идёт первая
    const base = (cur && cur.sid === sid && cur.src === src) ? cur : Object.assign({ sid, src, wp: 1, fail: false, tries: 0, sim: p.wr === 'fail' ? 'down' : 'up', busy: false, token: 0 }, seed || {});
    if (op === 'sim') { this.setState({ rec: Object.assign({}, base, { sim: seed.sim }) }); return; }
    const token = (this._recTok = (this._recTok || 0) + 1);
    if (op === 'begin') {
      const fail = (cur && cur.sid === sid ? cur.sim : base.sim) === 'down';
      this.setState({ rec: Object.assign({}, base, { wp: 1, fail: false, tries: 0, busy: true, token }), liveMsg: 'Сверка подтвердила завершение применения. Результат сохраняется.' });
      this.later(() => this.recSet(token, { wp: 2 }), 700);
      this.later(() => this.recDone(token, fail, false), 1700);
    } else if (op === 'retry') {
      const up = base.sim === 'up', n = (base.tries || 0) + 1;
      if (up) { this.setState({ rec: Object.assign({}, base, { wp: 4, tries: n, busy: true, token }), liveMsg: 'Запись восстановлена. Сверка повторяется, затем результат сохраняется.' }); this.later(() => this.recDone(token, false, true), 1100); }
      else { this.setState({ rec: Object.assign({}, base, { wp: 2, tries: n, busy: true, token }), liveMsg: 'Повторное сохранение результата.' }); this.later(() => this.recDone(token, true, false), 800); }
    }
  }
  recSet(token, patch) { const r = this.state.rec; if (r && r.token === token) this.setState({ rec: Object.assign({}, r, patch) }); }
  recDone(token, fail, recovered) {
    const r = this.state.rec; if (!r || r.token !== token) return;
    this.setState({ rec: Object.assign({}, r, { wp: 3, fail, busy: false }) });
    if (!fail) {
      this.patchSession(r.sid, { apState: '', scen: 'applied', applied: { sha: 'c91d2e8', bypass: false }, undone: '', liveMsg: 'Результат применения сохранён.' }, (o) => ({ k: 'done', meta: String(o.meta || '').replace(/[^·]*$/, ' Применено') }));
      if (recovered) this.setState({ dbw: '' });
    } else {
      this.patchSession(r.sid, { apState: 'unsaved', liveMsg: 'Git-результат подтверждён, но результат не сохранён: база не принимает запись.' }, (o) => ({ k: 'bad', meta: String(o.meta || '').replace(/[^·]*$/, ' Применено в Git · запись не сохранена') }));
      this.setState({ dbw: 'err' });
    }
  }''')
# Возврат фокуса после закрытия окна, если поле сообщения заблокировано (обнаружено регрессией B-01 на T-DbErr-Commit)
P.rep("""    this.setState({ dlg: '' }, () => { const o = this.opener; const e = o && document.getElementById(o); const t = e && !e.disabled ? e : (document.getElementById('msg') || document.getElementById('btn-new')); if (t) t.focus(); });""",
"""    // Фокус возвращается на кнопку, открывшую окно; если её нет или она недоступна — на поле сообщения, затем на заголовок сессии (поле может быть заблокировано).
    this.setState({ dlg: '' }, () => { const o = this.opener; const c = [o && document.getElementById(o), document.getElementById('msg'), document.getElementById('sess-title'), document.getElementById('btn-new')]; const t = c.find(e => e && !e.disabled); if (t) t.focus(); });""")
# Блокировка после «запись не удалась» общая, а не только у сессии, где она возникла (обнаружено регрессией A-09 при переходе в другую сессию)
P.rep("    const recFailInit = own && /^(rec|done)fail$/.test(p.dstep || '');","    const recFailG = /^(rec|done)fail$/.test(p.dstep || '');   // запись не удалась: блокировка действует во всех сессиях\n    const recFailInit = own && recFailG;")
P.rep("const dbw = s.dbw ?? p.dbw ?? (recFailInit ? 'err' : ''), dbv","const dbw = s.dbw ?? p.dbw ?? (recFailG ? 'err' : ''), dbv")
P.rep("blockedNow() { const st = this.state, p = this.props; return st.dbw ?? p.dbw ?? (/^(rec|done)fail$/.test(p.dstep || '') && (st.sid ?? p.sess ?? 'cur') === 'cur' ? 'err' : ''); }","blockedNow() { const st = this.state, p = this.props; return st.dbw ?? p.dbw ?? (/^(rec|done)fail$/.test(p.dstep || '') ? 'err' : ''); }")
# recst=busy: ход записи в ленте для статической платформы
P.rep("    const recHere = (s.rec && s.rec.sid === sid) ? s.rec : null;",
      "    // recst=busy — только для платформы: показывает ход записи в ленте без запуска таймеров\n    const recHere = (s.rec && s.rec.sid === sid) ? s.rec : (p.recst === 'busy' && own ? { sid, src: 'reconcile', wp: 2, fail: false, tries: 0, sim: 'up', busy: true, token: 0 } : null);")
P.rep('"wr":{"editor":"text","default":"ok"}','"wr":{"editor":"text","default":"ok"},"recst":{"editor":"text","default":""}')
# строка активной сессии в списке: при недоступной записи показывает то же, что её статус
P.rep("      if (id === 'cur') { const pr = SCEN_ROW[p.scenario || 'running'] || SCEN_ROW.running; const rs0 = p.stop === 'rs'; return { title: 'Гонка в очереди импорта', meta: (p.team === 'solo' ? 'Solo · ' + (p.agent || 'Claude') : 'Swarm · 4') + ' · ' + (rs0 ? 'Закрыто во время работы' : pr[0]), k: rs0 ? 'stopwarn' : pr[1] }; }", "      if (id === 'cur') {\n        const pr = SCEN_ROW[p.scenario || 'running'] || SCEN_ROW.running; const rs0 = p.stop === 'rs';\n        const dbo = !!dbw && (pr[1] === 'run');   // сессия с активным запуском: её исход зависит от записи\n        return { title: 'Гонка в очереди импорта', meta: (p.team === 'solo' ? 'Solo · ' + (p.agent || 'Claude') : 'Swarm · 4') + ' · ' + (dbo ? (dbw === 'err' ? 'Состояние не сохраняется' : 'Запись восстановлена: нужна сверка') : rs0 ? 'Закрыто во время работы' : pr[0]), k: dbo ? (dbw === 'err' ? 'stoperr' : 'stopwarn') : rs0 ? 'stopwarn' : pr[1] };\n      }")

# статус, действия инспектора и причина блокировки «Применить» показывают, что результат применения сохраняется
for _o, _n in [("apState === 'interrupted' ? 'Применение прервано: сначала нужна сверка состояния.' :", "apState === 'interrupted' ? (recBusyHere ? 'Применение уже подтверждено сверкой: результат сохраняется, повтор не нужен.' : 'Применение прервано: сначала нужна сверка состояния.') :"), ("    if (apState === 'interrupted') actions.unshift({ id: 'act-recon', label: 'Сверить состояние…', cls: 'btn-primary', off: false, why: 'Только читает состояние Git; ничего не откатывает и не повторяет.',", "    if (apState === 'interrupted') actions.unshift({ id: 'act-recon', label: recBusyHere ? 'Показать ход записи…' : 'Сверить состояние…', cls: 'btn-primary', off: false, why: recBusyHere ? 'Запись идёт и без окна; вторая запись не начинается.' : 'Только читает состояние Git; ничего не откатывает и не повторяет.',"), ("    if (apState === 'interrupted') stRow = ['Применение прервано', 'bad'];", "    if (apState === 'interrupted') stRow = recBusyHere ? ['Применено в Git · результат сохраняется', 'stopreq'] : ['Применение прервано', 'bad'];")]:
    P.rep(_o, _n)
P.rep("      const recHere = (s.rec && s.rec.sid === sid)", "      const recHere = (s.rec && s.rec.sid === sid)") if False else None
P.s = P.s.replace("    const recHere = (s.rec && s.rec.sid === sid) ? s.rec : (p.recst === 'busy' && own ? { sid, src: 'reconcile', wp: 2, fail: false, tries: 0, sim: 'up', busy: true, token: 0 } : null);\n", "    const recHere = (s.rec && s.rec.sid === sid) ? s.rec : (p.recst === 'busy' && own ? { sid, src: 'reconcile', wp: 2, fail: false, tries: 0, sim: 'up', busy: true, token: 0 } : null);\n    const recBusyHere = !!(recHere && recHere.busy);\n", 1)
P.rep("""        onResume: () => this.setState({ stopPh: '', scen: 'running', rs: undefined }, () => F('msg')) });
      tl.push(sb);""","""        onResume: () => this.setState({ stopPh: '', scen: 'running', rs: undefined }, () => F('msg')) });
      if (dbw) { sb.resumeOff = true; sb.resumeWhy = dbWhyShort; sb.onResume = () => { this.guardW('работа не возобновлена'); }; }   // возобновление — новый ход: при недоступной записи заблокировано
      tl.push(sb);""")
# пустые пояснения не рендерятся: без отказа записи вёрстка прежняя (обнаружено сравнением отрисовки v14/v15: V-Sess-Par-Light)
P.rep('''<button class="btn" id="cancel-wait" style="margin-top:var(--space-2)" disabled="{{b.cancelOff}}" aria-describedby="cancel-why" onClick="{{b.cancel}}">Отменить ожидание</button>
                  <div id="cancel-why" class="sm muted" style="margin-top:var(--space-1)">{{b.cancelWhy}}</div>''',
'''<button class="btn" id="cancel-wait" style="margin-top:var(--space-2)" disabled="{{b.cancelOff}}" aria-describedby="{{b.cancelDesc}}" onClick="{{b.cancel}}">Отменить ожидание</button>
                  <sc-if value="{{b.cancelWhy}}"><div id="cancel-why" class="sm muted" style="margin-top:var(--space-1)">{{b.cancelWhy}}</div></sc-if>''')
P.rep("cancelOff: !!dbw, cancelWhy: dbw ? dbWhyShort : '' });","cancelOff: !!dbw, cancelWhy: dbw ? dbWhyShort : '', cancelDesc: dbw ? 'cancel-why' : undefined });")
P.rep('''<div style="padding:0 var(--space-3);display:flex;flex-direction:column;gap:var(--space-1)"><button class="btn" id="rerun" disabled="{{rerunOff}}" aria-describedby="rerun-why" onClick="{{doRerun}}" style="align-self:flex-start">{{rerunLabel}}</button><span id="rerun-why" class="muted sm">{{rerunWhy}}</span></div>''',
'''<div style="padding:0 var(--space-3);display:flex;flex-direction:column;gap:var(--space-1)"><button class="btn" id="rerun" disabled="{{rerunOff}}" aria-describedby="{{rerunDesc}}" onClick="{{doRerun}}" style="align-self:flex-start">{{rerunLabel}}</button><sc-if value="{{rerunWhy}}"><span id="rerun-why" class="muted sm">{{rerunWhy}}</span></sc-if></div>''')
P.rep("rerunWhy: dbw ? dbWhyShort : '', rerunOff:","rerunWhy: dbw ? dbWhyShort : '', rerunDesc: dbw ? 'rerun-why' : undefined, rerunOff:")
P.rep("const anyBad = teamBad || checksBad || !!apState;","const anyBad = teamBad || checksBad || (!!apState && !recBusyHere);")
P.rep("(apState === 'interrupted' || apState === 'ambiguous') ? 'Применение прервано: сначала установите исход. Ничего не удаляем.'","recBusyHere ? 'Применение подтверждено, результат сохраняется: дождитесь записи. Ничего не удаляем.' : (apState === 'interrupted' || apState === 'ambiguous') ? 'Применение прервано: сначала установите исход. Ничего не удаляем.'")
P.rep("а не только в этой. Активного запуска здесь нет, статус сессии не менялся.')", "а не только в этой.' + (apState === 'unsaved' ? '' : ' Активного запуска здесь нет, статус сессии не менялся.'))")
P.rep("composePh: dbw ? 'Состояние не сохраняется: сообщения пока не принимаются' :","composePh: dbw === 'rec' ? 'Запись восстановлена: нужна сверка, сообщения пока не принимаются' : dbw ? 'Состояние не сохраняется: сообщения пока не принимаются' :")
P.rep("hintText: dbw ? 'Сообщения и ходы заблокированы до восстановления записи и сверки' :","hintText: dbw === 'rec' ? 'Сообщения и ходы заблокированы до сверки' : dbw ? 'Сообщения и ходы заблокированы до восстановления записи и сверки' :")
P.rep("if (dbw) help = 'Сообщения не принимаются, пока запись состояния недоступна.';","if (dbw) help = dbw === 'rec' ? 'Сообщения не принимаются, пока не выполнена сверка.' : 'Сообщения не принимаются, пока запись состояния недоступна.';")
P.save()
