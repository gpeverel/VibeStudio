# -*- coding: utf-8 -*-
# Упаковывает каталог комплекта в JSON-пакет для страницы комплекта (страница собирает из него ZIP в браузере).
#   python3 tools/mkbundle.py <каталог_комплекта> <выходной.json> <метка> [--skip-png]
# PNG не встраиваются (лежат отдельными файлами страницы), но остаются в MANIFEST.json, который входит в пакет как обычный файл.
import base64, hashlib, json, os, sys
root, out, label = sys.argv[1:4]
skip_png = '--skip-png' in sys.argv
files = []
for d, _, fs in os.walk(root):
    for f in sorted(fs):
        p = os.path.relpath(os.path.join(d, f), root).replace(os.sep, '/')
        if skip_png and p.lower().endswith('.png'): continue
        b = open(os.path.join(d, f), 'rb').read()
        e = {'path': p, 'size': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
        try: e['data'] = b.decode('utf-8'); e['enc'] = 'utf8'
        except UnicodeDecodeError: e['data'] = base64.b64encode(b).decode('ascii'); e['enc'] = 'b64'
        files.append(e)
files.sort(key=lambda e: e['path'])
json.dump({'label': label, 'files': files}, open(out, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
print(out, len(files), 'файлов', os.path.getsize(out), 'байт')
