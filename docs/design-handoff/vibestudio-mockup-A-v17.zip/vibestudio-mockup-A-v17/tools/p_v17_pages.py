# -*- coding: utf-8 -*-
# Правки Review.dc.html версии 17 (написаны заново). Применяются к Review.dc.html версии 16:
#   python3 -I tools/p_v17_pages.py project/Review.dc.html
# Находка проверки минимального окна 640×480 при масштабе 200% (tests/ui7/zoom200.mjs): при ширине 320 CSS px закреплённые
# шапка ревью (путь, вкладки фильтра) и подвал (сводка, отправка) занимали всю высоту, и область diff сжималась до 0 px —
# изменения и замечания нельзя было ни увидеть, ни выбрать. Теперь область diff не ниже 160 CSS px (около семи строк),
# а если места не хватает, прокручивается вся страница ревью. При обычных размерах раскладка не меняется.
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pt import Patch
P = Patch(sys.argv[1])
P.rep('<div id="rv-scroll" style="flex:1;min-height:0;overflow:auto">', '<div id="rv-scroll" style="flex:1;min-height:160px;overflow:auto">')
P.rep("rootStyle: 'height:100%;display:flex;flex-direction:column;min-height:0;background:var(--color-bg);--pad:' + pad,",
      "rootStyle: 'height:100%;display:flex;flex-direction:column;min-height:0;overflow-y:auto;background:var(--color-bg);--pad:' + pad,")
P.save()
