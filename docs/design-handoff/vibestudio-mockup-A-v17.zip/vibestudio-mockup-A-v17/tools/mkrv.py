# -*- coding: utf-8 -*-
# Обёртки RV-<имя>-<тема> для просмотра глазами: каждая платформа этапов 4–5 в обеих темах. python3 tools/mkrv.py → project/RV-*.dc.html и review/rv.json
import re, glob, os, json
names = []
for f in sorted(glob.glob('project/*.dc.html')):
    n = os.path.basename(f)[:-8]
    if re.match(r'^(X-|Y-|L-Rules|V-Sess|W-|Z640|Z500|AR-|E-DbErr|E-DbRec|G-Orphan|Q-PCtx|P-Rule|P-Denied|P-Perm|A-Recon)', n): names.append(n)
for f in glob.glob('project/RV-*.dc.html'): os.remove(f)
os.makedirs('review', exist_ok=True)
out = []
for n in names:
    s = open('project/%s.dc.html' % n, encoding='utf-8').read()
    title = re.search(r'<title>(.*?)</title>', s).group(1)
    for t in ('dark', 'light'):
        rn = 'RV-%s-%s' % (n, t)
        s2 = re.sub(r'(<dc-import name="App" theme=")(dark|light)(")', r'\g<1>%s\3' % t, s).replace('<title>%s</title>' % title, '<title>%s</title>' % rn)
        open('project/%s.dc.html' % rn, 'w', encoding='utf-8').write(s2)
        w = int(re.search(r' w="(\d+)"', s2).group(1)); h = int(re.search(r' h="(\d+)"', s2).group(1))
        out.append(dict(name=rn, base=n, theme=t, w=w, h=h))
json.dump(out, open('review/rv.json', 'w'), ensure_ascii=False)
print(len(names), 'платформ,', len(out), 'снимков')
