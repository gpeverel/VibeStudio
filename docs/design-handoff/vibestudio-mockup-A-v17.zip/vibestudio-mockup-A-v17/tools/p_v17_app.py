# -*- coding: utf-8 -*-
# Правки App.dc.html версии 17 (написаны заново). Применяются к App.dc.html версии 16:
#   python3 -I tools/p_v17_app.py project/App.dc.html
# Находка проверки минимального окна 640×480 при настоящем масштабе браузера 200% (tests/ui7/zoom200.mjs): область окна
# 320×196 CSS px. Шапка, подвалы окон и поле сообщения закреплены, поэтому кнопки форм и окон и часть текста уходили за
# нижний край без прокрутки. При ширине 320 шапка, строка контекста и поле сообщения переносятся в несколько строк, и даже
# при высоте 320–400 для ленты оставалось 0–30 px. Теперь при ширине области меньше 400 CSS px (минимальное окно при
# масштабе от 175%) раскладка не ниже 440 CSS px, а окно прокручивается целиком: колесом мыши и переводом фокуса
# клавиатурой. Более широкие области не меняются: 720×406 (1440×900 при 200%) и 500×316 (1000×720 при 200%) проверены
# с прежней раскладкой; при 100% минимальное окно шире 400, и раскладка прежняя.
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pt import Patch
P = Patch(sys.argv[1])
P.rep("    const w = +p.w || 1440, h = +p.h || 900;\n",
      "    // узкая область (меньше 400 CSS px — минимальное окно при масштабе от 175%): строки переносятся, поэтому раскладка\n"
      "    // не ниже 440 CSS px, а окно прокручивается целиком\n"
      "    const w = +p.w || 1440, h = w < 400 ? Math.max(+p.h || 900, 440) : (+p.h || 900);\n")
# Находка той же проверки: при переходе клавишей Tab Chrome не докручивает многострочное поле, если видна строка с курсором,
# поэтому поле сообщения и поле причины в окне при высоте 196 CSS px оставались видны наполовину. Текстовое поле, получившее
# фокус, докручивается в видимую область (block: 'nearest' — без сдвига, если поле уже видно целиком).
P.rep('<div class="app" data-theme="{{theme}}" style="{{rootStyle}}">', '<div class="app" data-theme="{{theme}}" style="{{rootStyle}}" onFocus="{{fieldFocus}}">')
P.rep("      theme, rootStyle, inBodyStyle,", "      fieldFocus: (e) => { const t = e.target; if (t && t.matches && t.matches('textarea, input:not([type]), input[type=\"text\"], input[type=\"search\"]')) t.scrollIntoView({ block: 'nearest' }); },\n      theme, rootStyle, inBodyStyle,")
# Решения 1 и 2 согласованы 27.10.2026 и внесены в src/renderer/styles/tokens.css: --color-border-strong больше не
# «предлагаемый», затемнение под окнами берёт --color-scrim (то же значение: --color-bg при прозрачности 0,72).
P.rep("/* Значения копируют src/renderer/styles/tokens.css. Новых токенов нет. Тема переключается атрибутом data-theme. */",
      "/* Значения копируют src/renderer/styles/tokens.css, включая согласованные 27.10.2026 --color-border-strong и --color-scrim. Тема переключается атрибутом data-theme. */")
P.rep("  --color-border-strong:#6f6f69; /* ПРЕДЛАГАЕМЫЙ токен: границы полей ввода, не для текста */\n",
      "  --color-border-strong:#6f6f69; /* только границы полей ввода, не для текста */\n  --color-scrim:rgba(21, 21, 20, 0.72);\n")
P.rep("  --color-border-strong:#858580;\n}", "  --color-border-strong:#858580;\n  --color-scrim:rgba(250, 250, 249, 0.72);\n}")
P.rep(".scrim{position:absolute;inset:0;z-index:39;background:var(--color-bg);opacity:.72}", ".scrim{position:absolute;inset:0;z-index:39;background:var(--color-scrim)}")
P.save()
