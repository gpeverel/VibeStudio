# -*- coding: utf-8 -*-
# Обновляет project/canvas.json версии 12 → версия 14: платформы этапа 5, высоты и положение документов, заметки.
# Запуск из каталога сборки после tools/gen_handoff5.py и tests/heights.mjs: python3 tools/update_canvas5.py
import json, sys
sys.path.insert(0, 'tools')
from mkboards5 import BOARDS
C = json.load(open('project/canvas.json', encoding='utf-8'))
H = json.load(open('tests/results/heights.json', encoding='utf-8'))   # Handoff1..3, Map, Trace, Prop2
B, O, N = C['boards'], C['order'], C['notes']
def put(name, x, y, w, h, title, interactive=False):
    d = {'x': x, 'y': y, 'w': w, 'h': h, 'title': title}
    if interactive: d['is_interactive'] = True
    B[name] = d
    if name not in O: O.append(name)
# --- документы: высоты и положение
DX = 17460
put('M-Map.dc.html', DX, 0, 1440, H['Map'], 'Карта экранов и переходов (этапы 2–5)')
put('M-Trace.dc.html', DX, H['Map'] + 120, 1440, H['Trace'], 'Основания в SPEC: элемент → действие → строки SPEC → тип (этапы 2–5)')
put('M-Prop2.dc.html', DX, H['Map'] + H['Trace'] + 240, 1440, H['Prop2'], 'Дополнения к контракту, этапы 2–5 (не часть макета)')
y = 0
for k, ttl in (('Handoff1', 'Пакет передачи 1: карта экранов и состояния'), ('Handoff2', 'Пакет передачи 2: компоненты и дополнения к контракту'), ('Handoff3', 'Пакет передачи 3: визуальные материалы, проверки и решения')):
    n = k.replace('Handoff', 'H')
    put('%s-Dark.dc.html' % n, 19020, y, 1440, H[k], ttl + ' · тёмная')
    put('%s-Light.dc.html' % n, 20580, y, 1440, H[k], ttl + ' · светлая')
    y += H[k] + 120
# --- платформы этапа 5
COLX = [22140, 23700, 25260]
ROWS = [
 ('Запись результата подтверждённого применения: сохраняется · сохранён · запись не удалась', ['AR-Seq-Dark', 'AR-Saved-Light', 'AR-Fail-Dark']),
 ('Разбор применения: завершено и сохранено · запись не удалась · применено в Git, запись не сохранена', ['AR-ManualDone-Light', 'AR-ManualFail-Dark', 'AR-Unsaved-Banner-Light']),
 ('Ошибка записи состояния: окно · остановка идёт · подтверждена не у всех', ['E-DbErr-Dialog-Dark', 'E-DbErr-Active-Light', 'E-DbErr-Mixed-Dark']),
 ('Ошибка записи состояния: сессия заблокирована · Solo · применение завершено, запись не сохранена', ['E-DbErr-Banner-Light', 'E-DbErr-Solo-Dark', 'E-DbErr-Unsaved-Dark']),
 ('Восстановление записи: нужна сверка · сверка выполнена · список проектов с найденной рабочей копией', ['E-DbErr-Recovered-Light', 'E-DbErr-Reconciled-Dark', 'G-Orphan-Sidebar-Dark']),
 ('Рабочая копия без сессии: владелец известен · не установлен · повторная сверка', ['G-Orphan-Known-Light', 'G-Orphan-Unknown-Dark', 'G-Orphan-Recheck-Dark']),
 ('Рабочая копия: сведения и сводка · в окне восстановления · диалог участника в окне восстановления', ['G-Orphan-Details-Light', 'G-Orphan-Restart-Light', 'Q-PCtx-Restart-Light']),
 ('Недоступный диалог участника Swarm: баннер · подтверждение · новый диалог создан', ['Q-PCtx-Banner-Dark', 'Q-PCtx-Confirm-Dark', 'Q-PCtx-Done-Light']),
 ('Правила: новое разрешение · новый запрет · ошибка в шаблоне', ['L-Rules-New-Dark', 'L-Rules-NewDeny-Light', 'L-Rules-Error-Dark']),
 ('Правила: изменение запрета · удаление запрета · разрешение перекрыто запретом', ['L-Rules-Edit-Dark', 'L-Rules-Delete-Light', 'L-Rules-Shadowed-Light']),
 ('Правила: было и стало', ['L-Rules-Changed-Dark', 'L-Rules-ChangedAllow-Light']),
]
info = {n: (t, th, w, h) for n, t, th, d, w, h in BOARDS}
for ri, (label, names) in enumerate(ROWS):
    ry = ri * 1020
    for ci, nm in enumerate(names):
        t, th, w, h = info[nm]
        put(nm + '.dc.html', COLX[ci], ry, w, h, t, True)
    if ri > 0: N['s5r%d' % ri] = {'x': COLX[0], 'y': ry - 70, 'text': label, 'w': 1400, 'size': 'm'}
ry = len(ROWS) * 1020
N['s5z'] = {'x': COLX[0], 'y': ry - 70, 'text': 'Тесное окно: 640×480 — существующий минимум окна (`minWidth` и `minHeight` в src/main/index.ts); это размер окна, а не области содержимого. 500×360 — дополнительная проверка, не требование и не проверка масштаба 200%.', 'w': 1400, 'size': 'm'}
x = COLX[0]
for nm in ['Z640-AutoRec-Dark', 'Z640-DbErr-Light', 'Z640-Orphan-Dark', 'Z640-PCtx-Light', 'Z640-RulesForm-Dark', 'Z500-DbErr-Light']:
    t, th, w, h = info[nm]
    put(nm + '.dc.html', x, ry, w, h, t, True); x += w + 120
N['t5'] = {'x': COLX[0], 'y': -300, 'text': 'Версия 14: запись результата применения, ошибка записи состояния, рабочая копия без сессии, диалог участника Swarm, управление правилами. Документы и пакет передачи — левее (x от 17460)', 'kind': 'title1', 'maxW': 4800}
N['n10'] = {'x': COLX[0], 'y': -150, 'text': 'Платформы с живыми окнами: клики и клавиатура работают; процессы, Git, CLI, база и хранилище правил подставлены (имитация). В окнах, где состояние записи или результат сверки выбираются, есть пометка «Только в макете». Макет не доказывает готовность реализации. Редактируемый комплект исходников и проверок — на странице комплекта (ссылка в пакете передачи, лист 3).', 'w': 1400, 'size': 'm'}
N['n9']['text'] = 'Карта экранов, основания в SPEC и дополнения к контракту обновлены на этапах 4–5 и лежат правее, рядом с пакетом передачи (x от 17460).'
N['t4']['text'] = 'Этап 4: восстановление после перезапуска, разбор применения, правила, навигация. Этап 5 — в колонках x от 22140. Документы и пакет передачи — между ними'
N['n5']['text'] = N['n5']['text'].replace('оба листа обновлены на этапе 4 и лежат правее (x от 17460)', 'оба листа обновлены на этапах 4–5 и лежат правее (x от 17460)')
# --- компонентные доски: положение важно на холсте
def moveb(name, x, yy, h=None):
    if name in B:
        B[name]['x'] = x; B[name]['y'] = yy
        if h: B[name]['h'] = h
base_y = 26340
moveb('Map.dc.html', 1560, base_y, H['Map'])
moveb('Trace.dc.html', 1560, base_y + H['Map'] + 120, H['Trace'])
moveb('Prop2.dc.html', 1560, base_y + H['Map'] + H['Trace'] + 240, H['Prop2'])
y2 = base_y + H['Map'] + H['Trace'] + H['Prop2'] + 360
moveb('AddProject.dc.html', 1560, y2); y2 += 820
for k in ('Handoff1', 'Handoff2', 'Handoff3'):
    moveb(k + '.dc.html', 1560, y2, H[k]); y2 += H[k] + 120
# --- обёртки листов: высота в dc-import и в предпросмотре
import re
def rewrap(fn, h):
    p = 'project/' + fn
    t = open(p, encoding='utf-8').read()
    t = re.sub(r'(<dc-import name="[A-Za-z0-9]+" theme="(?:dark|light)") h="\d+" hint-size="1440px,\d+px"', r'\1 h="%d" hint-size="1440px,%dpx"' % (h, h), t)
    t = re.sub(r'\{"\$preview":\{"width":1440,"height":\d+\}\}', '{"$preview":{"width":1440,"height":%d}}' % h, t)
    open(p, 'w', encoding='utf-8').write(t)
for k in ('Handoff1', 'Handoff2', 'Handoff3'):
    n = k.replace('Handoff', 'H')
    for th in ('Dark', 'Light'): rewrap('%s-%s.dc.html' % (n, th), H[k])
for nm, k in (('M-Map', 'Map'), ('M-Trace', 'Trace'), ('M-Prop2', 'Prop2')): rewrap(nm + '.dc.html', H[k])
json.dump(C, open('project/canvas.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('boards', len(B), 'order', len(O), 'notes', len(N))
