#!/bin/sh
# Локальный просмотр макета и запуск проверок: sh tools/serve.sh
# Корень сервера — каталог комплекта; страницы по адресу http://127.0.0.1:8765/project/Main.dc.html
cd "$(dirname "$0")/.." && exec python3 -m http.server 8765 --bind 127.0.0.1
