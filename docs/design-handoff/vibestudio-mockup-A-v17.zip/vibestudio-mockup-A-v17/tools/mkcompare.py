# -*- coding: utf-8 -*-
# Список платформ для сравнения отрисовки версий (tests/rvdiff.mjs): review/compare.json = все платформы приложения (обёртки App) в их теме
# плюс обе темы платформ просмотра (review/rv.json). python3 tools/mkcompare.py  (после tools/mkrv.py)
import glob, json, os, re
rv = json.load(open('review/rv.json', encoding='utf-8'))
out = list(rv); seen = {b['base'] for b in rv}
for f in sorted(glob.glob('project/*.dc.html')):
    n = os.path.basename(f)[:-8]
    if re.match(r'^(T-|RV-|Handoff|H[123]-)', n) or n in seen: continue
    s = open(f, encoding='utf-8').read()
    if '<dc-import name="App"' not in s: continue
    w = int(re.search(r' w="(\d+)"', s).group(1)); h = int(re.search(r' h="(\d+)"', s).group(1)); t = re.search(r' theme="(dark|light)"', s).group(1)
    out.append(dict(name=n, base=n, theme=t, w=w, h=h))
json.dump(out, open('review/compare.json', 'w', encoding='utf-8'), ensure_ascii=False)
print(len(out), 'платформ для сравнения')
