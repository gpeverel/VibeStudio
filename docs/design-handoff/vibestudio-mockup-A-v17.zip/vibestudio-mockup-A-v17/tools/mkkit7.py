# -*- coding: utf-8 -*-
# Собирает каталог комплекта версии 16 и MANIFEST.json (создан из mkkit6.py версии 15: добавлены tests/ui7, proposals/,
# доказательства версии 16; тексты README и PROVENANCE версии 16).
#   python3 tools/mkkit7.py <каталог_назначения> --results <каталог_результатов> --evidence <каталог_доказательств> --shots <каталог_снимков>
# MANIFEST.json перечисляет ВСЕ файлы комплекта, включая PNG, с размером и SHA-256. Единственное исключение — сам MANIFEST.json (самоссылка).
import os, re, shutil, json, sys, hashlib

def arg(name, default=None):
    return sys.argv[sys.argv.index('--' + name) + 1] if ('--' + name) in sys.argv else default
dest = [a for a in sys.argv[1:] if not a.startswith('--')][0]
RES, EVI, SHOTS = arg('results', 'tests/results'), arg('evidence', 'tests/evidence'), arg('shots', 'tests/shots/rv')
if os.path.exists(dest): shutil.rmtree(dest)
def mk(*d): os.makedirs(os.path.join(dest, *d), exist_ok=True)
def cp(src, dst):
    mk(os.path.dirname(dst)); shutil.copy(src, os.path.join(dest, dst))

# project: страницы приложения и документов, холст, рантайм (обёртки T-* и RV-* создаются сценариями и в комплект не входят)
for f in sorted(os.listdir('project')):
    if re.match(r'^(T-|RV-)', f): continue
    if f.endswith('.dc.html') or f in ('canvas.json', 'support.js'): cp('project/' + f, 'project/' + f)
# tools
for f in sorted(os.listdir('tools')):
    p = os.path.join('tools', f)
    if os.path.isfile(p) and not f.endswith('.pyc'): cp(p, 'tools/' + f)
# tests: сценарии, обвязка, самопроверка
for f in ('cdp.mjs', 'tlib.mjs', 'suite5.mjs', 'suite6.mjs', 'selftest.mjs', 'scan5.mjs', 'shots.mjs', 'rvshots.mjs', 'rvdiff.mjs', 'tokens5.mjs', 'heights.mjs', 'montage.mjs', 'verify-run.mjs', 'run-all.sh', 'steps.txt', 'expected.json', 'README.md', 'tokens5.json', 'visual-review.json', 'visual-review-v16.json', 'play-check.json'):
    if os.path.exists('tests/' + f): cp('tests/' + f, 'tests/' + f)
for f in sorted(os.listdir('tests/selftest')): cp('tests/selftest/' + f, 'tests/selftest/' + f)
for f in sorted(os.listdir('tests/ui7')):
    if f.endswith('.mjs'): cp('tests/ui7/' + f, 'tests/ui7/' + f)
# предлагаемые изменения tokens.css и DESIGN.md (для просмотра, не внесены в репозиторий)
for f in sorted(os.listdir('proposals')): cp('proposals/' + f, 'proposals/' + f)
for f in ('t7.mjs', 't8.mjs', 't9.mjs', 't10.mjs', 't11.mjs', 't12.mjs', 'tlib.mjs', 'cdp.mjs', 'CHANGES.md'): cp('tests/legacy/' + f, 'tests/legacy/' + f)
# результаты прогона на распакованной копии (получены ПОСЛЕ сборки: добавляются в комплект как данные) и доказательства «до»
for root, _, files in os.walk(RES):
    for f in files:
        rel = os.path.relpath(os.path.join(root, f), RES)
        cp(os.path.join(root, f), 'tests/results/' + rel)
if os.path.isdir(EVI):
    for root, _, files in os.walk(EVI):
        for f in files:
            rel = os.path.relpath(os.path.join(root, f), EVI)
            cp(os.path.join(root, f), 'tests/evidence/' + rel)
if os.path.exists('review/rv.json'): cp('review/rv.json', 'review/rv.json')
# visual: ключевые состояния версии 15, обе темы, 1:1
VIS = json.load(open('tools/visual_list.json', encoding='utf-8'))
idx = []
for name, title in VIS:
    have = True
    for t in ('dark', 'light'):
        src = os.path.join(SHOTS, 'RV-%s-%s.png' % (name, t))
        if not os.path.exists(src): have = False; print('нет снимка', src)
    if not have: continue
    for t in ('dark', 'light'): cp(os.path.join(SHOTS, 'RV-%s-%s.png' % (name, t)), 'visual/%s-%s.png' % (name, t))
    idx.append({'name': name, 'title': title})
mk('visual'); json.dump(idx, open(os.path.join(dest, 'visual/index.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# --- состав и числа для README
def allfiles():
    out = []
    for root, _, files in os.walk(dest):
        for f in files: out.append(os.path.relpath(os.path.join(root, f), dest).replace(os.sep, '/'))
    return sorted(out)
pre = [p for p in allfiles()]
n_png_pre = sum(1 for p in pre if p.endswith('.png'))
def count(prefix): return sum(1 for p in pre if p.startswith(prefix))
n_total = len(pre) + 2   # + README.md и PROVENANCE.md, создаваемые ниже (MANIFEST.json не считается)
n_png = n_png_pre
README = """# VibeStudio · макет A «Три панели» · версия 16

Редактируемый комплект дизайн-макета: страницы, раскладка холста, платформенный рантайм, скрипты сборки и проверок, результаты прогона, доказательства «до», снимки ключевых состояний и предлагаемые изменения контракта. Репозиторий VibeStudio, DESIGN.md и tokens.css этот комплект не затрагивает; макет — не реализация приложения: UI сессий в коде нет (лист 4 пакета передачи, раздел «Состояние реализации»).

Версия 16 выпущена по замечаниям независимого ревью Version 17 (публикация версии 15). Версии 15 и 14 сохранены неизменными пакетами на странице комплекта (`bundles/v15-final.json`, `bundles/v14-final.json`).

**Нумерация.** «Версия 16» — номер ревизии макета и этого комплекта; номер публикации на платформе (Version N) указан на странице комплекта и в сверке опубликованных файлов (`verify/v16-published-compare.json`, вне архива).

## Состав

| Каталог | Файлов | Содержимое |
|---|---|---|
| `project/` | %(project)d | Страницы `.dc.html`: приложение (`App`, `Ops`, `NewSession`, `AddProject`, `Review`), документы (`Map`, `Trace`, `Prop2`, `Proposals`, `Handoff1–4`), платформы-обёртки, `canvas.json`, `support.js` (платформенный рантайм) |
| `tools/` | %(tools)d | Скрипты сборки, правок и проверки комплекта; происхождение — в `tools/README.md` |
| `tests/` | %(tests)d | Сценарии, самопроверка обвязки, автоскан, набор версии 16 `tests/ui7`, результаты прогона в `tests/results/`, доказательства в `tests/evidence/`; описание — `tests/README.md` |
| `proposals/` | %(proposals)d | Точные предлагаемые изменения `tokens.css` и `DESIGN.md` (патчи); не внесены, ждут согласования |
| `visual/` | %(visual)d | Снимки ключевых состояний при 1:1 в обеих темах (PNG) и `index.json` |
| `review/` | %(review)d | Список платформ просмотра |
| корень | 2 | `README.md`, `PROVENANCE.md` |

Всего файлов в комплекте, не считая `MANIFEST.json`: **%(total)d**, в том числе PNG: **%(png)d**.

## Манифест

`MANIFEST.json` — список `{path, size, sha256}` для каждого файла комплекта, включая PNG и этот README. **Исключён только сам `MANIFEST.json`** (он не может содержать собственную сумму). Сверка:

```sh
python3 -I tools/verify_kit.py .      # из каталога распакованного комплекта; код возврата 0 — всё совпало
```

## Как запустить проверки

Распакуйте комплект в отдельный каталог. Нужны Node 22+, Python 3, Google Chrome и пакет `playwright` (каталог пакета — в `PLAYWRIGHT_DIR`).

```sh
PLAYWRIGHT_DIR=<каталог playwright> sh tests/run-all.sh      # VIBESTUDIO_REPO=<репозиторий> — сверка листов с кодом
```

Код возврата 0 — только при полном успешном прогоне. Порты: `MOCKUP_PORT` и `CDP_PORT` из окружения; если их нет, скрипт выбирает свободные (так и было в итоговом прогоне — с разрешения пользователя, порты окружением не выделялись). Набор `tests/ui7` портов не использует.

## Что здесь не так, как кажется

- Исходная сборка версий 10–12 утрачена; версия 16 получена правкой файлов версии 15. Источник правды — `project/`. Скрипты `tools/p_v16_*.py` описывают правки версии 16 и проверены на воспроизведение (`tools/README.md`).
- Скрипты `tests/legacy/` извлечены из журнала рабочей сессии и изменены; это не восстановленный прежний набор тестов.
- `support.js` — копия платформенного `artifact-type/dc-runtime.js`; `canvas.json` платформа может переписывать. Совпадение с опубликованной версией проверено на дату публикации.
- VoiceOver не проверялся; дерево доступности Chrome его не заменяет. Проверка браузерного макета на macOS — не приёмка нативного поведения Electron-приложения.
"""
PROV = """# Происхождение файлов, версия 16

## project/
- Страницы приложения и документов: пакет версии 15 (`bundles/v15-final.json`; опубликован как Version 17, `1792286621-25ae`) плюс правки версии 16 (`tools/p_v16_*.py`, генератор листов `tools/gen_handoff7.py`, холст `tools/update_canvas7.py`). Версия 15 — правка опубликованной версии 14 (`1792072575-8814`), та — правка опубликованной версии 12 (`1791973368-bfe9`). Исходная сборка версий 10–12 (каталог `src/`, `build.py` и др.) находилась во временной папке сессии, была очищена и **не восстановлена**.
- Рабочий каталог версии 15 тоже находился во временной папке и к началу работы над версией 16 был пуст: версия 15 восстановлена с опубликованной страницы комплекта (пакет и 66 снимков) и сверена с её MANIFEST.json (374 файла, расхождений нет).
- Платформы-обёртки создаёт `tools/mkboards5.py`; обёртки `T-*` и `RV-*` в комплект не входят. `support.js` — копия `artifact-type/dc-runtime.js` опубликованной версии.
- Основание документов: `docs/SPEC.md` на коммите 07776e2 (15.10.2026), состояние кода — репозиторий на 749f040 (19.10.2026), сверено 25.10.2026 (`tools/basis.json`).

## tools/ и tests/
Таблица происхождения — в `tools/README.md` и `tests/README.md`. Коротко:
- извлечены из журнала сессии без изменений: `tools/gen_handoff_v12.py`, `tools/pt.py`;
- извлечены из журнала и изменены: `tests/legacy/t7–t12.mjs` (`tests/legacy/CHANGES.md`);
- написаны заново при подготовке версий 14, 15 и 16: остальные файлы; в версии 16 — `tests/ui7/*`, `tools/p_v16_*.py`, `tools/mkv16.py`, `tools/p_gen7.py`, `tools/mkproposals.py`, `tools/update_canvas7.py`, `tools/mkkit7.py`, `tools/basis.json`; расширены `tools/check_docs15.py`, `tests/run-all.sh` (шаги `ui7-*`, `docs`), `tests/expected.json`.

## tests/evidence/
- `v14-before/`, `v14-baseline-new-harness/`, `v15-after/` — как в версии 15; `v15-after/play-check-v17.json` — Play-проверка Version 17 (нажатия через DOM click(), историческая).
- `v15-before/` — проверки версии 16 на неизменённой версии 15: настоящий масштаб 200%, дерево доступности, правила сверки документов (находят то, что исправлено в версии 16).

## visual/
Снимки сделаны `tests/ui7/rvshots.mjs` (Playwright, Chrome) на страницах версии 16, 1440×900 и 640×480.
"""
mk('.')
open(os.path.join(dest, 'README.md'), 'w', encoding='utf-8').write(README % dict(project=count('project/'), tools=count('tools/'), tests=count('tests/'), visual=count('visual/'), review=count('review/'), proposals=count('proposals/'), total=n_total, png=n_png))
open(os.path.join(dest, 'PROVENANCE.md'), 'w', encoding='utf-8').write(PROV)

# --- манифест: все файлы, кроме самого MANIFEST.json
files = [p for p in allfiles() if p != 'MANIFEST.json']
assert len(files) == n_total, (len(files), n_total)
man = []
for p in files:
    b = open(os.path.join(dest, p), 'rb').read()
    man.append({'path': p, 'size': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
json.dump(man, open(os.path.join(dest, 'MANIFEST.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('комплект:', dest, '· файлов', len(man), '· PNG', sum(1 for m in man if m['path'].endswith('.png')), '· состояний', len(idx))
