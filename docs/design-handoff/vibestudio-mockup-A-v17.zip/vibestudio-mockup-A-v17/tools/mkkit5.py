# -*- coding: utf-8 -*-
# Собирает каталог комплекта версии 14: python3 tools/mkkit5.py <каталог_назначения>
import os, re, shutil, json, sys
dest = sys.argv[1]
if os.path.exists(dest): shutil.rmtree(dest)
for d in ('project', 'tools', 'tests', 'tests/legacy', 'tests/results', 'tests/legacy/results', 'visual', 'review'): os.makedirs(os.path.join(dest, d))
# project
for f in sorted(os.listdir('project')):
    if re.match(r'^(T-|RV-)', f): continue
    if f.endswith('.dc.html') or f in ('canvas.json', 'support.js'): shutil.copy('project/' + f, dest + '/project/' + f)
# tools
for f in sorted(os.listdir('tools')):
    p = 'tools/' + f
    if os.path.isfile(p) and not f.endswith('.pyc'): shutil.copy(p, dest + '/tools/' + f)
# tests
for f in ('play-check.json', 'cdp.mjs', 'tlib.mjs', 'suite5.mjs', 'scan5.mjs', 'shots.mjs', 'rvshots.mjs', 'tokens5.mjs', 'heights.mjs', 'tokens5.json', 'README.md', 'run-all.sh', 'visual-review.json', 'montage.mjs'):
    if os.path.exists('tests/' + f): shutil.copy('tests/' + f, dest + '/tests/' + f)
for f in ('t7.mjs', 't8.mjs', 't9.mjs', 't10.mjs', 't11.mjs', 't12.mjs', 'tlib.mjs', 'cdp.mjs', 'CHANGES.md'):
    shutil.copy('tests/legacy/' + f, dest + '/tests/legacy/' + f)
for f in os.listdir('tests/results'): shutil.copy('tests/results/' + f, dest + '/tests/results/' + f)
for f in os.listdir('tests/legacy/results'): shutil.copy('tests/legacy/results/' + f, dest + '/tests/legacy/results/' + f)
shutil.copy('review/rv.json', dest + '/review/rv.json')
# visual
VIS = json.load(open('tools/visual_list.json', encoding='utf-8'))
idx = []
for name, title in VIS:
    ok = True
    for t in ('dark', 'light'):
        src = 'tests/shots/rv/RV-%s-%s.png' % (name, t)
        if not os.path.exists(src): ok = False; print('нет снимка', src); continue
        shutil.copy(src, dest + '/visual/%s-%s.png' % (name, t))
    if ok: idx.append({'name': name, 'title': title})
json.dump(idx, open(dest + '/visual/index.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
# документы комплекта
for f in ('README.md', 'PROVENANCE.md'): shutil.copy('kitdocs/' + f, dest + '/' + f)
print('комплект:', dest, len(idx), 'состояний')
